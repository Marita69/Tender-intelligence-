# Tender Intelligence

An AI-assisted tender/procurement analysis platform: upload a tender
document, get eligibility criteria, mandatory documents, deadlines,
financial/technical requirements, risks and disqualifying clauses
extracted with page-level citations, a bid/no-bid recommendation, a
compliance checklist, and an exportable analysis report.

# Scope of build
- Multi-tenant auth (signup/login/refresh, org membership, tenant
  isolation enforced on every query), with rate limiting on auth endpoints
- A single hardcoded platform-admin account (`ADMIN_EMAIL`), gating a
  System Overview page (org directory with suspend/unsuspend, telemetry,
  audit-derived system logs) — see PAGES.md "Admin access"
- Tender CRUD, document upload with validation (extension/size checks,
  opaque storage keys)
- PDF/DOCX text extraction with OCR fallback (Tesseract) for scanned pages
- AI extraction pipeline: chunked structured extraction → Requirement +
  Evidence rows (every fact cites a page + exact quote) → conflict/low-
  confidence flagging → human review queue rows → compliance checklist
  generation → bid/no-bid scoring, all against a swappable LLM provider
  abstraction (real Anthropic provider + a heuristic mock provider for
  running the whole thing without an API key)
- Checklist + task management (kanban board with priority/assignee),
  company profile + a real document library (expiry-tracked compliance
  evidence), PDF/DOCX report export with a print-style preview page
- Async processing via Celery (with an eager-mode fallback for local dev),
  audit logging, job-status polling in the UI (with backoff, not a single
  reload)
- Human review queue with a working UI (filter, resolve/reject) and a
  field-correction UI on extracted requirements
- Notifications: an in-app system (bell dropdown + full center + per-user
  preferences) with real triggers (analysis complete/failed, items
  flagged for review) and two scheduled jobs (upcoming-deadline and
  expiring-document alerts) — email delivery is NOT implemented, see
  PAGES.md
- A dashboard with real stats, an active-tender pipeline, and an
  urgent-tasks widget
- Billing: an idempotent credits-ledger abstraction with real Stripe
  webhook signature verification, a checkout-session endpoint, and a
  frontend billing page — disabled by default (`BILLING_PROVIDER=none`,
  unlimited usage) until you configure real Stripe keys
- A full platform admin dashboard (stats, 24h telemetry, organization
  directory with suspend/unsuspend, audit-derived system logs), gated to
  a single hardcoded `ADMIN_EMAIL` account
- A light/dark theme (design tokens ported from a Stitch UI/UX export;
  the dark palette itself was designed for this pass — see PAGES.md
  "Dark theme")
- A working React/Vite/TS/Tailwind frontend covering the whole user
  journey: signup → company profile/document library → create tender →
  upload → run analysis → review requirements/risks/bid recommendation →
  correct a requirement → work the review queue → compliance matrix →
  task board → document viewer → report preview/export → notifications →
  settings → manage billing

See `PAGES.md` for exactly what's built vs. deliberately scoped down per
page, and why (e.g. the Document Viewer's evidence highlighting is
page-jump + sidebar rather than pixel-level in-page highlight overlays;
company-document AI auto-classification is stubbed but not implemented).

## Repo layout

```
apps/api/          FastAPI backend (see apps/api/app for source)
apps/web/           React frontend
docs/               Architecture notes
infra/              (placeholder for IaC — not populated)
docker-compose.yml   Postgres + Redis + api + worker + beat + web
.env.example         Every config var, with comments on what's dev vs prod
PRODUCTION_GUIDE.md   What YOU need to do to ship this
```

## Quickstart (local dev)

```bash
cp .env.example .env
# edit .env: at minimum set SECRET_KEY to something random

docker compose up --build
# first run: generate the initial migration (see apps/api/migrations/versions/README.md)
docker compose exec api alembic revision --autogenerate -m "initial schema"
docker compose exec api alembic upgrade head
```

Then open http://localhost:5173, sign up, and try uploading a tender PDF
with `AI_PROVIDER=mock` (the default) to see the whole pipeline run
without any API key.

## Tests

```bash
cd apps/api
pip install -r requirements.txt --break-system-packages
pytest -v
```

Runs against in-memory SQLite with the mock AI provider — see
`apps/api/tests/README.md` for exactly what this does and doesn't prove.
