# Pages — what was built, what wasn't, and why

This documents every page in the Stitch UI/UX export
(`TenderIntelligence_stitch.zip`, 11 pages + a `DESIGN.md`) against what
exists in `apps/web/src/pages` today, plus the backend work each one
needed. Written for whoever picks this project up next.

## How to read this

For each Stitch page: **Status** (built / partially built / not built),
**Route**, what backend work it needed, and — for anything not built
exactly as designed — why.

---

## 1. Landing Page → Built

**Route:** `/`
**Stitch page:** `landing_page_tender_intelligence`

Restyled to the new token system. Not a pixel-exact port of the Stitch
marketing copy/layout — kept the existing hero structure from the prior
build and reskinned it with the new fonts/colors/icon set, since the
marketing page has no backend dependency and pixel-matching a landing
page is the lowest-value place to spend limited time versus the actual
product screens.

## 2. Dashboard → Built

**Route:** `/app/dashboard`
**Stitch page:** `dashboard_tender_intelligence`
**Backend:** new `GET /api/v1/dashboard/overview` (`app/api/dashboard.py`,
`app/services/dashboard_service.py`) — stats (active tenders, new this
week, deadlines this week, critical blockers), the active-tender pipeline
table with each tender's latest bid score, and an "urgent action
required" list of not-done tasks sorted by due date across the org.

All three widgets in the Stitch design are backed by real queries, not
placeholder data — including "critical blockers," which counts actual
`Risk` rows flagged `is_disqualifying=True` across the org's tenders.

## 3. Tender Detail → Built (as "Overview")

**Route:** `/app/tenders/:tenderId`
**Stitch page:** `tender_detail_solar_farm_maintenance`

This is the tender's home page: document upload/list, run-analysis
button with live polling, bid recommendation, extracted requirements
(with inline correction), and risks. Stitch's mockup bundles compliance
checklist and task info into this same page; this build splits those
into their own routes (below) reached via a shared sub-nav
(`TenderSubNav`), because the compliance matrix and task board each
needed real table/kanban layouts that don't fit naturally as a card
inside a longer scrolling page — matching the *separate* Compliance
Matrix and Task Management mockups Stitch also provided as their own
pages, rather than the combined single-page sketch.

## 4. Compliance Matrix → Built

**Route:** `/app/tenders/:tenderId/compliance`
**Stitch page:** `compliance_matrix_solar_farm_maintenance`
**Backend:** `ChecklistItemOut` enriched with the linked requirement's
type/confidence and first evidence citation (join added in
`checklist_service.py`) — previously the checklist only carried a label
and status; the matrix needed "mandatory," "AI confidence," and "source
page" columns, which live on `Requirement`/`Evidence`.

## 5. Document Viewer → Built, with one deliberate scope cut

**Route:** `/app/tenders/:tenderId/documents/:documentId`
**Stitch page:** `document_viewer_solar_farm_maintenance_tender`

**What's built:** a document list sidebar, the PDF rendered via the
browser's native viewer (fetched as an authenticated blob, not a raw
`<iframe src>`, since the download endpoint requires a Bearer token an
iframe can't attach), and an evidence sidebar where clicking a citation
jumps the viewer to that page.

**What's scoped down, and why:** Stitch's mockup implies pixel-level
highlighted spans directly on the rendered page (the exact quoted text
boxed/highlighted in place). Building that means either a custom
canvas-based PDF renderer with text-layer coordinate mapping (e.g.
pdf.js with a highlight overlay computed from OCR/text-extraction
bounding boxes we don't currently store) — a multi-day feature on its
own — or faking it unconvincingly. The page-jump + quoted-text-in-sidebar
version covers the actual underlying need (let someone verify a fact
against its source quickly) without that build-out. If this matters for
launch, the real fix is storing character/word bounding boxes during
extraction (`app/documents/extraction.py`) and rendering with pdf.js
instead of a native `<iframe>`.

## 6. Task Management → Built

**Route:** `/app/tenders/:tenderId/tasks`
**Stitch page:** `task_management_solar_farm_maintenance`
**Backend:** `Task.priority` (critical/high/medium/low) and a new
`under_review` status added to `TaskStatus` (previously only
todo/in_progress/done/blocked); `GET /api/v1/organization/members` added
so the assignee dropdown has real people to pick from, not a stub list.

Built as a real kanban board (status columns, drag-free but with a
status `<select>` per card, priority tag, assignee avatar with initials)
rather than a flat list, matching the Stitch layout.

## 7. Company Profile & Document Library → Built

**Route:** `/app/company-profile`
**Stitch page:** `company_profile_document_library`
**Backend:** new `CompanyDocument` model + full CRUD/upload/download
router (`app/models/company_document.py`, `app/api/company_document.py`)
— this didn't exist at all before this pass; the only prior storage was
an unused JSONB blob on `CompanyProfile`. Status (valid / expiring soon /
expired / no expiry) is computed from `expiry_date`, not stored, so it's
always current.

**Not built:** AI-driven auto-classification of an uploaded document's
category/expiry (the model has an `ai_confidence` column reserved for
this, deliberately left `null`/unused) — Stitch's mockup implies the
system recognizes "this is a Tax Clearance Certificate" automatically.
Doing that well needs its own extraction pass distinct from the tender-
analysis pipeline; scoped out as a v2 item rather than half-built.

## 8. Tender Analysis Report Preview → Built

**Route:** `/app/tenders/:tenderId/report`
**Stitch page:** `tender_analysis_report_preview`

Styled to look like the exported document itself (a print-like page:
centered title block, executive summary, findings table, risks, footer
disclaimer) rather than another dashboard card, per the mockup. Reuses
the existing `GET .../analysis` and `GET .../reports/{pdf,docx}`
endpoints — no backend change needed beyond what the report-export
feature already had.

## 9. Admin Dashboard / System Overview → Built

**Route:** `/app/admin` (gated — see "Admin access" below)
**Stitch page:** `admin_dashboard_system_overview`
**Backend:** substantially extended `app/services/admin_service.py` +
`app/api/admin.py`:
- Real stats (orgs, users, active tenders, documents processed,
  analysis success rate)
- Real 24h telemetry (job count, token usage, average pipeline duration)
  computed from actual `AnalysisJob` rows, not synthetic numbers
- An organization directory (member/tender counts, credit balance, last
  activity, plan) with a working **suspend/unsuspend** action — enforced
  server-side in `app/security/tenancy.py`'s `current_membership`
  dependency, so suspending an org actually locks out every member from
  every org-scoped route, not just a cosmetic flag in a table
- System logs, derived from the existing append-only `AuditLog` (a
  keyword heuristic classifies each action as info/warning/error for
  display — see the comment in `admin_service.py`; there's no separate
  stored severity field, since `AuditLog` is a record of what happened,
  not an error log)

**Not built:** the telemetry graphs/sparkline charts shown in the Stitch
mockup (numbers are shown as stat cards, not plotted over time) — no
time-series storage exists for this yet, would need a metrics table or
an external time-series backend; and a per-model **cost estimate**
(dollars, not just tokens) — deliberately left out rather than shipped
as a guess, since it needs a pricing table kept in sync with the
provider's published rates and getting it quietly wrong is worse than
not showing it. Both are documented as open items in
`PRODUCTION_GUIDE.md`.

## 10. Notification Center → Built

**Route:** `/app/notifications`, plus a bell-icon dropdown in the app
shell header on every page
**Stitch page:** `notification_center_tender_intelligence`
**Backend:** entirely new — `Notification` + `NotificationPreference`
models, service, and router (`app/models/notification.py`,
`app/services/notification_service.py`, `app/api/notifications.py`).
Real triggers wired into the analysis pipeline (job succeeded, job
failed, N items flagged for review) plus two new Celery-beat scheduled
tasks: `check_upcoming_deadlines` (72h window, hourly) and
`check_expiring_company_documents` (30-day window, daily) — both
deduplicated so re-running the schedule doesn't spam a fresh notification
every time the tender/document stays inside the window.

**Not built:** actual **email delivery**. `NotificationPreference` has an
`email_digest` toggle and it's stored, but nothing sends an email — there
is no email provider (SES/Postmark/SendGrid/etc.) wired into this
codebase at all. Wiring one in is a config + a templating pass, not a
data-model change, so it was left as an explicit, clearly-labeled no-op
in the Settings UI rather than silently doing nothing with no
indication.

## 11. User Settings → Built

**Route:** `/app/settings`
**Stitch page:** `user_settings_tender_intelligence`
**Backend:** `User.job_title` added; new `PATCH /api/v1/auth/me` and
`POST /api/v1/auth/me/change-password`.

Covers profile (name, job title, read-only email), a light/dark theme
picker, and password change. **Not built:** avatar upload (the `User`
model has `avatar_storage_key` reserved for this, unused — same
reasoning as the company-document AI classification: real scope, not
worth half-building without deciding the actual upload/crop UX), and
account deletion/org transfer flows, which aren't in the Stitch mockup
either.

---

## Two pages built in an earlier session, not in the Stitch export

**Review Queue** (`/app/review-queue`) and **Billing** (`/app/billing`)
existed before this round from an earlier extension pass, not from a
Stitch mockup — they're re-themed to match the new design tokens but
weren't restructured against any Stitch layout, since none exists for
them. If a future design pass produces mockups for these, treat them as
not-yet-matched rather than assume the current layout is intentional.

---

## Admin access

**There is exactly one admin account**, identified by `ADMIN_EMAIL` in
the backend's `.env` (see `.env.example` and `PRODUCTION_GUIDE.md`).
Whoever logs in with that exact email is auto-elevated to
`is_platform_admin=True` on every signup/login
(`app/services/auth_service.py::_sync_platform_admin_flag`); every other
account is guaranteed `False`. There is no API endpoint that accepts
`is_platform_admin` as input from a client — the only way to become
admin is controlling that mailbox. If `ADMIN_EMAIL` is changed or
cleared, the previous admin's flag is revoked on their next login rather
than lingering.

The frontend's `AdminRoute` guard (hides `/app/admin` and the Admin nav
item from non-admins) is a UX convenience only — the real boundary is
server-side: every `/api/v1/admin/*` route depends on
`require_platform_admin`, so even a modified frontend or a direct API
call from a non-admin gets a 403.

## Dark theme

The Stitch export scaffolded `darkMode: "class"` in every page's Tailwind
config but never defined a single dark color value anywhere across the
11 pages — only the light palette exists in the export. The dark palette
in `apps/web/src/styles/index.css` (the `.dark { ... }` block) was
designed for this pass, following the same Material-3-flavored token
relationships as the light palette (same hue for primary/secondary/error,
adjusted lightness/contrast for a dark surface), not lifted from
anything Stitch provided. The token *names* match Stitch's light-theme
tokens one-for-one, minus the `-fixed`/`-fixed-dim`/`-fixed-variant` and
`tertiary` families (M3 tokens for "always-light" chip surfaces that
nothing in this app's actual UI uses).

Toggle lives in Settings (`/app/settings`) and as a header icon button
(`ThemeToggle`) on every authenticated page. Preference is stored in
`localStorage` and applied before first paint via a small inline script
in `index.html` (avoids a flash of the wrong theme on load).
