# Tender Intelligence — Web

React 18 + TypeScript + Vite + Tailwind. Talks to the FastAPI backend in
`apps/api` via `src/lib/api.ts` (reads `VITE_API_BASE_URL`).

## ⚠️ Not build-verified in this sandbox

This code was written without network access, so `npm install` could not
be run here (no registry access) and neither `vite build` nor `tsc` has
actually been executed against the real dependency tree. The code has
been manually reviewed for import-path correctness and obvious logic
errors, but **you must treat first install/build as an unverified step**:

```bash
cd apps/web
npm install
npm run build   # runs `tsc -b` first — this is your first real syntax/type check
npm run dev
```

Fix whatever `npm run build` surfaces before deploying — most likely small
type mismatches, not structural issues, but don't skip this step.

## Structure

- `src/pages/` — one file per route (Landing, Login, Signup, TendersList,
  TenderDetail, CompanyProfilePage)
- `src/components/` — shared UI (AppShell, Card, Button, StatusStamp)
- `src/hooks/useAuth.tsx` — session + multi-organization context
- `src/lib/api.ts` — fetch wrapper: injects auth + org headers, retries once
  on 401 via refresh token
- `src/types/index.ts` — mirrors the backend Pydantic schemas by hand;
  if you change a backend schema, update this file too (no codegen wired
  up yet — see "Suggested next steps" in the root README)

## What's implemented vs. stubbed

Implemented: signup/login, tender CRUD, document upload, triggering
analysis with backoff-polling job status (not a single reload), requirements/
risks/bid-assessment display with evidence citations, inline requirement
correction, checklist toggling, task listing, PDF/DOCX report download,
company profile form, multi-organization switcher, a review queue page
(filter + resolve/reject), a billing page (credit balance + Stripe Checkout
redirect, only shown when billing is enabled), and a minimal admin stats
page (only shown to platform admins).

Not implemented (see root PRODUCTION_GUIDE.md and spec for the rest):
task assignment picker, drag-and-drop upload, true real-time job progress
(polls with backoff, not websockets/SSE), a post-purchase confirmation
screen after Stripe Checkout redirects back, and a deeper admin dashboard
beyond the current stats page.
