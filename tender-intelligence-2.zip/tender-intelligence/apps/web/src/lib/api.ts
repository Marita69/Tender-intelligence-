const API_BASE = import.meta.env.VITE_API_BASE_URL || "http://localhost:8000";

export class ApiError extends Error {
  status: number;
  constructor(status: number, message: string) {
    super(message);
    this.status = status;
  }
}

function getStoredAuth() {
  return {
    accessToken: localStorage.getItem("access_token"),
    refreshToken: localStorage.getItem("refresh_token"),
    organizationId: localStorage.getItem("organization_id"),
  };
}

export function setStoredAuth(accessToken: string, refreshToken: string, organizationId?: string) {
  localStorage.setItem("access_token", accessToken);
  localStorage.setItem("refresh_token", refreshToken);
  if (organizationId) localStorage.setItem("organization_id", organizationId);
}

export function setActiveOrganization(organizationId: string) {
  localStorage.setItem("organization_id", organizationId);
}

export function clearStoredAuth() {
  localStorage.removeItem("access_token");
  localStorage.removeItem("refresh_token");
  localStorage.removeItem("organization_id");
}

async function request<T>(
  path: string,
  options: RequestInit = {},
  { skipAuth = false, retrying = false }: { skipAuth?: boolean; retrying?: boolean } = {}
): Promise<T> {
  const { accessToken, organizationId } = getStoredAuth();
  const headers = new Headers(options.headers);
  if (!(options.body instanceof FormData) && !headers.has("Content-Type") && options.body) {
    headers.set("Content-Type", "application/json");
  }
  if (!skipAuth && accessToken) headers.set("Authorization", `Bearer ${accessToken}`);
  if (!skipAuth && organizationId) headers.set("X-Organization-Id", organizationId);

  let resp: Response;
  try {
    resp = await fetch(`${API_BASE}${path}`, { ...options, headers });
  } catch (err) {
    // fetch() itself throws (not resp.ok=false) when the request never got
    // a response at all — wrong API_BASE_URL, the API is down, or a CORS
    // rejection. Wrapping this as an ApiError means every caller's existing
    // `err instanceof ApiError ? err.message : "Something went wrong"`
    // pattern shows something actionable instead of the generic fallback,
    // which is what made this class of failure hard to diagnose before.
    throw new ApiError(
      0,
      `Could not reach the server at ${API_BASE}. Check that the API is running and that CORS_ORIGINS on the backend includes this site's origin (${window.location.origin}).`
    );
  }

  if (resp.status === 401 && !skipAuth && !retrying) {
    const refreshed = await tryRefreshToken();
    if (refreshed) {
      return request<T>(path, options, { skipAuth, retrying: true });
    }
    clearStoredAuth();
    window.location.href = "/login";
    throw new ApiError(401, "Session expired");
  }

  if (!resp.ok) {
    let detail = resp.statusText;
    try {
      const body = await resp.json();
      detail = body.detail || detail;
    } catch {
      /* non-JSON error body */
    }
    throw new ApiError(resp.status, detail);
  }

  if (resp.status === 204) return undefined as T;

  const contentType = resp.headers.get("content-type") || "";
  if (contentType.includes("application/json")) {
    return resp.json();
  }
  return resp.blob() as unknown as T;
}

async function tryRefreshToken(): Promise<boolean> {
  const { refreshToken } = getStoredAuth();
  if (!refreshToken) return false;
  try {
    const resp = await fetch(`${API_BASE}/api/v1/auth/refresh`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ refresh_token: refreshToken }),
    });
    if (!resp.ok) return false;
    const body = await resp.json();
    setStoredAuth(body.access_token, body.refresh_token);
    return true;
  } catch {
    return false;
  }
}

export const api = {
  get: <T>(path: string) => request<T>(path, { method: "GET" }),
  post: <T>(path: string, body?: unknown, opts?: { skipAuth?: boolean }) =>
    request<T>(path, { method: "POST", body: body ? JSON.stringify(body) : undefined }, opts),
  patch: <T>(path: string, body?: unknown) =>
    request<T>(path, { method: "PATCH", body: body ? JSON.stringify(body) : undefined }),
  put: <T>(path: string, body?: unknown) =>
    request<T>(path, { method: "PUT", body: body ? JSON.stringify(body) : undefined }),
  delete: <T>(path: string) => request<T>(path, { method: "DELETE" }),
  upload: <T>(path: string, file: File, extraFields?: Record<string, string>) => {
    const form = new FormData();
    form.append("file", file);
    const qs = extraFields
      ? "?" + new URLSearchParams(extraFields).toString()
      : "";
    return request<T>(`${path}${qs}`, { method: "POST", body: form });
  },
  // Distinct from `upload`: this one sends extra fields as multipart form
  // fields in the body (matches endpoints built with FastAPI's Form(...)
  // params), not as query params — used by the company document library
  // upload, which needs name/category/expiry_date alongside the file.
  uploadWithFields: <T>(path: string, file: File, fields: Record<string, string>) => {
    const form = new FormData();
    form.append("file", file);
    for (const [key, value] of Object.entries(fields)) {
      if (value) form.append(key, value);
    }
    return request<T>(path, { method: "POST", body: form });
  },
  getBlob: async (path: string): Promise<Blob> => {
    const { accessToken, organizationId } = getStoredAuth();
    const resp = await fetch(`${API_BASE}${path}`, {
      headers: {
        Authorization: `Bearer ${accessToken}`,
        "X-Organization-Id": organizationId || "",
      },
    });
    if (!resp.ok) throw new ApiError(resp.status, resp.statusText);
    return resp.blob();
  },
};
