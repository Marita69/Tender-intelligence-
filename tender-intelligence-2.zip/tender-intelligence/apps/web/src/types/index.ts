export type MembershipRole = "owner" | "admin" | "member" | "viewer";

export interface Membership {
  user: {
    id: string;
    email: string;
    full_name: string;
    job_title: string | null;
    is_active: boolean;
    is_platform_admin: boolean;
  };
  organization_id: string;
  organization_name: string;
  role: MembershipRole;
}

export type TenderStatus = "draft" | "processing" | "analyzed" | "failed" | "archived";

export interface Tender {
  id: string;
  title: string;
  reference_number: string | null;
  issuing_entity: string | null;
  status: TenderStatus;
  submission_deadline: string | null;
  submission_deadline_timezone: string | null;
  submission_deadline_is_uncertain: boolean;
  bid_outcome: string | null;
  created_at: string;
  updated_at: string;
}

export interface TenderListResponse {
  items: Tender[];
  total: number;
  page: number;
  page_size: number;
}

export type DocumentStatus =
  | "uploaded"
  | "validating"
  | "valid"
  | "invalid"
  | "extracting"
  | "extracted"
  | "failed";

export interface TenderDocument {
  id: string;
  tender_id: string;
  original_filename: string;
  content_type: string;
  size_bytes: number;
  document_kind: string;
  status: DocumentStatus;
  status_reason: string | null;
  page_count: number | null;
  has_text_layer: boolean | null;
  ocr_used: boolean;
  created_at: string;
}

export type RequirementType =
  | "eligibility"
  | "mandatory_document"
  | "deadline"
  | "financial"
  | "bid_security"
  | "technical"
  | "evaluation_criterion"
  | "submission_instruction"
  | "contract_term";

export type ConfidenceLevel = "high" | "medium" | "low" | "unknown";

export interface Evidence {
  id: string;
  document_id: string;
  page_number: number;
  quoted_text: string;
}

export interface Requirement {
  id: string;
  type: RequirementType;
  summary: string;
  detail: string | null;
  structured_value: Record<string, unknown>;
  confidence: ConfidenceLevel;
  is_inferred: boolean;
  is_unknown: boolean;
  deadline_at: string | null;
  deadline_timezone: string | null;
  has_conflict: boolean;
  conflict_notes: string | null;
  references_missing_document: boolean;
  referenced_document_name: string | null;
  evidence: Evidence[];
}

export type RiskSeverity = "critical" | "high" | "medium" | "low";

export interface Risk {
  id: string;
  title: string;
  description: string;
  severity: RiskSeverity;
  is_disqualifying: boolean;
}

export type BidRecommendation = "bid" | "conditional_bid" | "no_bid" | "insufficient_information";

export interface BidAssessment {
  id: string;
  recommendation: BidRecommendation;
  score: number;
  confidence: ConfidenceLevel;
  rationale: string;
  score_breakdown: Record<string, unknown>;
  disqualifying_factors: string[];
}

export type AnalysisJobStatus = "pending" | "running" | "succeeded" | "failed" | "partially_succeeded";

export interface AnalysisJob {
  id: string;
  status: AnalysisJobStatus;
  ai_provider: string;
  ai_model: string;
  prompt_version: string;
  error_message: string | null;
  created_at: string;
}

export interface TenderAnalysis {
  job: AnalysisJob;
  requirements: Requirement[];
  risks: Risk[];
  bid_assessment: BidAssessment | null;
}

export type ChecklistItemStatus = "missing" | "in_progress" | "complete" | "not_applicable";

export interface ChecklistItem {
  id: string;
  label: string;
  status: ChecklistItemStatus;
  linked_document_id: string | null;
  notes: string | null;
  requirement_type: string | null;
  confidence: ConfidenceLevel | null;
  evidence_document_id: string | null;
  evidence_page_number: number | null;
  evidence_quote: string | null;
}

export type TaskStatus = "todo" | "in_progress" | "under_review" | "done" | "blocked";
export type TaskPriority = "critical" | "high" | "medium" | "low";

export interface Task {
  id: string;
  title: string;
  description: string | null;
  status: TaskStatus;
  priority: TaskPriority;
  due_at: string | null;
  assigned_to_user_id: string | null;
}

export interface CompanyProfile {
  id: string;
  legal_name: string;
  registration_number: string | null;
  years_in_operation: number | null;
  sectors: string[];
  certifications: string[];
  annual_turnover_band: string | null;
  financial_capacity_notes: string | null;
}

export type ReviewStatus = "needs_review" | "reviewed" | "rejected" | "corrected";

export interface ReviewItem {
  id: string;
  tender_id: string;
  requirement_id: string | null;
  reason: string;
  status: ReviewStatus;
  reviewed_by_user_id: string | null;
  reviewed_at: string | null;
  created_at: string;
  requirement_summary: string | null;
  requirement_type: string | null;
}

export interface BillingBalance {
  credits: number;
  billing_enabled: boolean;
}

export type CompanyDocumentStatus = "valid" | "expiring_soon" | "expired" | "no_expiry";

export interface CompanyDocument {
  id: string;
  name: string;
  category: string;
  issuing_body: string | null;
  original_filename: string;
  content_type: string;
  size_bytes: number;
  expiry_date: string | null;
  status: CompanyDocumentStatus;
  ai_confidence: number | null;
  created_at: string;
}

export type NotificationType = "deadline" | "compliance" | "analysis" | "document_expiry" | "task" | "system";

export interface AppNotification {
  id: string;
  type: NotificationType;
  title: string;
  body: string | null;
  tender_id: string | null;
  is_read: boolean;
  created_at: string;
}

export interface NotificationPreferences {
  email_digest: boolean;
  in_app_alerts: boolean;
  alert_critical_deadlines: boolean;
  alert_compliance: boolean;
  alert_analysis_complete: boolean;
  alert_team_activity: boolean;
}

export interface DashboardStats {
  active_tenders: number;
  new_this_week: number;
  deadlines_this_week: number;
  critical_blockers: number;
}

export interface PipelineTender {
  id: string;
  title: string;
  reference_number: string | null;
  issuing_entity: string | null;
  submission_deadline: string | null;
  bid_score: number | null;
  bid_recommendation: BidRecommendation | null;
  status: TenderStatus;
}

export interface UrgentTask {
  id: string;
  tender_id: string;
  tender_title: string;
  title: string;
  due_at: string | null;
  assigned_to_user_id: string | null;
  assigned_to_name: string | null;
  status: TaskStatus;
}

export interface DashboardOverview {
  stats: DashboardStats;
  pipeline: PipelineTender[];
  urgent_tasks: UrgentTask[];
}

export interface AdminStats {
  organizations: number;
  users: number;
  active_tenders: number;
  documents_processed: number;
  analysis_jobs_succeeded: number;
  analysis_jobs_failed: number;
  extraction_success_rate_pct: number;
}

export interface AdminTelemetry {
  jobs_last_24h: number;
  tokens_last_24h: number;
  avg_pipeline_seconds: number | null;
}

export interface AdminOrganization {
  id: string;
  name: string;
  slug: string;
  plan: string;
  is_suspended: boolean;
  member_count: number;
  tender_count: number;
  credit_balance: number;
  created_at: string;
  last_activity_at: string | null;
}

export interface AdminSystemLog {
  id: string;
  level: "info" | "warning" | "error";
  action: string;
  resource_type: string;
  resource_id: string | null;
  organization_id: string | null;
  created_at: string;
}

export type AIProviderName = "anthropic" | "openrouter" | "nvidia" | "gemini" | "deepseek" | "mock";

export interface AIProviderSetting {
  provider: AIProviderName;
  model: string;
  is_override_active: boolean;
  updated_at: string | null;
}

export interface AIProviderTestResult {
  success: boolean;
  message: string;
  sample_output: string | null;
}
