import { NavLink } from "react-router-dom";

const TABS = [
  { to: "", label: "Overview", end: true },
  { to: "compliance", label: "Compliance Matrix" },
  { to: "tasks", label: "Tasks" },
  { to: "report", label: "Report" },
];

export function TenderSubNav({ tenderId }: { tenderId: string }) {
  return (
    <div className="flex gap-1 border-b border-border-subtle">
      {TABS.map((tab) => (
        <NavLink
          key={tab.to}
          to={`/app/tenders/${tenderId}${tab.to ? `/${tab.to}` : ""}`}
          end={tab.end}
          className={({ isActive }) =>
            `px-4 py-2 text-sm font-medium ${
              isActive ? "border-b-2 border-secondary text-secondary" : "text-on-surface-variant hover:text-on-surface"
            }`
          }
        >
          {tab.label}
        </NavLink>
      ))}
    </div>
  );
}
