import { NavLink, Outlet, Link } from "react-router-dom";
import { useEffect, useRef, useState } from "react";
import { useAuth } from "@/hooks/useAuth";
import { api } from "@/lib/api";
import type { AppNotification, BillingBalance } from "@/types";
import { Icon } from "@/components/Icon";
import { ThemeToggle } from "@/components/ThemeToggle";

const NAV_ITEMS = [
  { to: "/app/dashboard", label: "Dashboard", icon: "dashboard" },
  { to: "/app/tenders", label: "Tenders", icon: "folder_open" },
  { to: "/app/review-queue", label: "Review Queue", icon: "fact_check" },
  { to: "/app/company-profile", label: "Company Profile", icon: "business_center" },
];

export function AppShell() {
  const { memberships, activeOrganizationId, switchOrganization, logout } = useAuth();
  const activeMembership = memberships.find((m) => m.organization_id === activeOrganizationId);
  const isPlatformAdmin = activeMembership?.user.is_platform_admin ?? false;
  const [balance, setBalance] = useState<BillingBalance | null>(null);
  const [notifications, setNotifications] = useState<AppNotification[]>([]);
  const [unreadCount, setUnreadCount] = useState(0);
  const [bellOpen, setBellOpen] = useState(false);
  const bellRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    api.get<BillingBalance>("/api/v1/billing/balance").then(setBalance).catch(() => setBalance(null));
    loadNotifications();
    const interval = setInterval(() => api.get<{ count: number }>("/api/v1/notifications/unread-count").then((r) => setUnreadCount(r.count)), 60000);
    return () => clearInterval(interval);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [activeOrganizationId]);

  useEffect(() => {
    function onClickOutside(e: MouseEvent) {
      if (bellRef.current && !bellRef.current.contains(e.target as Node)) setBellOpen(false);
    }
    document.addEventListener("mousedown", onClickOutside);
    return () => document.removeEventListener("mousedown", onClickOutside);
  }, []);

  async function loadNotifications() {
    const [list, count] = await Promise.all([
      api.get<AppNotification[]>("/api/v1/notifications?unread_only=false"),
      api.get<{ count: number }>("/api/v1/notifications/unread-count"),
    ]);
    setNotifications(list.slice(0, 6));
    setUnreadCount(count.count);
  }

  async function markRead(id: string) {
    await api.post(`/api/v1/notifications/${id}/read`);
    setNotifications((prev) => prev.map((n) => (n.id === id ? { ...n, is_read: true } : n)));
    setUnreadCount((c) => Math.max(0, c - 1));
  }

  const navItems = [
    ...NAV_ITEMS,
    ...(balance?.billing_enabled ? [{ to: "/app/billing", label: "Billing", icon: "payments" }] : []),
    ...(isPlatformAdmin ? [{ to: "/app/admin", label: "Admin", icon: "shield_person" }] : []),
  ];

  return (
    <div className="flex min-h-screen">
      <aside className="w-60 shrink-0 border-r border-border-subtle bg-surface-container-lowest">
        <div className="flex h-16 items-center gap-2 border-b border-border-subtle px-5">
          <div className="h-6 w-6 rotate-3 rounded-sm border-2 border-secondary" aria-hidden />
          <span className="font-display text-lg font-semibold text-on-surface">Tender Intel</span>
        </div>
        <nav className="flex flex-col gap-1 p-3">
          {navItems.map((item) => (
            <NavLink
              key={item.to}
              to={item.to}
              className={({ isActive }) =>
                `flex items-center gap-2 rounded-md px-3 py-2 text-sm font-medium ${
                  isActive ? "bg-secondary-container text-on-secondary-container" : "text-on-surface-variant hover:bg-surface-container-low"
                }`
              }
            >
              <Icon name={item.icon} size={18} />
              {item.label}
            </NavLink>
          ))}
        </nav>
      </aside>

      <div className="flex flex-1 flex-col">
        <header className="flex h-16 items-center justify-between border-b border-border-subtle bg-surface-container-lowest px-6">
          <div>
            {memberships.length > 1 ? (
              <select
                className="rounded-md border border-border-subtle px-2 py-1 text-sm"
                value={activeOrganizationId ?? ""}
                onChange={(e) => switchOrganization(e.target.value)}
              >
                {memberships.map((m) => (
                  <option key={m.organization_id} value={m.organization_id}>
                    {m.organization_name}
                  </option>
                ))}
              </select>
            ) : (
              <span className="text-sm font-medium text-on-surface-variant">{activeMembership?.organization_name}</span>
            )}
          </div>
          <div className="flex items-center gap-2">
            {balance?.billing_enabled && (
              <NavLink
                to="/app/billing"
                className="rounded-full bg-surface-container-low px-3 py-1 text-xs font-medium text-on-surface-variant hover:bg-surface-container"
              >
                {balance.credits} credits
              </NavLink>
            )}

            <div className="relative" ref={bellRef}>
              <button
                onClick={() => setBellOpen((o) => !o)}
                className="relative flex h-9 w-9 items-center justify-center rounded-full text-on-surface-variant hover:bg-surface-container-low"
                aria-label="Notifications"
              >
                <Icon name="notifications" />
                {unreadCount > 0 && (
                  <span className="absolute right-1 top-1 flex h-2 w-2 rounded-full bg-error" />
                )}
              </button>
              {bellOpen && (
                <div className="absolute right-0 mt-2 w-80 rounded-lg border border-border-subtle bg-surface-container-lowest shadow-lg">
                  <div className="flex items-center justify-between border-b border-border-subtle px-4 py-2">
                    <span className="text-sm font-semibold text-on-surface">Notifications</span>
                    <Link to="/app/notifications" className="text-xs text-secondary hover:underline" onClick={() => setBellOpen(false)}>
                      View all
                    </Link>
                  </div>
                  {notifications.length === 0 ? (
                    <p className="p-4 text-sm text-muted">No notifications yet.</p>
                  ) : (
                    <ul className="max-h-80 divide-y divide-border-subtle overflow-y-auto">
                      {notifications.map((n) => (
                        <li key={n.id} className={`px-4 py-2.5 text-sm ${n.is_read ? "" : "bg-secondary-container/20"}`}>
                          <button onClick={() => !n.is_read && markRead(n.id)} className="w-full text-left">
                            <p className="font-medium text-on-surface">{n.title}</p>
                            {n.body && <p className="mt-0.5 text-xs text-on-surface-variant">{n.body}</p>}
                          </button>
                        </li>
                      ))}
                    </ul>
                  )}
                </div>
              )}
            </div>

            <ThemeToggle />

            <Link to="/app/settings" className="text-sm text-muted hover:text-on-surface">
              {activeMembership?.user.full_name}
            </Link>
            <button onClick={logout} className="text-sm font-medium text-muted hover:text-on-surface">
              Log out
            </button>
          </div>
        </header>
        <main className="flex-1 bg-background p-6">
          <Outlet />
        </main>
      </div>
    </div>
  );
}
