interface IconProps {
  name: string;
  className?: string;
  size?: number;
  filled?: boolean;
}

/**
 * Wraps a Material Symbols Outlined ligature span. The font is loaded in
 * index.html; `name` is the icon's ligature name (e.g. "dashboard",
 * "notifications", "warning") — see fonts.google.com/icons for the catalog
 * used throughout the Stitch designs this app's UI is based on.
 */
export function Icon({ name, className = "", size = 20, filled = false }: IconProps) {
  return (
    <span
      className={`material-symbols-outlined select-none leading-none ${className}`}
      style={{
        fontSize: size,
        fontVariationSettings: `"FILL" ${filled ? 1 : 0}, "wght" 400, "GRAD" 0, "opsz" 24`,
      }}
      aria-hidden="true"
    >
      {name}
    </span>
  );
}
