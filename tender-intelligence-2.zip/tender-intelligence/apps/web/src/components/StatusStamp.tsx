import type { ChecklistItemStatus, ConfidenceLevel } from "@/types";

const CHECKLIST_LABELS: Record<ChecklistItemStatus, string> = {
  complete: "Complete",
  missing: "Missing",
  in_progress: "In Progress",
  not_applicable: "N/A",
};

const CHECKLIST_CLASSES: Record<ChecklistItemStatus, string> = {
  complete: "stamp-complete",
  missing: "stamp-missing",
  in_progress: "stamp-progress",
  not_applicable: "stamp-na",
};

export function ChecklistStamp({ status }: { status: ChecklistItemStatus }) {
  return <span className={CHECKLIST_CLASSES[status]}>{CHECKLIST_LABELS[status]}</span>;
}

const CONFIDENCE_CLASSES: Record<ConfidenceLevel, string> = {
  high: "stamp-complete",
  medium: "stamp-progress",
  low: "stamp-missing",
  unknown: "stamp-na",
};

export function ConfidenceStamp({ level }: { level: ConfidenceLevel }) {
  return <span className={CONFIDENCE_CLASSES[level]}>{level}</span>;
}
