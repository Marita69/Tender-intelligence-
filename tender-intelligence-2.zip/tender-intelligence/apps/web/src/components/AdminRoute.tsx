import type { ReactNode } from "react";
import { Navigate } from "react-router-dom";
import { useAuth } from "@/hooks/useAuth";

/**
 * There is exactly one admin account (ADMIN_EMAIL in the backend's .env —
 * see PRODUCTION_GUIDE.md). This guard is a UX convenience only, not the
 * real security boundary: every /api/v1/admin/* route independently
 * requires is_platform_admin server-side (require_platform_admin in
 * app/security/tenancy.py), so hiding the route here just avoids showing
 * a non-admin a page that would 403 anyway.
 */
export function AdminRoute({ children }: { children: ReactNode }) {
  const { memberships, activeOrganizationId, isLoading } = useAuth();
  if (isLoading) return <p className="p-6 text-sm text-muted">Loading…</p>;
  const membership = memberships.find((m) => m.organization_id === activeOrganizationId);
  if (!membership?.user.is_platform_admin) return <Navigate to="/app/tenders" replace />;
  return <>{children}</>;
}
