import { useState } from "react";
import { api, ApiError } from "@/lib/api";
import { useAuth } from "@/hooks/useAuth";
import { useTheme } from "@/hooks/useTheme";
import { Card, CardBody, CardHeader } from "@/components/Card";
import { Button } from "@/components/Button";

export function UserSettingsPage() {
  const { memberships, activeOrganizationId, refreshMemberships } = useAuth();
  const { theme, setTheme } = useTheme();
  const membership = memberships.find((m) => m.organization_id === activeOrganizationId);

  const [fullName, setFullName] = useState(membership?.user.full_name || "");
  const [jobTitle, setJobTitle] = useState(membership?.user.job_title || "");
  const [profileMessage, setProfileMessage] = useState<string | null>(null);
  const [isSavingProfile, setIsSavingProfile] = useState(false);

  const [currentPassword, setCurrentPassword] = useState("");
  const [newPassword, setNewPassword] = useState("");
  const [passwordMessage, setPasswordMessage] = useState<string | null>(null);
  const [passwordError, setPasswordError] = useState<string | null>(null);
  const [isSavingPassword, setIsSavingPassword] = useState(false);

  async function handleSaveProfile(e: React.FormEvent) {
    e.preventDefault();
    setIsSavingProfile(true);
    setProfileMessage(null);
    try {
      await api.patch("/api/v1/auth/me", { full_name: fullName, job_title: jobTitle || null });
      await refreshMemberships();
      setProfileMessage("Saved.");
    } finally {
      setIsSavingProfile(false);
    }
  }

  async function handleChangePassword(e: React.FormEvent) {
    e.preventDefault();
    setIsSavingPassword(true);
    setPasswordError(null);
    setPasswordMessage(null);
    try {
      await api.post("/api/v1/auth/me/change-password", {
        current_password: currentPassword,
        new_password: newPassword,
      });
      setCurrentPassword("");
      setNewPassword("");
      setPasswordMessage("Password updated.");
    } catch (err) {
      setPasswordError(err instanceof ApiError ? err.message : "Could not update password");
    } finally {
      setIsSavingPassword(false);
    }
  }

  return (
    <div className="mx-auto max-w-2xl space-y-6">
      <h1 className="font-display text-2xl font-semibold text-on-surface">Settings</h1>

      <Card>
        <CardHeader title="Profile" />
        <CardBody>
          <form onSubmit={handleSaveProfile} className="space-y-4">
            <div>
              <label className="block text-sm font-medium text-on-surface-variant">Full name</label>
              <input
                required
                value={fullName}
                onChange={(e) => setFullName(e.target.value)}
                className="mt-1 w-full rounded-md border border-outline-variant px-3 py-2 text-sm focus:border-secondary focus:outline-none focus:ring-1 focus:ring-secondary"
              />
            </div>
            <div>
              <label className="block text-sm font-medium text-on-surface-variant">Job title</label>
              <input
                value={jobTitle}
                onChange={(e) => setJobTitle(e.target.value)}
                placeholder="e.g. Procurement Analyst"
                className="mt-1 w-full rounded-md border border-outline-variant px-3 py-2 text-sm focus:border-secondary focus:outline-none focus:ring-1 focus:ring-secondary"
              />
            </div>
            <div>
              <label className="block text-sm font-medium text-on-surface-variant">Email</label>
              <input
                disabled
                value={membership?.user.email || ""}
                className="mt-1 w-full rounded-md border border-outline-variant bg-surface-container-low px-3 py-2 text-sm text-muted"
              />
            </div>
            {profileMessage && <p className="text-sm text-secondary">{profileMessage}</p>}
            <Button type="submit" disabled={isSavingProfile}>
              {isSavingProfile ? "Saving…" : "Save profile"}
            </Button>
          </form>
        </CardBody>
      </Card>

      <Card>
        <CardHeader title="Appearance" />
        <CardBody>
          <div className="flex gap-2">
            <button
              onClick={() => setTheme("light")}
              className={`flex-1 rounded-md border px-4 py-2 text-sm ${
                theme === "light" ? "border-secondary bg-secondary-container text-on-secondary-container" : "border-outline-variant text-on-surface-variant"
              }`}
            >
              Light
            </button>
            <button
              onClick={() => setTheme("dark")}
              className={`flex-1 rounded-md border px-4 py-2 text-sm ${
                theme === "dark" ? "border-secondary bg-secondary-container text-on-secondary-container" : "border-outline-variant text-on-surface-variant"
              }`}
            >
              Dark
            </button>
          </div>
        </CardBody>
      </Card>

      <Card>
        <CardHeader title="Change password" />
        <CardBody>
          <form onSubmit={handleChangePassword} className="space-y-4">
            <div>
              <label className="block text-sm font-medium text-on-surface-variant">Current password</label>
              <input
                type="password"
                required
                value={currentPassword}
                onChange={(e) => setCurrentPassword(e.target.value)}
                className="mt-1 w-full rounded-md border border-outline-variant px-3 py-2 text-sm focus:border-secondary focus:outline-none focus:ring-1 focus:ring-secondary"
              />
            </div>
            <div>
              <label className="block text-sm font-medium text-on-surface-variant">New password</label>
              <input
                type="password"
                required
                minLength={10}
                value={newPassword}
                onChange={(e) => setNewPassword(e.target.value)}
                className="mt-1 w-full rounded-md border border-outline-variant px-3 py-2 text-sm focus:border-secondary focus:outline-none focus:ring-1 focus:ring-secondary"
              />
            </div>
            {passwordError && <p className="text-sm text-status-danger">{passwordError}</p>}
            {passwordMessage && <p className="text-sm text-secondary">{passwordMessage}</p>}
            <Button type="submit" disabled={isSavingPassword}>
              {isSavingPassword ? "Updating…" : "Update password"}
            </Button>
          </form>
        </CardBody>
      </Card>
    </div>
  );
}
