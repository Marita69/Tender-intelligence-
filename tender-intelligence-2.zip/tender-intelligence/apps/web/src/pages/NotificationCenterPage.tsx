import { useEffect, useState } from "react";
import { Link } from "react-router-dom";
import { api } from "@/lib/api";
import type { AppNotification, NotificationPreferences } from "@/types";
import { Card, CardBody, CardHeader } from "@/components/Card";
import { Button } from "@/components/Button";
import { Icon } from "@/components/Icon";

const TYPE_ICON: Record<string, string> = {
  deadline: "event_upcoming",
  compliance: "fact_check",
  analysis: "auto_awesome",
  document_expiry: "folder_off",
  task: "task_alt",
  system: "info",
};

const PREF_LABELS: { key: keyof NotificationPreferences; label: string }[] = [
  { key: "in_app_alerts", label: "In-app alerts" },
  { key: "alert_critical_deadlines", label: "Critical deadline alerts" },
  { key: "alert_compliance", label: "Compliance / review-queue alerts" },
  { key: "alert_analysis_complete", label: "Analysis complete alerts" },
  { key: "alert_team_activity", label: "Team activity" },
  { key: "email_digest", label: "Email digest (not yet delivered — see PAGES.md)" },
];

export function NotificationCenterPage() {
  const [items, setItems] = useState<AppNotification[]>([]);
  const [prefs, setPrefs] = useState<NotificationPreferences | null>(null);

  async function load() {
    const [notifs, preferences] = await Promise.all([
      api.get<AppNotification[]>("/api/v1/notifications"),
      api.get<NotificationPreferences>("/api/v1/notifications/preferences"),
    ]);
    setItems(notifs);
    setPrefs(preferences);
  }

  useEffect(() => {
    load();
  }, []);

  async function markRead(id: string) {
    await api.post(`/api/v1/notifications/${id}/read`);
    setItems((prev) => prev.map((n) => (n.id === id ? { ...n, is_read: true } : n)));
  }

  async function markAllRead() {
    await api.post("/api/v1/notifications/mark-all-read");
    setItems((prev) => prev.map((n) => ({ ...n, is_read: true })));
  }

  async function togglePref(key: keyof NotificationPreferences) {
    if (!prefs) return;
    const updated = await api.put<NotificationPreferences>("/api/v1/notifications/preferences", {
      [key]: !prefs[key],
    });
    setPrefs(updated);
  }

  const unreadCount = items.filter((n) => !n.is_read).length;

  return (
    <div className="mx-auto max-w-4xl">
      <div className="flex items-center justify-between">
        <h1 className="font-display text-2xl font-semibold text-on-surface">Notifications</h1>
        {unreadCount > 0 && (
          <Button variant="secondary" onClick={markAllRead}>
            Mark all read
          </Button>
        )}
      </div>

      <div className="mt-6 grid grid-cols-1 gap-6 lg:grid-cols-[1fr_280px]">
        <Card>
          <CardBody className="!p-0">
            {items.length === 0 ? (
              <p className="p-5 text-sm text-muted">No notifications yet.</p>
            ) : (
              <ul className="divide-y divide-border-subtle">
                {items.map((n) => (
                  <li key={n.id} className={`flex items-start gap-3 p-4 text-sm ${n.is_read ? "" : "bg-secondary-container/20"}`}>
                    <Icon name={TYPE_ICON[n.type] || "info"} className="mt-0.5 text-secondary" />
                    <div className="flex-1">
                      {n.tender_id ? (
                        <Link to={`/app/tenders/${n.tender_id}`} className="font-medium text-on-surface hover:text-secondary">
                          {n.title}
                        </Link>
                      ) : (
                        <p className="font-medium text-on-surface">{n.title}</p>
                      )}
                      {n.body && <p className="mt-0.5 text-on-surface-variant">{n.body}</p>}
                      <p className="mt-1 text-xs text-muted">{new Date(n.created_at).toLocaleString()}</p>
                    </div>
                    {!n.is_read && (
                      <button onClick={() => markRead(n.id)} className="text-xs font-medium text-secondary hover:underline">
                        Mark read
                      </button>
                    )}
                  </li>
                ))}
              </ul>
            )}
          </CardBody>
        </Card>

        <Card className="h-fit">
          <CardHeader title="Preferences" />
          <CardBody>
            {prefs && (
              <ul className="space-y-3">
                {PREF_LABELS.map(({ key, label }) => (
                  <li key={key} className="flex items-center justify-between text-sm">
                    <span className="text-on-surface-variant">{label}</span>
                    <button
                      onClick={() => togglePref(key)}
                      className={`h-5 w-9 rounded-full transition-colors ${prefs[key] ? "bg-secondary" : "bg-outline-variant"}`}
                    >
                      <span
                        className={`block h-4 w-4 translate-y-0.5 rounded-full bg-white transition-transform ${
                          prefs[key] ? "translate-x-4" : "translate-x-0.5"
                        }`}
                      />
                    </button>
                  </li>
                ))}
              </ul>
            )}
          </CardBody>
        </Card>
      </div>
    </div>
  );
}
