import { useEffect, useState } from "react";
import { useParams } from "react-router-dom";
import { api } from "@/lib/api";
import type { ChecklistItem } from "@/types";
import { Card, CardBody, CardHeader } from "@/components/Card";
import { ChecklistStamp, ConfidenceStamp } from "@/components/StatusStamp";
import { TenderSubNav } from "@/components/TenderSubNav";
import { Icon } from "@/components/Icon";

const MANDATORY_TYPES = new Set(["mandatory_document", "eligibility"]);

export function ComplianceMatrixPage() {
  const { tenderId } = useParams<{ tenderId: string }>();
  const [items, setItems] = useState<ChecklistItem[]>([]);
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    if (!tenderId) return;
    api
      .get<ChecklistItem[]>(`/api/v1/tenders/${tenderId}/checklist`)
      .then(setItems)
      .finally(() => setIsLoading(false));
  }, [tenderId]);

  async function toggle(item: ChecklistItem) {
    if (!tenderId) return;
    const nextStatus = item.status === "complete" ? "missing" : "complete";
    const updated = await api.patch<ChecklistItem>(`/api/v1/tenders/${tenderId}/checklist/${item.id}`, {
      status: nextStatus,
    });
    setItems((prev) => prev.map((c) => (c.id === updated.id ? updated : c)));
  }

  if (!tenderId) return null;

  const completeCount = items.filter((i) => i.status === "complete").length;

  return (
    <div className="mx-auto max-w-5xl">
      <h1 className="font-display text-2xl font-semibold text-on-surface">Compliance Matrix</h1>
      <div className="mt-6">
        <TenderSubNav tenderId={tenderId} />
      </div>

      <div className="mt-6">
        <Card>
          <CardHeader
            title="Requirement compliance"
            subtitle={items.length > 0 ? `${completeCount} of ${items.length} complete` : undefined}
          />
          <CardBody className="!p-0">
            {isLoading ? (
              <p className="p-5 text-sm text-muted">Loading…</p>
            ) : items.length === 0 ? (
              <p className="p-5 text-sm text-muted">
                No checklist items yet — run analysis from the tender's Overview tab first.
              </p>
            ) : (
              <table className="w-full text-sm">
                <thead>
                  <tr className="border-b border-border-subtle text-left text-muted">
                    <th className="px-5 py-3 font-medium">Requirement</th>
                    <th className="px-5 py-3 font-medium">Mandatory</th>
                    <th className="px-5 py-3 font-medium">AI Confidence</th>
                    <th className="px-5 py-3 font-medium">Source</th>
                    <th className="px-5 py-3 font-medium">Status</th>
                  </tr>
                </thead>
                <tbody>
                  {items.map((item) => (
                    <tr key={item.id} className="border-b border-border-subtle last:border-0">
                      <td className="px-5 py-3 text-on-surface">{item.label}</td>
                      <td className="px-5 py-3 text-on-surface-variant">
                        {item.requirement_type && MANDATORY_TYPES.has(item.requirement_type) ? (
                          <Icon name="check" size={18} className="text-status-success" />
                        ) : (
                          "—"
                        )}
                      </td>
                      <td className="px-5 py-3">
                        {item.confidence ? <ConfidenceStamp level={item.confidence} /> : "—"}
                      </td>
                      <td className="px-5 py-3 text-xs text-muted">
                        {item.evidence_page_number ? `p.${item.evidence_page_number}` : "—"}
                      </td>
                      <td className="px-5 py-3">
                        <button onClick={() => toggle(item)}>
                          <ChecklistStamp status={item.status} />
                        </button>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            )}
          </CardBody>
        </Card>
      </div>
    </div>
  );
}
