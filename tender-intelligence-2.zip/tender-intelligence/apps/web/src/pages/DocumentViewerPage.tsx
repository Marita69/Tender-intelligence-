import { useEffect, useMemo, useState } from "react";
import { Link, useParams, useSearchParams } from "react-router-dom";
import { api } from "@/lib/api";
import type { Requirement, TenderAnalysis, TenderDocument } from "@/types";
import { Card, CardBody, CardHeader } from "@/components/Card";
import { TenderSubNav } from "@/components/TenderSubNav";
import { Icon } from "@/components/Icon";

/**
 * Practical scope, documented in PAGES.md: this renders the PDF via the
 * browser's native viewer (an <iframe> with a #page= fragment) rather than
 * a custom canvas-based renderer with pixel-level highlight overlays on
 * the exact quoted span. Evidence citations still deep-link to the right
 * page and show the quoted text in a side panel — clicking one jumps the
 * iframe to that page — which covers the actual need (verify a fact
 * against its source) without a bespoke PDF rendering engine.
 *
 * The file is fetched via the authenticated api.getBlob() and rendered
 * from a blob: URL, not a direct <iframe src="/api/..."> — the download
 * endpoint requires a Bearer token, which a plain <iframe> has no way to
 * attach, so pointing it at the API URL directly would just 401.
 */
export function DocumentViewerPage() {
  const { tenderId, documentId } = useParams<{ tenderId: string; documentId: string }>();
  const [searchParams] = useSearchParams();
  const [documents, setDocuments] = useState<TenderDocument[]>([]);
  const [analysis, setAnalysis] = useState<TenderAnalysis | null>(null);
  const [page, setPage] = useState<number>(Number(searchParams.get("page")) || 1);
  const [blobUrl, setBlobUrl] = useState<string | null>(null);

  useEffect(() => {
    if (!tenderId) return;
    api.get<TenderDocument[]>(`/api/v1/tenders/${tenderId}/documents`).then(setDocuments);
    api
      .get<TenderAnalysis>(`/api/v1/tenders/${tenderId}/analysis`)
      .then(setAnalysis)
      .catch(() => setAnalysis(null));
  }, [tenderId]);

  useEffect(() => {
    const p = Number(searchParams.get("page"));
    if (p) setPage(p);
  }, [searchParams]);

  const activeDocument = documents.find((d) => d.id === documentId) || documents[0];

  useEffect(() => {
    if (!tenderId || !activeDocument) return;
    let currentUrl: string | null = null;
    api.getBlob(`/api/v1/tenders/${tenderId}/documents/${activeDocument.id}/download`).then((blob) => {
      currentUrl = URL.createObjectURL(blob);
      setBlobUrl(currentUrl);
    });
    return () => {
      if (currentUrl) URL.revokeObjectURL(currentUrl);
    };
  }, [tenderId, activeDocument]);

  const evidenceForDocument = useMemo(() => {
    if (!analysis || !activeDocument) return [];
    const rows: { requirement: Requirement; page: number; quote: string }[] = [];
    for (const req of analysis.requirements) {
      for (const ev of req.evidence) {
        if (ev.document_id === activeDocument.id) {
          rows.push({ requirement: req, page: ev.page_number, quote: ev.quoted_text });
        }
      }
    }
    return rows.sort((a, b) => a.page - b.page);
  }, [analysis, activeDocument]);

  if (!tenderId) return null;

  const viewerUrl = blobUrl ? `${blobUrl}#page=${page}` : null;

  return (
    <div className="mx-auto max-w-6xl">
      <h1 className="font-display text-2xl font-semibold text-on-surface">Document Viewer</h1>
      <div className="mt-6">
        <TenderSubNav tenderId={tenderId} />
      </div>

      <div className="mt-6 grid grid-cols-1 gap-6 lg:grid-cols-[220px_1fr_320px]">
        <Card className="h-fit">
          <CardHeader title="Documents" />
          <CardBody className="!p-2">
            <ul className="space-y-1">
              {documents.map((doc) => (
                <li key={doc.id}>
                  <Link
                    to={`/app/tenders/${tenderId}/documents/${doc.id}`}
                    className={`block truncate rounded-md px-2 py-1.5 text-xs ${
                      activeDocument?.id === doc.id
                        ? "bg-secondary-container text-on-secondary-container"
                        : "text-on-surface-variant hover:bg-surface-container-low"
                    }`}
                    title={doc.original_filename}
                  >
                    {doc.original_filename}
                  </Link>
                </li>
              ))}
            </ul>
          </CardBody>
        </Card>

        <Card className="min-h-[70vh]">
          <CardBody className="!p-0">
            {viewerUrl ? (
              <iframe title="Document preview" src={viewerUrl} className="h-[75vh] w-full rounded-lg" />
            ) : (
              <p className="p-6 text-sm text-muted">No documents to display.</p>
            )}
          </CardBody>
        </Card>

        <Card className="h-fit">
          <CardHeader title="Cited evidence" subtitle={`${evidenceForDocument.length} citation(s) in this file`} />
          <CardBody className="!p-0">
            {evidenceForDocument.length === 0 ? (
              <p className="p-4 text-sm text-muted">No extracted requirements cite this document.</p>
            ) : (
              <ul className="divide-y divide-border-subtle">
                {evidenceForDocument.map((row, idx) => (
                  <li key={idx} className="p-3">
                    <button
                      onClick={() => setPage(row.page)}
                      className="flex items-center gap-1 text-xs font-semibold text-secondary hover:underline"
                    >
                      <Icon name="bookmark" size={14} /> Page {row.page}
                    </button>
                    <p className="mt-1 text-xs text-on-surface-variant">{row.requirement.summary}</p>
                    <p className="mt-1 text-xs italic text-muted">"{row.quote.slice(0, 140)}"</p>
                  </li>
                ))}
              </ul>
            )}
          </CardBody>
        </Card>
      </div>
    </div>
  );
}
