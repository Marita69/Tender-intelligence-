import { useEffect, useRef, useState } from "react";
import { api, ApiError } from "@/lib/api";
import type { CompanyDocument, CompanyProfile } from "@/types";
import { Card, CardBody, CardHeader } from "@/components/Card";
import { Button } from "@/components/Button";
import { Icon } from "@/components/Icon";

const EMPTY: CompanyProfile = {
  id: "",
  legal_name: "",
  registration_number: "",
  years_in_operation: null,
  sectors: [],
  certifications: [],
  annual_turnover_band: "",
  financial_capacity_notes: "",
};

export function CompanyProfilePage() {
  const [profile, setProfile] = useState<CompanyProfile>(EMPTY);
  const [isSaving, setIsSaving] = useState(false);
  const [savedMessage, setSavedMessage] = useState<string | null>(null);

  useEffect(() => {
    api
      .get<CompanyProfile>("/api/v1/company-profile")
      .then(setProfile)
      .catch((err) => {
        if (!(err instanceof ApiError && err.status === 404)) throw err;
      });
  }, []);

  async function handleSave(e: React.FormEvent) {
    e.preventDefault();
    setIsSaving(true);
    setSavedMessage(null);
    try {
      const saved = await api.put<CompanyProfile>("/api/v1/company-profile", {
        legal_name: profile.legal_name,
        registration_number: profile.registration_number || null,
        years_in_operation: profile.years_in_operation,
        sectors: profile.sectors,
        certifications: profile.certifications,
        annual_turnover_band: profile.annual_turnover_band || null,
        financial_capacity_notes: profile.financial_capacity_notes || null,
      });
      setProfile(saved);
      setSavedMessage("Saved.");
    } finally {
      setIsSaving(false);
    }
  }

  return (
    <div className="mx-auto max-w-2xl">
      <h1 className="font-display text-2xl font-semibold text-on-surface">Company profile</h1>
      <p className="mt-1 text-sm text-muted">
        Used to compare tender requirements against what your company can demonstrate for bid/no-bid scoring.
      </p>

      <Card className="mt-6">
        <CardHeader title="Details" />
        <CardBody>
          <form onSubmit={handleSave} className="space-y-4">
            <div>
              <label className="block text-sm font-medium text-on-surface-variant">Legal company name</label>
              <input
                required
                value={profile.legal_name}
                onChange={(e) => setProfile({ ...profile, legal_name: e.target.value })}
                className="mt-1 w-full rounded-md border border-outline-variant px-3 py-2 text-sm focus:border-secondary focus:outline-none focus:ring-1 focus:ring-secondary"
              />
            </div>
            <div className="grid grid-cols-2 gap-4">
              <div>
                <label className="block text-sm font-medium text-on-surface-variant">Registration number</label>
                <input
                  value={profile.registration_number || ""}
                  onChange={(e) => setProfile({ ...profile, registration_number: e.target.value })}
                  className="mt-1 w-full rounded-md border border-outline-variant px-3 py-2 text-sm focus:border-secondary focus:outline-none focus:ring-1 focus:ring-secondary"
                />
              </div>
              <div>
                <label className="block text-sm font-medium text-on-surface-variant">Years in operation</label>
                <input
                  type="number"
                  min={0}
                  value={profile.years_in_operation ?? ""}
                  onChange={(e) =>
                    setProfile({ ...profile, years_in_operation: e.target.value ? Number(e.target.value) : null })
                  }
                  className="mt-1 w-full rounded-md border border-outline-variant px-3 py-2 text-sm focus:border-secondary focus:outline-none focus:ring-1 focus:ring-secondary"
                />
              </div>
            </div>
            <div>
              <label className="block text-sm font-medium text-on-surface-variant">Sectors (comma-separated)</label>
              <input
                value={profile.sectors.join(", ")}
                onChange={(e) =>
                  setProfile({ ...profile, sectors: e.target.value.split(",").map((s) => s.trim()).filter(Boolean) })
                }
                className="mt-1 w-full rounded-md border border-outline-variant px-3 py-2 text-sm focus:border-secondary focus:outline-none focus:ring-1 focus:ring-secondary"
              />
            </div>
            <div>
              <label className="block text-sm font-medium text-on-surface-variant">Certifications (comma-separated)</label>
              <input
                value={profile.certifications.join(", ")}
                onChange={(e) =>
                  setProfile({
                    ...profile,
                    certifications: e.target.value.split(",").map((s) => s.trim()).filter(Boolean),
                  })
                }
                className="mt-1 w-full rounded-md border border-outline-variant px-3 py-2 text-sm focus:border-secondary focus:outline-none focus:ring-1 focus:ring-secondary"
              />
            </div>
            <div>
              <label className="block text-sm font-medium text-on-surface-variant">Annual turnover band</label>
              <input
                value={profile.annual_turnover_band || ""}
                onChange={(e) => setProfile({ ...profile, annual_turnover_band: e.target.value })}
                placeholder="e.g. $1M–$5M"
                className="mt-1 w-full rounded-md border border-outline-variant px-3 py-2 text-sm focus:border-secondary focus:outline-none focus:ring-1 focus:ring-secondary"
              />
            </div>
            <div>
              <label className="block text-sm font-medium text-on-surface-variant">Financial capacity notes</label>
              <textarea
                rows={3}
                value={profile.financial_capacity_notes || ""}
                onChange={(e) => setProfile({ ...profile, financial_capacity_notes: e.target.value })}
                className="mt-1 w-full rounded-md border border-outline-variant px-3 py-2 text-sm focus:border-secondary focus:outline-none focus:ring-1 focus:ring-secondary"
              />
            </div>
            {savedMessage && <p className="text-sm text-secondary">{savedMessage}</p>}
            <Button type="submit" disabled={isSaving}>
              {isSaving ? "Saving…" : "Save profile"}
            </Button>
          </form>
        </CardBody>
      </Card>

      <DocumentLibrary />
    </div>
  );
}

function DocumentLibrary() {
  const [docs, setDocs] = useState<CompanyDocument[]>([]);
  const [isUploading, setIsUploading] = useState(false);
  const [form, setForm] = useState({ name: "", category: "legal", issuing_body: "", expiry_date: "" });
  const fileInputRef = useRef<HTMLInputElement>(null);
  const [pendingFile, setPendingFile] = useState<File | null>(null);
  const [error, setError] = useState<string | null>(null);

  async function load() {
    const result = await api.get<CompanyDocument[]>("/api/v1/company-documents");
    setDocs(result);
  }

  useEffect(() => {
    load();
  }, []);

  function pickFile() {
    fileInputRef.current?.click();
  }

  function handleFileChosen(e: React.ChangeEvent<HTMLInputElement>) {
    const file = e.target.files?.[0];
    if (file) {
      setPendingFile(file);
      setForm((f) => ({ ...f, name: f.name || file.name }));
    }
  }

  async function handleUpload(e: React.FormEvent) {
    e.preventDefault();
    if (!pendingFile) return;
    setError(null);
    setIsUploading(true);
    try {
      await api.uploadWithFields<CompanyDocument>("/api/v1/company-documents", pendingFile, {
        name: form.name || pendingFile.name,
        category: form.category,
        issuing_body: form.issuing_body,
        expiry_date: form.expiry_date,
      });
      setPendingFile(null);
      setForm({ name: "", category: "legal", issuing_body: "", expiry_date: "" });
      if (fileInputRef.current) fileInputRef.current.value = "";
      await load();
    } catch (err) {
      setError(err instanceof ApiError ? err.message : "Upload failed");
    } finally {
      setIsUploading(false);
    }
  }

  async function handleDelete(id: string) {
    await api.delete(`/api/v1/company-documents/${id}`);
    setDocs((prev) => prev.filter((d) => d.id !== id));
  }

  async function handleDownload(doc: CompanyDocument) {
    const blob = await api.getBlob(`/api/v1/company-documents/${doc.id}/download`);
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = doc.original_filename;
    a.click();
    URL.revokeObjectURL(url);
  }

  return (
    <Card className="mt-6">
      <CardHeader
        title="Document library"
        subtitle="Reusable compliance evidence — registration certificates, tax clearance, ISO certifications — that can back checklist items across every tender."
      />
      <CardBody>
        <form onSubmit={handleUpload} className="mb-6 flex flex-wrap items-end gap-3 border-b border-border-subtle pb-6">
          <input ref={fileInputRef} type="file" className="hidden" onChange={handleFileChosen} />
          <Button type="button" variant="secondary" onClick={pickFile}>
            <Icon name="upload_file" size={18} /> {pendingFile ? pendingFile.name : "Choose file"}
          </Button>
          <div>
            <label className="block text-xs font-medium text-on-surface-variant">Name</label>
            <input
              value={form.name}
              onChange={(e) => setForm({ ...form, name: e.target.value })}
              className="mt-1 rounded-md border border-outline-variant px-2 py-1.5 text-sm"
              placeholder="Tax Clearance Certificate"
            />
          </div>
          <div>
            <label className="block text-xs font-medium text-on-surface-variant">Category</label>
            <select
              value={form.category}
              onChange={(e) => setForm({ ...form, category: e.target.value })}
              className="mt-1 rounded-md border border-outline-variant px-2 py-1.5 text-sm"
            >
              <option value="legal">Legal</option>
              <option value="financial">Financial</option>
              <option value="certification">Certification</option>
              <option value="other">Other</option>
            </select>
          </div>
          <div>
            <label className="block text-xs font-medium text-on-surface-variant">Expiry date</label>
            <input
              type="date"
              value={form.expiry_date}
              onChange={(e) => setForm({ ...form, expiry_date: e.target.value })}
              className="mt-1 rounded-md border border-outline-variant px-2 py-1.5 text-sm"
            />
          </div>
          <Button type="submit" disabled={!pendingFile || isUploading}>
            {isUploading ? "Uploading…" : "Add to library"}
          </Button>
        </form>
        {error && <p className="mb-3 text-sm text-status-danger">{error}</p>}

        {docs.length === 0 ? (
          <p className="text-sm text-muted">No documents in the library yet.</p>
        ) : (
          <ul className="divide-y divide-border-subtle">
            {docs.map((doc) => (
              <li key={doc.id} className="flex items-center justify-between py-3 text-sm">
                <div>
                  <p className="font-medium text-on-surface">{doc.name}</p>
                  <p className="text-xs text-muted">
                    {doc.category} {doc.expiry_date ? `· expires ${doc.expiry_date}` : ""}
                  </p>
                </div>
                <div className="flex items-center gap-3">
                  <CompanyDocumentStamp status={doc.status} />
                  <button onClick={() => handleDownload(doc)} className="text-muted hover:text-secondary">
                    <Icon name="download" size={18} />
                  </button>
                  <button onClick={() => handleDelete(doc.id)} className="text-muted hover:text-status-danger">
                    <Icon name="delete" size={18} />
                  </button>
                </div>
              </li>
            ))}
          </ul>
        )}
      </CardBody>
    </Card>
  );
}

function CompanyDocumentStamp({ status }: { status: CompanyDocument["status"] }) {
  const map: Record<CompanyDocument["status"], string> = {
    valid: "stamp-complete",
    expiring_soon: "stamp-progress",
    expired: "stamp-missing",
    no_expiry: "stamp-na",
  };
  const label: Record<CompanyDocument["status"], string> = {
    valid: "Valid",
    expiring_soon: "Expiring soon",
    expired: "Expired",
    no_expiry: "No expiry",
  };
  return <span className={map[status]}>{label[status]}</span>;
}
