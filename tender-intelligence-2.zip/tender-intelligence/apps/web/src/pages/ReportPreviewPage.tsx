import { useEffect, useState } from "react";
import { useParams } from "react-router-dom";
import { api } from "@/lib/api";
import type { Tender, TenderAnalysis } from "@/types";
import { Card, CardBody } from "@/components/Card";
import { Button } from "@/components/Button";
import { ConfidenceStamp } from "@/components/StatusStamp";
import { TenderSubNav } from "@/components/TenderSubNav";

const RECOMMENDATION_LABEL: Record<string, string> = {
  bid: "Bid",
  conditional_bid: "Conditional Bid",
  no_bid: "No Bid",
  insufficient_information: "Insufficient Information",
};

export function ReportPreviewPage() {
  const { tenderId } = useParams<{ tenderId: string }>();
  const [tender, setTender] = useState<Tender | null>(null);
  const [analysis, setAnalysis] = useState<TenderAnalysis | null>(null);

  useEffect(() => {
    if (!tenderId) return;
    api.get<Tender>(`/api/v1/tenders/${tenderId}`).then(setTender);
    api
      .get<TenderAnalysis>(`/api/v1/tenders/${tenderId}/analysis`)
      .then(setAnalysis)
      .catch(() => setAnalysis(null));
  }, [tenderId]);

  async function download(format: "pdf" | "docx") {
    if (!tenderId) return;
    const blob = await api.getBlob(`/api/v1/tenders/${tenderId}/reports/${format}`);
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = `tender-analysis.${format}`;
    a.click();
    URL.revokeObjectURL(url);
  }

  if (!tenderId || !tender) return <p className="text-sm text-muted">Loading…</p>;

  return (
    <div className="mx-auto max-w-4xl">
      <div className="flex items-center justify-between">
        <h1 className="font-display text-2xl font-semibold text-on-surface">Analysis Report</h1>
        <div className="flex gap-2">
          <Button variant="secondary" onClick={() => download("docx")}>
            Export DOCX
          </Button>
          <Button onClick={() => download("pdf")}>Export PDF</Button>
        </div>
      </div>
      <div className="mt-6">
        <TenderSubNav tenderId={tenderId} />
      </div>

      {!analysis ? (
        <Card className="mt-6">
          <CardBody>
            <p className="text-sm text-muted">No analysis available yet for this tender.</p>
          </CardBody>
        </Card>
      ) : (
        <div className="mt-6 space-y-6 rounded-lg border border-border-subtle bg-surface-container-lowest p-10 shadow-sm">
          {/* Styled to look like the exported document itself, per the
              "Tender Analysis Report Preview" Stitch design -- a print-like
              page rather than another dashboard card. */}
          <div className="border-b border-border-subtle pb-6 text-center">
            <p className="text-xs uppercase tracking-widest text-muted">Tender Analysis Report</p>
            <h2 className="mt-2 font-display text-3xl font-semibold text-on-surface">{tender.title}</h2>
            {tender.reference_number && <p className="mt-1 text-sm text-muted">Reference: {tender.reference_number}</p>}
            {tender.issuing_entity && <p className="text-sm text-muted">{tender.issuing_entity}</p>}
          </div>

          <div>
            <h3 className="font-display text-lg font-semibold text-on-surface">Executive Summary</h3>
            {analysis.bid_assessment ? (
              <>
                <div className="mt-2 flex items-center gap-4">
                  <span className="stamp-complete">{RECOMMENDATION_LABEL[analysis.bid_assessment.recommendation]}</span>
                  <span className="text-sm text-muted">Score: {analysis.bid_assessment.score.toFixed(0)}/100</span>
                  <ConfidenceStamp level={analysis.bid_assessment.confidence} />
                </div>
                <p className="mt-3 text-sm leading-relaxed text-on-surface-variant">{analysis.bid_assessment.rationale}</p>
              </>
            ) : (
              <p className="mt-2 text-sm text-muted">No bid assessment available.</p>
            )}
          </div>

          <div>
            <h3 className="font-display text-lg font-semibold text-on-surface">Key Findings</h3>
            <table className="mt-3 w-full text-sm">
              <thead>
                <tr className="border-b border-border-subtle text-left text-muted">
                  <th className="py-2 font-medium">Type</th>
                  <th className="py-2 font-medium">Requirement</th>
                  <th className="py-2 font-medium">Confidence</th>
                  <th className="py-2 font-medium">Source</th>
                </tr>
              </thead>
              <tbody>
                {analysis.requirements.slice(0, 30).map((req) => (
                  <tr key={req.id} className="border-b border-border-subtle last:border-0">
                    <td className="py-2 capitalize text-on-surface-variant">{req.type.replace(/_/g, " ")}</td>
                    <td className="py-2 text-on-surface">{req.summary}</td>
                    <td className="py-2">
                      <ConfidenceStamp level={req.confidence} />
                    </td>
                    <td className="py-2 text-xs text-muted">
                      {req.evidence[0] ? `p.${req.evidence[0].page_number}` : "Unverified / inferred"}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>

          {analysis.risks.length > 0 && (
            <div>
              <h3 className="font-display text-lg font-semibold text-on-surface">Risks &amp; Disqualifying Clauses</h3>
              <ul className="mt-3 space-y-2">
                {analysis.risks.map((risk) => (
                  <li key={risk.id} className="text-sm">
                    <span className={risk.is_disqualifying ? "stamp-missing" : "stamp-progress"}>
                      {risk.is_disqualifying ? "Disqualifying" : risk.severity}
                    </span>
                    <span className="ml-2 font-medium text-on-surface">{risk.title}</span>
                    <p className="text-on-surface-variant">{risk.description}</p>
                  </li>
                ))}
              </ul>
            </div>
          )}

          <p className="border-t border-border-subtle pt-4 text-center text-xs text-muted">
            Decision-support analysis. Verify against source documents before submission.
          </p>
        </div>
      )}
    </div>
  );
}
