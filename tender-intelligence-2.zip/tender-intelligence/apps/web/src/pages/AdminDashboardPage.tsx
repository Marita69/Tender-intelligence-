import { useEffect, useState } from "react";
import { api, ApiError } from "@/lib/api";
import type { AdminOrganization, AdminStats, AdminSystemLog, AdminTelemetry, AIProviderName, AIProviderSetting, AIProviderTestResult } from "@/types";
import { Card, CardBody, CardHeader } from "@/components/Card";
import { Button } from "@/components/Button";
import { Icon } from "@/components/Icon";

const PROVIDER_OPTIONS: { value: AIProviderName; label: string; hint: string; modelSuggestions: string[] }[] = [
  {
    value: "mock",
    label: "Mock (no API key needed)",
    hint: "Heuristic-only, for testing the pipeline without cost.",
    modelSuggestions: ["mock-v1"],
  },
  {
    value: "anthropic",
    label: "Anthropic",
    hint: "Requires ANTHROPIC_API_KEY.",
    modelSuggestions: ["claude-sonnet-4-6", "claude-opus-4-8", "claude-haiku-4-5-20251001"],
  },
  {
    value: "openrouter",
    label: "OpenRouter",
    hint: "Aggregates many providers behind one key; \":free\" models cost nothing. Requires OPENROUTER_API_KEY.",
    modelSuggestions: [
      "meta-llama/llama-3.3-70b-instruct:free",
      "google/gemini-2.0-flash-exp:free",
      "deepseek/deepseek-r1:free",
      "deepseek/deepseek-chat:free",
      "qwen/qwen-2.5-72b-instruct:free",
    ],
  },
  {
    value: "nvidia",
    label: "NVIDIA NIM",
    hint: "NVIDIA's hosted inference API, free evaluation tier. Requires NVIDIA_API_KEY.",
    modelSuggestions: ["meta/llama-3.1-70b-instruct", "meta/llama-3.1-405b-instruct", "mistralai/mixtral-8x22b-instruct-v0.1"],
  },
  {
    value: "gemini",
    label: "Google Gemini",
    hint: "Via Google's OpenAI-compatible endpoint. Free tier available. Requires GEMINI_API_KEY.",
    modelSuggestions: ["gemini-2.0-flash", "gemini-1.5-flash", "gemini-1.5-pro"],
  },
  {
    value: "deepseek",
    label: "DeepSeek",
    hint: "Low-cost direct API (not free, but cheap). Requires DEEPSEEK_API_KEY.",
    modelSuggestions: ["deepseek-chat", "deepseek-reasoner"],
  },
];

const STAT_LABELS: { key: keyof AdminStats; label: string; icon: string }[] = [
  { key: "organizations", label: "Organizations", icon: "corporate_fare" },
  { key: "users", label: "Users", icon: "group" },
  { key: "active_tenders", label: "Active tenders", icon: "folder_open" },
  { key: "documents_processed", label: "Documents processed", icon: "description" },
  { key: "analysis_jobs_succeeded", label: "Analyses succeeded", icon: "check_circle" },
  { key: "analysis_jobs_failed", label: "Analyses failed", icon: "error" },
];

const LOG_LEVEL_ICON: Record<string, string> = { info: "info", warning: "warning", error: "error" };
const LOG_LEVEL_CLASS: Record<string, string> = {
  info: "text-status-info",
  warning: "text-status-warning",
  error: "text-status-danger",
};

export function AdminDashboardPage() {
  const [stats, setStats] = useState<AdminStats | null>(null);
  const [telemetry, setTelemetry] = useState<AdminTelemetry | null>(null);
  const [orgs, setOrgs] = useState<AdminOrganization[]>([]);
  const [logs, setLogs] = useState<AdminSystemLog[]>([]);
  const [aiSetting, setAiSetting] = useState<AIProviderSetting | null>(null);
  const [aiForm, setAiForm] = useState<{ provider: AIProviderName; model: string }>({ provider: "mock", model: "" });
  const [isSavingAi, setIsSavingAi] = useState(false);
  const [testResult, setTestResult] = useState<AIProviderTestResult | null>(null);
  const [isTesting, setIsTesting] = useState(false);
  const [aiError, setAiError] = useState<string | null>(null);

  async function load() {
    const [s, t, o, l, ai] = await Promise.all([
      api.get<AdminStats>("/api/v1/admin/stats"),
      api.get<AdminTelemetry>("/api/v1/admin/telemetry"),
      api.get<{ items: AdminOrganization[] }>("/api/v1/admin/organizations?page=1&page_size=20"),
      api.get<AdminSystemLog[]>("/api/v1/admin/system-logs?limit=30"),
      api.get<AIProviderSetting>("/api/v1/admin/ai-provider"),
    ]);
    setStats(s);
    setTelemetry(t);
    setOrgs(o.items);
    setLogs(l);
    setAiSetting(ai);
    setAiForm({ provider: ai.provider, model: ai.model });
  }

  useEffect(() => {
    load();
  }, []);

  async function toggleSuspend(org: AdminOrganization) {
    const updated = await api.post<AdminOrganization>(`/api/v1/admin/organizations/${org.id}/suspend`, {
      is_suspended: !org.is_suspended,
    });
    setOrgs((prev) => prev.map((o) => (o.id === updated.id ? updated : o)));
  }

  async function saveAiProvider(e: React.FormEvent) {
    e.preventDefault();
    setIsSavingAi(true);
    setAiError(null);
    setTestResult(null);
    try {
      const updated = await api.put<AIProviderSetting>("/api/v1/admin/ai-provider", aiForm);
      setAiSetting(updated);
    } catch (err) {
      setAiError(err instanceof ApiError ? err.message : "Could not save AI provider settings");
    } finally {
      setIsSavingAi(false);
    }
  }

  async function testAiProvider() {
    setIsTesting(true);
    setTestResult(null);
    try {
      const result = await api.post<AIProviderTestResult>("/api/v1/admin/ai-provider/test");
      setTestResult(result);
    } finally {
      setIsTesting(false);
    }
  }

  return (
    <div className="mx-auto max-w-6xl">
      <h1 className="font-display text-2xl font-semibold text-on-surface">Platform Admin</h1>
      <p className="mt-1 text-sm text-muted">
        Visible only to the account matching ADMIN_EMAIL. Every route here is independently gated server-side.
      </p>

      {stats && (
        <div className="mt-6 grid grid-cols-2 gap-4 lg:grid-cols-3">
          {STAT_LABELS.map(({ key, label, icon }) => (
            <Card key={key}>
              <CardBody>
                <div className="flex items-center gap-3">
                  <Icon name={icon} className="text-secondary" />
                  <div>
                    <p className="font-display text-2xl font-semibold text-on-surface">{stats[key]}</p>
                    <p className="text-sm text-muted">{label}</p>
                  </div>
                </div>
              </CardBody>
            </Card>
          ))}
        </div>
      )}

      {telemetry && (
        <Card className="mt-6">
          <CardHeader title="24h processing telemetry" subtitle="No cost estimate shown — see PAGES.md for why." />
          <CardBody>
            <div className="grid grid-cols-3 gap-4 text-sm">
              <div>
                <p className="text-muted">Jobs run</p>
                <p className="font-display text-xl font-semibold text-on-surface">{telemetry.jobs_last_24h}</p>
              </div>
              <div>
                <p className="text-muted">Tokens consumed</p>
                <p className="font-display text-xl font-semibold text-on-surface">{telemetry.tokens_last_24h.toLocaleString()}</p>
              </div>
              <div>
                <p className="text-muted">Avg pipeline duration</p>
                <p className="font-display text-xl font-semibold text-on-surface">
                  {telemetry.avg_pipeline_seconds !== null ? `${telemetry.avg_pipeline_seconds.toFixed(1)}s` : "—"}
                </p>
              </div>
            </div>
          </CardBody>
        </Card>
      )}

      <Card className="mt-6">
        <CardHeader
          title="AI Provider"
          subtitle={
            aiSetting
              ? aiSetting.is_override_active
                ? `Admin override active${aiSetting.updated_at ? ` — last changed ${new Date(aiSetting.updated_at).toLocaleString()}` : ""}`
                : "Using the .env default — no admin override saved yet"
              : undefined
          }
        />
        <CardBody>
          <form onSubmit={saveAiProvider} className="flex flex-wrap items-end gap-3">
            <div>
              <label className="block text-xs font-medium text-on-surface-variant">Provider</label>
              <select
                value={aiForm.provider}
                onChange={(e) => {
                  const provider = e.target.value as AIProviderName;
                  const suggestions = PROVIDER_OPTIONS.find((o) => o.value === provider)?.modelSuggestions ?? [];
                  setAiForm({ provider, model: suggestions[0] ?? "" });
                }}
                className="mt-1 rounded-md border border-outline-variant bg-surface-container-lowest px-2 py-1.5 text-sm"
              >
                {PROVIDER_OPTIONS.map((opt) => (
                  <option key={opt.value} value={opt.value}>
                    {opt.label}
                  </option>
                ))}
              </select>
            </div>
            <div className="flex-1">
              <label className="block text-xs font-medium text-on-surface-variant">Model</label>
              <input
                list="ai-model-suggestions"
                value={aiForm.model}
                onChange={(e) => setAiForm({ ...aiForm, model: e.target.value })}
                placeholder="Pick a suggestion or type any model id"
                className="mt-1 w-full rounded-md border border-outline-variant bg-surface-container-lowest px-2 py-1.5 text-sm"
              />
              <datalist id="ai-model-suggestions">
                {(PROVIDER_OPTIONS.find((o) => o.value === aiForm.provider)?.modelSuggestions ?? []).map((m) => (
                  <option key={m} value={m} />
                ))}
              </datalist>
            </div>
            <Button type="submit" disabled={isSavingAi}>
              {isSavingAi ? "Saving…" : "Save"}
            </Button>
            <Button type="button" variant="secondary" onClick={testAiProvider} disabled={isTesting}>
              {isTesting ? "Testing…" : "Test connection"}
            </Button>
          </form>
          <p className="mt-2 text-xs text-muted">
            {PROVIDER_OPTIONS.find((o) => o.value === aiForm.provider)?.hint} Takes effect on the next analysis run —
            no restart needed. API keys themselves are set via environment variables, not here (see PRODUCTION_GUIDE.md).
          </p>
          {aiError && <p className="mt-2 text-sm text-status-danger">{aiError}</p>}
          {testResult && (
            <p className={`mt-2 text-sm ${testResult.success ? "text-status-success" : "text-status-danger"}`}>
              {testResult.message}
              {testResult.sample_output && ` — "${testResult.sample_output}"`}
            </p>
          )}
        </CardBody>
      </Card>

      <Card className="mt-6">
        <CardHeader title="Organization directory" />
        <CardBody className="!p-0">
          <table className="w-full text-sm">
            <thead>
              <tr className="border-b border-border-subtle text-left text-muted">
                <th className="px-5 py-3 font-medium">Organization</th>
                <th className="px-5 py-3 font-medium">Plan</th>
                <th className="px-5 py-3 font-medium">Members</th>
                <th className="px-5 py-3 font-medium">Tenders</th>
                <th className="px-5 py-3 font-medium">Credits</th>
                <th className="px-5 py-3 font-medium">Last activity</th>
                <th className="px-5 py-3 font-medium">Status</th>
                <th className="px-5 py-3 font-medium"></th>
              </tr>
            </thead>
            <tbody>
              {orgs.map((org) => (
                <tr key={org.id} className="border-b border-border-subtle last:border-0">
                  <td className="px-5 py-3 font-medium text-on-surface">{org.name}</td>
                  <td className="px-5 py-3 capitalize text-on-surface-variant">{org.plan}</td>
                  <td className="px-5 py-3 text-on-surface-variant">{org.member_count}</td>
                  <td className="px-5 py-3 text-on-surface-variant">{org.tender_count}</td>
                  <td className="px-5 py-3 text-on-surface-variant">{org.credit_balance}</td>
                  <td className="px-5 py-3 text-xs text-muted">
                    {org.last_activity_at ? new Date(org.last_activity_at).toLocaleDateString() : "—"}
                  </td>
                  <td className="px-5 py-3">
                    <span className={org.is_suspended ? "stamp-missing" : "stamp-complete"}>
                      {org.is_suspended ? "Suspended" : "Active"}
                    </span>
                  </td>
                  <td className="px-5 py-3">
                    <Button variant={org.is_suspended ? "secondary" : "danger"} onClick={() => toggleSuspend(org)}>
                      {org.is_suspended ? "Unsuspend" : "Suspend"}
                    </Button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </CardBody>
      </Card>

      <Card className="mt-6">
        <CardHeader title="System logs" subtitle="Derived from the audit log — see PAGES.md for how levels are classified." />
        <CardBody className="!p-0">
          <ul className="divide-y divide-border-subtle">
            {logs.map((log) => (
              <li key={log.id} className="flex items-center gap-3 px-5 py-2.5 text-sm">
                <Icon name={LOG_LEVEL_ICON[log.level]} size={18} className={LOG_LEVEL_CLASS[log.level]} />
                <span className="font-mono text-xs text-muted">{new Date(log.created_at).toLocaleString()}</span>
                <span className="text-on-surface-variant">{log.action}</span>
                <span className="text-xs text-muted">({log.resource_type})</span>
              </li>
            ))}
          </ul>
        </CardBody>
      </Card>
    </div>
  );
}
