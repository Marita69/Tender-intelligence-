import { useEffect, useState } from "react";
import { Link, useNavigate } from "react-router-dom";
import { api } from "@/lib/api";
import type { Tender, TenderListResponse } from "@/types";
import { Card } from "@/components/Card";
import { Button } from "@/components/Button";

const STATUS_LABEL: Record<Tender["status"], string> = {
  draft: "Draft",
  processing: "Processing…",
  analyzed: "Analyzed",
  failed: "Analysis failed",
  archived: "Archived",
};

export function TendersList() {
  const navigate = useNavigate();
  const [tenders, setTenders] = useState<Tender[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const [isCreating, setIsCreating] = useState(false);
  const [newTitle, setNewTitle] = useState("");

  async function load() {
    setIsLoading(true);
    const resp = await api.get<TenderListResponse>("/api/v1/tenders");
    setTenders(resp.items);
    setIsLoading(false);
  }

  useEffect(() => {
    load();
  }, []);

  async function handleCreate(e: React.FormEvent) {
    e.preventDefault();
    if (!newTitle.trim()) return;
    const tender = await api.post<Tender>("/api/v1/tenders", { title: newTitle });
    setNewTitle("");
    setIsCreating(false);
    navigate(`/app/tenders/${tender.id}`);
  }

  return (
    <div className="mx-auto max-w-5xl">
      <div className="flex items-center justify-between">
        <h1 className="font-display text-2xl font-semibold text-on-surface">Tenders</h1>
        <Button onClick={() => setIsCreating(true)}>+ New tender</Button>
      </div>

      {isCreating && (
        <Card className="mt-4">
          <form onSubmit={handleCreate} className="flex items-center gap-3 p-4">
            <input
              autoFocus
              placeholder="Tender title, e.g. Road Maintenance Contract 2026"
              value={newTitle}
              onChange={(e) => setNewTitle(e.target.value)}
              className="flex-1 rounded-md border border-outline-variant px-3 py-2 text-sm focus:border-secondary focus:outline-none focus:ring-1 focus:ring-secondary"
            />
            <Button type="submit">Create</Button>
            <Button type="button" variant="ghost" onClick={() => setIsCreating(false)}>
              Cancel
            </Button>
          </form>
        </Card>
      )}

      <div className="mt-6">
        {isLoading ? (
          <p className="text-sm text-muted">Loading…</p>
        ) : tenders.length === 0 ? (
          <Card>
            <div className="p-10 text-center">
              <p className="text-muted">No tenders yet. Create one and upload the tender document to begin.</p>
            </div>
          </Card>
        ) : (
          <Card>
            <table className="w-full text-sm">
              <thead>
                <tr className="border-b border-border-subtle text-left text-muted">
                  <th className="px-5 py-3 font-medium">Title</th>
                  <th className="px-5 py-3 font-medium">Issuing entity</th>
                  <th className="px-5 py-3 font-medium">Deadline</th>
                  <th className="px-5 py-3 font-medium">Status</th>
                </tr>
              </thead>
              <tbody>
                {tenders.map((t) => (
                  <tr key={t.id} className="border-b border-border-subtle last:border-0 hover:bg-background">
                    <td className="px-5 py-3">
                      <Link to={`/app/tenders/${t.id}`} className="font-medium text-secondary hover:underline">
                        {t.title}
                      </Link>
                    </td>
                    <td className="px-5 py-3 text-on-surface-variant">{t.issuing_entity || "—"}</td>
                    <td className="px-5 py-3 text-on-surface-variant">
                      {t.submission_deadline
                        ? new Date(t.submission_deadline).toLocaleDateString()
                        : t.submission_deadline_is_uncertain
                          ? "Uncertain"
                          : "—"}
                    </td>
                    <td className="px-5 py-3 text-on-surface-variant">{STATUS_LABEL[t.status]}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </Card>
        )}
      </div>
    </div>
  );
}
