import { Link } from "react-router-dom";
import { Icon } from "@/components/Icon";

export function Landing() {
  return (
    <div className="min-h-screen bg-slate-950 text-slate-50">
      <header className="mx-auto flex max-w-6xl items-center justify-between px-6 py-6">
        <div className="flex items-center gap-2">
          <div className="h-6 w-6 rotate-3 rounded-sm border-2 border-teal-400" aria-hidden />
          <span className="font-display text-lg font-semibold">Tender Intelligence</span>
        </div>
        <div className="flex items-center gap-4">
          <Link to="/login" className="text-sm font-medium text-slate-300 hover:text-white">
            Log in
          </Link>
          <Link
            to="/signup"
            className="rounded-md bg-teal-600 px-4 py-2 text-sm font-medium text-white hover:bg-teal-500"
          >
            Get started
          </Link>
        </div>
      </header>

      <section className="mx-auto grid max-w-6xl grid-cols-1 items-center gap-12 px-6 py-20 lg:grid-cols-2">
        <div>
          <p className="font-display text-sm uppercase tracking-[0.2em] text-teal-400">
            Read every clause. Miss nothing.
          </p>
          <h1 className="mt-4 font-display text-5xl font-semibold leading-[1.05] tracking-tight">
            Tender documents,
            <br />
            <span className="text-teal-400">stamped &amp; sorted</span> in minutes.
          </h1>
          <p className="mt-6 max-w-md text-lg text-slate-300">
            Upload a tender. Get every eligibility rule, deadline, mandatory document, and
            disqualifying clause pulled out, cited to the exact page — plus an honest
            bid / no-bid recommendation your team can actually defend.
          </p>
          <div className="mt-8 flex gap-4">
            <Link
              to="/signup"
              className="rounded-md bg-teal-600 px-6 py-3 text-sm font-semibold text-white hover:bg-teal-500"
            >
              Start analyzing tenders
            </Link>
          </div>
          <div className="mt-10 flex gap-6 text-sm text-slate-400">
            <div className="flex items-center gap-1.5">
              <Icon name="fact_check" size={18} />
              Evidence-cited extraction
            </div>
            <div className="flex items-center gap-1.5">
              <Icon name="dark_mode" size={18} />
              Light &amp; dark mode
            </div>
          </div>
        </div>

        <div className="relative">
          <div className="rotate-2 rounded-lg border border-slate-700 bg-slate-800 p-6 shadow-2xl">
            <div className="flex items-center justify-between border-b border-slate-700 pb-3">
              <span className="font-display text-sm font-semibold">Water Supply Tender — Overview</span>
              <span className="stamp-complete !rotate-0">Bid</span>
            </div>
            <ul className="mt-4 space-y-3 text-sm text-slate-300">
              <li className="flex justify-between">
                <span>Submission deadline</span>
                <span className="font-medium text-white">15 Dec 2026, p.3</span>
              </li>
              <li className="flex justify-between">
                <span>Tax clearance certificate</span>
                <span className="stamp-missing !rotate-0">Missing</span>
              </li>
              <li className="flex justify-between">
                <span>Bid security</span>
                <span className="stamp-complete !rotate-0">Complete</span>
              </li>
              <li className="flex justify-between">
                <span>Disqualifying clause found</span>
                <span className="font-medium text-rose-400">p.14</span>
              </li>
            </ul>
          </div>
        </div>
      </section>
    </div>
  );
}
