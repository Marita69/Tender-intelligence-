import { useEffect, useState } from "react";
import { api } from "@/lib/api";
import type { BillingBalance } from "@/types";
import { Card, CardBody, CardHeader } from "@/components/Card";
import { Button } from "@/components/Button";

export function BillingPage() {
  const [balance, setBalance] = useState<BillingBalance | null>(null);
  const [isRedirecting, setIsRedirecting] = useState(false);

  useEffect(() => {
    api.get<BillingBalance>("/api/v1/billing/balance").then(setBalance);
  }, []);

  async function handleBuyCredits() {
    setIsRedirecting(true);
    try {
      const { checkout_url } = await api.post<{ checkout_url: string }>("/api/v1/billing/checkout-session", {
        success_url: `${window.location.origin}/app/tenders?purchase=success`,
        cancel_url: `${window.location.origin}/app/tenders?purchase=cancelled`,
      });
      window.location.href = checkout_url;
    } finally {
      setIsRedirecting(false);
    }
  }

  if (!balance) return <p className="text-sm text-muted">Loading…</p>;

  return (
    <div className="mx-auto max-w-md">
      <h1 className="font-display text-2xl font-semibold text-on-surface">Billing</h1>

      <Card className="mt-6">
        <CardHeader title="Analysis credits" />
        <CardBody>
          {balance.billing_enabled ? (
            <>
              <p className="text-3xl font-display font-semibold text-on-surface">{balance.credits}</p>
              <p className="mt-1 text-sm text-muted">Credits remaining. Each analysis run consumes one.</p>
              <Button className="mt-4" onClick={handleBuyCredits} disabled={isRedirecting}>
                {isRedirecting ? "Redirecting…" : "Buy more credits"}
              </Button>
            </>
          ) : (
            <p className="text-sm text-muted">
              Billing is not enabled on this deployment — your organization has unlimited analyses.
            </p>
          )}
        </CardBody>
      </Card>
    </div>
  );
}
