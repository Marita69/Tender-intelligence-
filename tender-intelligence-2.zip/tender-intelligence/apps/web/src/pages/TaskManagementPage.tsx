import { useEffect, useState } from "react";
import { useParams } from "react-router-dom";
import { api } from "@/lib/api";
import type { Task, TaskPriority, TaskStatus } from "@/types";
import { Card, CardBody } from "@/components/Card";
import { Button } from "@/components/Button";
import { Icon } from "@/components/Icon";
import { TenderSubNav } from "@/components/TenderSubNav";

interface Member {
  id: string;
  full_name: string;
}

const COLUMNS: { status: TaskStatus; label: string }[] = [
  { status: "todo", label: "To Do" },
  { status: "in_progress", label: "In Progress" },
  { status: "under_review", label: "Under Review" },
  { status: "done", label: "Done" },
];

const PRIORITY_CLASSES: Record<TaskPriority, string> = {
  critical: "stamp-missing",
  high: "stamp-progress",
  medium: "stamp-na",
  low: "stamp-na",
};

function initials(name: string): string {
  return name
    .split(" ")
    .map((p) => p[0])
    .slice(0, 2)
    .join("")
    .toUpperCase();
}

export function TaskManagementPage() {
  const { tenderId } = useParams<{ tenderId: string }>();
  const [tasks, setTasks] = useState<Task[]>([]);
  const [members, setMembers] = useState<Member[]>([]);
  const [isCreating, setIsCreating] = useState(false);
  const [newTitle, setNewTitle] = useState("");
  const [newPriority, setNewPriority] = useState<TaskPriority>("medium");

  async function load() {
    if (!tenderId) return;
    const [t, m] = await Promise.all([
      api.get<Task[]>(`/api/v1/tenders/${tenderId}/tasks`),
      api.get<Member[]>("/api/v1/organization/members"),
    ]);
    setTasks(t);
    setMembers(m);
  }

  useEffect(() => {
    load();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [tenderId]);

  async function handleCreate(e: React.FormEvent) {
    e.preventDefault();
    if (!tenderId || !newTitle.trim()) return;
    await api.post(`/api/v1/tenders/${tenderId}/tasks`, { title: newTitle, priority: newPriority });
    setNewTitle("");
    setIsCreating(false);
    await load();
  }

  async function moveTask(task: Task, status: TaskStatus) {
    if (!tenderId) return;
    const updated = await api.patch<Task>(`/api/v1/tenders/${tenderId}/tasks/${task.id}`, { status });
    setTasks((prev) => prev.map((t) => (t.id === updated.id ? updated : t)));
  }

  async function assignTask(task: Task, userId: string) {
    if (!tenderId) return;
    const updated = await api.patch<Task>(`/api/v1/tenders/${tenderId}/tasks/${task.id}`, {
      assigned_to_user_id: userId || null,
    });
    setTasks((prev) => prev.map((t) => (t.id === updated.id ? updated : t)));
  }

  async function deleteTask(task: Task) {
    if (!tenderId) return;
    if (!window.confirm(`Delete task "${task.title}"?`)) return;
    await api.delete(`/api/v1/tenders/${tenderId}/tasks/${task.id}`);
    setTasks((prev) => prev.filter((t) => t.id !== task.id));
  }

  if (!tenderId) return null;

  return (
    <div className="mx-auto max-w-6xl">
      <div className="flex items-center justify-between">
        <h1 className="font-display text-2xl font-semibold text-on-surface">Task Management</h1>
        <Button onClick={() => setIsCreating(true)}>+ New task</Button>
      </div>
      <div className="mt-6">
        <TenderSubNav tenderId={tenderId} />
      </div>

      {isCreating && (
        <Card className="mt-4">
          <form onSubmit={handleCreate} className="flex items-center gap-3 p-4">
            <input
              autoFocus
              placeholder="Task title"
              value={newTitle}
              onChange={(e) => setNewTitle(e.target.value)}
              className="flex-1 rounded-md border border-outline-variant px-3 py-2 text-sm focus:border-secondary focus:outline-none focus:ring-1 focus:ring-secondary"
            />
            <select
              value={newPriority}
              onChange={(e) => setNewPriority(e.target.value as TaskPriority)}
              className="rounded-md border border-outline-variant px-2 py-2 text-sm"
            >
              <option value="critical">Critical</option>
              <option value="high">High</option>
              <option value="medium">Medium</option>
              <option value="low">Low</option>
            </select>
            <Button type="submit">Create</Button>
            <Button type="button" variant="ghost" onClick={() => setIsCreating(false)}>
              Cancel
            </Button>
          </form>
        </Card>
      )}

      <div className="mt-6 grid grid-cols-1 gap-4 md:grid-cols-4">
        {COLUMNS.map((col) => (
          <div key={col.status}>
            <h3 className="mb-2 text-sm font-semibold text-on-surface-variant">
              {col.label} <span className="text-muted">({tasks.filter((t) => t.status === col.status).length})</span>
            </h3>
            <div className="space-y-2">
              {tasks
                .filter((t) => t.status === col.status)
                .map((task) => {
                  const assignee = members.find((m) => m.id === task.assigned_to_user_id);
                  return (
                    <Card key={task.id}>
                      <CardBody className="!p-3">
                        <div className="flex items-start justify-between gap-2">
                          <p className="text-sm font-medium text-on-surface">{task.title}</p>
                          <button
                            onClick={() => deleteTask(task)}
                            className="shrink-0 text-muted hover:text-status-danger"
                            aria-label="Delete task"
                          >
                            <Icon name="delete" size={16} />
                          </button>
                        </div>
                        <div className="mt-2 flex items-center justify-between">
                          <span className={PRIORITY_CLASSES[task.priority]}>{task.priority}</span>
                          {assignee && (
                            <span
                              title={assignee.full_name}
                              className="flex h-6 w-6 items-center justify-center rounded-full bg-secondary-container text-[10px] font-semibold text-on-secondary-container"
                            >
                              {initials(assignee.full_name)}
                            </span>
                          )}
                        </div>
                        <div className="mt-2 flex items-center gap-2">
                          <select
                            value={task.status}
                            onChange={(e) => moveTask(task, e.target.value as TaskStatus)}
                            className="flex-1 rounded border border-outline-variant bg-surface-container-lowest px-1.5 py-1 text-xs"
                          >
                            {COLUMNS.map((c) => (
                              <option key={c.status} value={c.status}>
                                {c.label}
                              </option>
                            ))}
                            <option value="blocked">Blocked</option>
                          </select>
                          <select
                            value={task.assigned_to_user_id || ""}
                            onChange={(e) => assignTask(task, e.target.value)}
                            className="flex-1 rounded border border-outline-variant bg-surface-container-lowest px-1.5 py-1 text-xs"
                          >
                            <option value="">Unassigned</option>
                            {members.map((m) => (
                              <option key={m.id} value={m.id}>
                                {m.full_name}
                              </option>
                            ))}
                          </select>
                        </div>
                      </CardBody>
                    </Card>
                  );
                })}
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}
