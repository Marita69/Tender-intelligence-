import { useCallback, useEffect, useRef, useState } from "react";
import { Link, useParams } from "react-router-dom";
import { api, ApiError } from "@/lib/api";
import type { AnalysisJob, Requirement, Tender, TenderAnalysis, TenderDocument } from "@/types";
import { Card, CardBody, CardHeader } from "@/components/Card";
import { Button } from "@/components/Button";
import { ConfidenceStamp } from "@/components/StatusStamp";
import { Icon } from "@/components/Icon";
import { TenderSubNav } from "@/components/TenderSubNav";

const RECOMMENDATION_LABEL: Record<string, string> = {
  bid: "Bid",
  conditional_bid: "Conditional Bid",
  no_bid: "No Bid",
  insufficient_information: "Insufficient Information",
};

// Polls with backoff instead of a single reload — a real analysis run can
// take anywhere from a few seconds (mock provider) to a couple of minutes
// (real AI provider over several document pages), so the UI shows live
// progress instead of looking frozen.
const POLL_INTERVALS_MS = [1500, 1500, 3000, 3000, 5000, 8000, 8000, 8000];

export function TenderDetail() {
  const { tenderId } = useParams<{ tenderId: string }>();
  const [tender, setTender] = useState<Tender | null>(null);
  const [documents, setDocuments] = useState<TenderDocument[]>([]);
  const [analysis, setAnalysis] = useState<TenderAnalysis | null>(null);
  const [runningJob, setRunningJob] = useState<AnalysisJob | null>(null);
  const [uploadError, setUploadError] = useState<string | null>(null);
  const [correctingId, setCorrectingId] = useState<string | null>(null);
  const [correctionValue, setCorrectionValue] = useState("");
  const fileInputRef = useRef<HTMLInputElement>(null);
  const pollTimeoutRef = useRef<ReturnType<typeof setTimeout> | null>(null);

  const load = useCallback(async () => {
    if (!tenderId) return;
    const [t, docs] = await Promise.all([
      api.get<Tender>(`/api/v1/tenders/${tenderId}`),
      api.get<TenderDocument[]>(`/api/v1/tenders/${tenderId}/documents`),
    ]);
    setTender(t);
    setDocuments(docs);
    try {
      const a = await api.get<TenderAnalysis>(`/api/v1/tenders/${tenderId}/analysis`);
      setAnalysis(a);
    } catch (err) {
      if (!(err instanceof ApiError && err.status === 404)) throw err;
      setAnalysis(null);
    }
  }, [tenderId]);

  useEffect(() => {
    load();
    return () => {
      if (pollTimeoutRef.current) clearTimeout(pollTimeoutRef.current);
    };
  }, [load]);

  const pollJob = useCallback(
    (jobId: string, attempt: number) => {
      if (!tenderId) return;
      pollTimeoutRef.current = setTimeout(
        async () => {
          const job = await api.get<AnalysisJob>(`/api/v1/tenders/${tenderId}/analysis/jobs/${jobId}`);
          setRunningJob(job);
          if (job.status === "running" || job.status === "pending") {
            pollJob(jobId, Math.min(attempt + 1, POLL_INTERVALS_MS.length - 1));
          } else {
            setRunningJob(null);
            await load();
          }
        },
        POLL_INTERVALS_MS[Math.min(attempt, POLL_INTERVALS_MS.length - 1)]
      );
    },
    [tenderId, load]
  );

  async function handleUpload(e: React.ChangeEvent<HTMLInputElement>) {
    if (!tenderId || !e.target.files?.length) return;
    setUploadError(null);
    try {
      await api.upload(`/api/v1/tenders/${tenderId}/documents`, e.target.files[0]);
      await load();
    } catch (err) {
      setUploadError(err instanceof ApiError ? err.message : "Upload failed");
    } finally {
      if (fileInputRef.current) fileInputRef.current.value = "";
    }
  }

  async function handleRunAnalysis() {
    if (!tenderId) return;
    setUploadError(null);
    try {
      const job = await api.post<AnalysisJob>(`/api/v1/tenders/${tenderId}/analysis/run`);
      setRunningJob(job);
      if (job.status === "running" || job.status === "pending") {
        pollJob(job.id, 0);
      } else {
        await load();
      }
    } catch (err) {
      if (err instanceof ApiError && err.status === 402) {
        setUploadError("Out of analysis credits. Visit Billing to buy more before running another analysis.");
      } else {
        setUploadError(err instanceof ApiError ? err.message : "Could not start analysis");
      }
    }
  }

  function startCorrection(req: Requirement) {
    setCorrectingId(req.id);
    setCorrectionValue(req.summary);
  }

  async function submitCorrection(reqId: string) {
    if (!tenderId) return;
    await api.post(`/api/v1/tenders/${tenderId}/analysis/requirements/${reqId}/corrections`, {
      field_name: "summary",
      corrected_value: correctionValue,
    });
    setCorrectingId(null);
    await load();
  }

  async function handleDeleteDocument(documentId: string) {
    if (!tenderId) return;
    if (!window.confirm("Delete this document? This cannot be undone.")) return;
    await api.delete(`/api/v1/tenders/${tenderId}/documents/${documentId}`);
    await load();
  }

  async function handleDeleteAnalysis() {
    if (!tenderId) return;
    if (
      !window.confirm(
        "Delete all analysis results for this tender (requirements, risks, bid recommendation, checklist, review items)? Uploaded documents are kept — you can re-run analysis afterward. This cannot be undone."
      )
    )
      return;
    await api.delete(`/api/v1/tenders/${tenderId}/analysis`);
    await load();
  }

  if (!tender || !tenderId) return <p className="text-sm text-muted">Loading…</p>;

  return (
    <div className="mx-auto max-w-5xl">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="font-display text-2xl font-semibold text-on-surface">{tender.title}</h1>
          <p className="mt-1 text-sm text-muted">
            {tender.issuing_entity || "No issuing entity set"} · Status: {tender.status}
          </p>
        </div>
        {tender.submission_deadline && (
          <div className="text-right">
            <p className="text-xs uppercase tracking-wide text-muted">Submission deadline</p>
            <p className="font-display text-lg font-semibold text-on-surface">
              {new Date(tender.submission_deadline).toLocaleString()}
            </p>
          </div>
        )}
        {!tender.submission_deadline && tender.submission_deadline_is_uncertain && (
          <span className="stamp-progress">Deadline uncertain</span>
        )}
      </div>

      <div className="mt-6">
        <TenderSubNav tenderId={tenderId} />
      </div>

      <div className="mt-6 space-y-6">
        <Card>
          <CardHeader
            title="Tender documents"
            subtitle="Upload the tender notice, addenda, and any referenced forms."
            action={
              <div className="flex gap-2">
                <input ref={fileInputRef} type="file" accept=".pdf,.docx,.doc" className="hidden" id="file-upload" onChange={handleUpload} />
                <Button variant="secondary" onClick={() => fileInputRef.current?.click()}>
                  <Icon name="upload_file" size={18} /> Upload
                </Button>
                <Button onClick={handleRunAnalysis} disabled={!!runningJob || documents.length === 0}>
                  {runningJob ? `Analyzing… (${runningJob.status})` : "Run analysis"}
                </Button>
              </div>
            }
          />
          <CardBody>
            {uploadError && <p className="mb-3 text-sm text-status-danger">{uploadError}</p>}
            {documents.length === 0 ? (
              <p className="text-sm text-muted">No documents uploaded yet.</p>
            ) : (
              <ul className="divide-y divide-border-subtle">
                {documents.map((doc) => (
                  <li key={doc.id} className="flex items-center justify-between py-3 text-sm">
                    <Link
                      to={`/app/tenders/${tenderId}/documents/${doc.id}`}
                      className="flex items-center gap-2 font-medium text-on-surface hover:text-secondary"
                    >
                      <Icon name="description" size={18} />
                      {doc.original_filename}
                    </Link>
                    <div className="flex items-center gap-3 text-muted">
                      <span>
                        {(doc.size_bytes / 1024).toFixed(0)} KB
                        {doc.page_count ? ` · ${doc.page_count} pages` : ""}
                        {doc.ocr_used ? " · OCR used" : ""}
                      </span>
                      <span>{doc.status}</span>
                      <button
                        onClick={() => handleDeleteDocument(doc.id)}
                        className="text-muted hover:text-status-danger"
                        aria-label="Delete document"
                      >
                        <Icon name="delete" size={18} />
                      </button>
                    </div>
                  </li>
                ))}
              </ul>
            )}
          </CardBody>
        </Card>

        {!analysis ? (
          <Card>
            <CardBody>
              <p className="text-sm text-muted">
                No analysis has been run yet. Upload documents and click "Run analysis" above.
              </p>
            </CardBody>
          </Card>
        ) : (
          <>
            <div className="flex items-center justify-between">
              <h2 className="font-display text-lg font-semibold text-on-surface">Analysis</h2>
              <Button variant="danger" onClick={handleDeleteAnalysis}>
                <Icon name="delete" size={18} /> Delete analysis
              </Button>
            </div>

            {analysis.bid_assessment && (
              <Card>
                <CardHeader
                  title="Bid recommendation"
                  action={
                    <Link to={`/app/tenders/${tenderId}/report`}>
                      <Button variant="secondary">View report</Button>
                    </Link>
                  }
                />
                <CardBody>
                  <div className="flex items-center gap-4">
                    <span className="stamp-complete">{RECOMMENDATION_LABEL[analysis.bid_assessment.recommendation]}</span>
                    <span className="text-sm text-muted">Score: {analysis.bid_assessment.score.toFixed(0)}/100</span>
                    <ConfidenceStamp level={analysis.bid_assessment.confidence} />
                  </div>
                  <p className="mt-3 text-sm text-on-surface-variant">{analysis.bid_assessment.rationale}</p>
                </CardBody>
              </Card>
            )}

            <Card>
              <CardHeader title="Extracted requirements" subtitle={`${analysis.requirements.length} found`} />
              <CardBody>
                <ul className="divide-y divide-border-subtle">
                  {analysis.requirements.map((req) => (
                    <li key={req.id} className="py-3 text-sm">
                      <div className="flex items-center justify-between">
                        <span className="font-medium capitalize text-on-surface">{req.type.replace(/_/g, " ")}</span>
                        <div className="flex items-center gap-2">
                          <ConfidenceStamp level={req.confidence} />
                          {correctingId !== req.id && (
                            <button onClick={() => startCorrection(req)} className="text-xs font-medium text-muted hover:text-secondary">
                              Correct
                            </button>
                          )}
                        </div>
                      </div>
                      {correctingId === req.id ? (
                        <div className="mt-2 flex items-center gap-2">
                          <input
                            autoFocus
                            value={correctionValue}
                            onChange={(e) => setCorrectionValue(e.target.value)}
                            className="flex-1 rounded-md border border-outline-variant px-2 py-1 text-sm focus:border-secondary focus:outline-none focus:ring-1 focus:ring-secondary"
                          />
                          <Button onClick={() => submitCorrection(req.id)}>Save</Button>
                          <Button variant="ghost" onClick={() => setCorrectingId(null)}>Cancel</Button>
                        </div>
                      ) : (
                        <p className="mt-1 text-on-surface-variant">{req.summary}</p>
                      )}
                      {req.evidence.length > 0 && (
                        <Link
                          to={`/app/tenders/${tenderId}/documents/${req.evidence[0].document_id}?page=${req.evidence[0].page_number}`}
                          className="mt-1 block text-xs text-muted hover:text-secondary"
                        >
                          Source: p.{req.evidence[0].page_number} — "{req.evidence[0].quoted_text.slice(0, 120)}
                          {req.evidence[0].quoted_text.length > 120 ? "…" : ""}"
                        </Link>
                      )}
                      {req.is_unknown && (
                        <p className="mt-1 text-xs text-status-warning">Could not be determined from the source documents.</p>
                      )}
                    </li>
                  ))}
                </ul>
              </CardBody>
            </Card>

            {analysis.risks.length > 0 && (
              <Card>
                <CardHeader title="Risks" />
                <CardBody>
                  <ul className="space-y-2">
                    {analysis.risks.map((risk) => (
                      <li key={risk.id} className="text-sm">
                        <span className={risk.is_disqualifying ? "stamp-missing" : "stamp-progress"}>
                          {risk.is_disqualifying ? "Disqualifying" : risk.severity}
                        </span>
                        <span className="ml-2 font-medium text-on-surface">{risk.title}</span>
                        <p className="text-on-surface-variant">{risk.description}</p>
                      </li>
                    ))}
                  </ul>
                </CardBody>
              </Card>
            )}
          </>
        )}
      </div>
    </div>
  );
}
