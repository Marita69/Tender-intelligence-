import { useEffect, useState } from "react";
import { Link } from "react-router-dom";
import { api } from "@/lib/api";
import type { DashboardOverview } from "@/types";
import { Card, CardBody, CardHeader } from "@/components/Card";
import { Icon } from "@/components/Icon";

const STATUS_LABEL: Record<string, string> = {
  draft: "Draft",
  processing: "Processing…",
  analyzed: "Analyzed",
  failed: "Analysis failed",
  archived: "Archived",
};

const RECOMMENDATION_LABEL: Record<string, string> = {
  bid: "Bid",
  conditional_bid: "Conditional",
  no_bid: "No Bid",
  insufficient_information: "Insufficient info",
};

function StatCard({ icon, label, value }: { icon: string; label: string; value: number | string }) {
  return (
    <Card>
      <CardBody>
        <div className="flex items-center gap-3">
          <div className="flex h-10 w-10 items-center justify-center rounded-full bg-secondary-container text-on-secondary-container">
            <Icon name={icon} size={20} />
          </div>
          <div>
            <p className="font-display text-2xl font-semibold text-on-surface">{value}</p>
            <p className="text-sm text-muted">{label}</p>
          </div>
        </div>
      </CardBody>
    </Card>
  );
}

export function DashboardPage() {
  const [overview, setOverview] = useState<DashboardOverview | null>(null);

  useEffect(() => {
    api.get<DashboardOverview>("/api/v1/dashboard/overview").then(setOverview);
  }, []);

  if (!overview) return <p className="text-sm text-muted">Loading…</p>;

  return (
    <div className="mx-auto max-w-6xl">
      <h1 className="font-display text-2xl font-semibold text-on-surface">Dashboard</h1>

      <div className="mt-6 grid grid-cols-2 gap-4 lg:grid-cols-4">
        <StatCard icon="folder_open" label="Active tenders" value={overview.stats.active_tenders} />
        <StatCard icon="fiber_new" label="New this week" value={overview.stats.new_this_week} />
        <StatCard icon="event_upcoming" label="Deadlines this week" value={overview.stats.deadlines_this_week} />
        <StatCard icon="report" label="Critical blockers" value={overview.stats.critical_blockers} />
      </div>

      <div className="mt-6 grid grid-cols-1 gap-6 lg:grid-cols-[1fr_320px]">
        <Card>
          <CardHeader title="Active tender pipeline" />
          <CardBody className="!p-0">
            {overview.pipeline.length === 0 ? (
              <p className="p-5 text-sm text-muted">
                No active tenders yet. <Link to="/app/tenders" className="text-secondary hover:underline">Create one</Link>.
              </p>
            ) : (
              <table className="w-full text-sm">
                <thead>
                  <tr className="border-b border-border-subtle text-left text-muted">
                    <th className="px-5 py-3 font-medium">Tender</th>
                    <th className="px-5 py-3 font-medium">Deadline</th>
                    <th className="px-5 py-3 font-medium">Bid score</th>
                    <th className="px-5 py-3 font-medium">Status</th>
                  </tr>
                </thead>
                <tbody>
                  {overview.pipeline.map((t) => (
                    <tr key={t.id} className="border-b border-border-subtle last:border-0 hover:bg-surface-container-low">
                      <td className="px-5 py-3">
                        <Link to={`/app/tenders/${t.id}`} className="font-medium text-secondary hover:underline">
                          {t.title}
                        </Link>
                        <p className="text-xs text-muted">{t.issuing_entity}</p>
                      </td>
                      <td className="px-5 py-3 text-on-surface-variant">
                        {t.submission_deadline ? new Date(t.submission_deadline).toLocaleDateString() : "—"}
                      </td>
                      <td className="px-5 py-3 text-on-surface-variant">
                        {t.bid_score !== null ? (
                          <>
                            {t.bid_score.toFixed(0)}/100
                            {t.bid_recommendation && (
                              <span className="ml-2 text-xs text-muted">{RECOMMENDATION_LABEL[t.bid_recommendation]}</span>
                            )}
                          </>
                        ) : (
                          "—"
                        )}
                      </td>
                      <td className="px-5 py-3 text-on-surface-variant">{STATUS_LABEL[t.status]}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            )}
          </CardBody>
        </Card>

        <Card className="h-fit">
          <CardHeader title="Urgent action required" />
          <CardBody className="!p-0">
            {overview.urgent_tasks.length === 0 ? (
              <p className="p-4 text-sm text-muted">Nothing urgent right now.</p>
            ) : (
              <ul className="divide-y divide-border-subtle">
                {overview.urgent_tasks.map((task) => (
                  <li key={task.id} className="p-3">
                    <Link to={`/app/tenders/${task.tender_id}/tasks`} className="text-sm font-medium text-on-surface hover:text-secondary">
                      {task.title}
                    </Link>
                    <p className="text-xs text-muted">{task.tender_title}</p>
                    {task.due_at && (
                      <p className="mt-1 text-xs text-status-warning">Due {new Date(task.due_at).toLocaleDateString()}</p>
                    )}
                  </li>
                ))}
              </ul>
            )}
          </CardBody>
        </Card>
      </div>
    </div>
  );
}
