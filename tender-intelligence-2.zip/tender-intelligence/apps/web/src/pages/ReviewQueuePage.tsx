import { useEffect, useState } from "react";
import { Link } from "react-router-dom";
import { api } from "@/lib/api";
import type { ReviewItem, ReviewStatus } from "@/types";
import { Card, CardBody, CardHeader } from "@/components/Card";
import { Button } from "@/components/Button";

const REASON_LABELS: Record<string, string> = {
  low_confidence: "Low confidence",
  conflicting_requirement: "Conflicting requirement",
  missing_referenced_document: "Missing referenced document",
  uncertain_deadline: "Uncertain deadline",
  critical_eligibility_decision: "Critical eligibility decision",
  uncertain_bid_score: "Uncertain bid score",
};

const FILTERS: { label: string; value: ReviewStatus | "all" }[] = [
  { label: "Needs review", value: "needs_review" },
  { label: "Reviewed", value: "reviewed" },
  { label: "Rejected", value: "rejected" },
  { label: "Corrected", value: "corrected" },
  { label: "All", value: "all" },
];

export function ReviewQueuePage() {
  const [items, setItems] = useState<ReviewItem[]>([]);
  const [filter, setFilter] = useState<ReviewStatus | "all">("needs_review");
  const [isLoading, setIsLoading] = useState(true);

  async function load() {
    setIsLoading(true);
    const qs = filter === "all" ? "" : `?status_filter=${filter}`;
    const result = await api.get<ReviewItem[]>(`/api/v1/review-queue${qs}`);
    setItems(result);
    setIsLoading(false);
  }

  useEffect(() => {
    load();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [filter]);

  async function resolve(item: ReviewItem, status: ReviewStatus) {
    await api.patch(`/api/v1/review-queue/${item.id}`, { status });
    setItems((prev) => prev.filter((i) => i.id !== item.id));
  }

  return (
    <div className="mx-auto max-w-4xl">
      <h1 className="font-display text-2xl font-semibold text-on-surface">Review queue</h1>
      <p className="mt-1 text-sm text-muted">
        Facts the AI flagged as low-confidence, conflicting, or otherwise needing a human look before you rely on
        them.
      </p>

      <div className="mt-4 flex gap-1">
        {FILTERS.map((f) => (
          <button
            key={f.value}
            onClick={() => setFilter(f.value)}
            className={`rounded-md px-3 py-1.5 text-sm font-medium ${
              filter === f.value ? "bg-primary text-on-primary" : "bg-surface-container-lowest text-on-surface-variant hover:bg-surface-container-low"
            }`}
          >
            {f.label}
          </button>
        ))}
      </div>

      <div className="mt-4">
        {isLoading ? (
          <p className="text-sm text-muted">Loading…</p>
        ) : items.length === 0 ? (
          <Card>
            <CardBody>
              <p className="text-sm text-muted">Nothing here right now.</p>
            </CardBody>
          </Card>
        ) : (
          <Card>
            <CardHeader title={`${items.length} item${items.length === 1 ? "" : "s"}`} />
            <CardBody className="!p-0">
              <ul className="divide-y divide-border-subtle">
                {items.map((item) => (
                  <li key={item.id} className="flex items-center justify-between px-5 py-4">
                    <div>
                      <span className="stamp-progress">{REASON_LABELS[item.reason] || item.reason}</span>
                      {item.requirement_summary && (
                        <p className="mt-1 text-sm text-on-surface">
                          [{item.requirement_type?.replace(/_/g, " ")}] {item.requirement_summary}
                        </p>
                      )}
                      <Link
                        to={`/app/tenders/${item.tender_id}`}
                        className="mt-1 inline-block text-xs font-medium text-secondary hover:underline"
                      >
                        View tender →
                      </Link>
                    </div>
                    {item.status === "needs_review" && (
                      <div className="flex shrink-0 gap-2">
                        <Button variant="secondary" onClick={() => resolve(item, "reviewed")}>
                          Mark reviewed
                        </Button>
                        <Button variant="danger" onClick={() => resolve(item, "rejected")}>
                          Reject
                        </Button>
                      </div>
                    )}
                  </li>
                ))}
              </ul>
            </CardBody>
          </Card>
        )}
      </div>
    </div>
  );
}
