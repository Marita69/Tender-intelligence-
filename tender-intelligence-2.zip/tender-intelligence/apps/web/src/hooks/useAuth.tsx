import { createContext, useCallback, useContext, useEffect, useState, type ReactNode } from "react";
import { api, clearStoredAuth, setActiveOrganization, setStoredAuth } from "@/lib/api";
import type { Membership } from "@/types";

interface AuthContextValue {
  memberships: Membership[];
  activeOrganizationId: string | null;
  isLoading: boolean;
  isAuthenticated: boolean;
  login: (email: string, password: string) => Promise<void>;
  signup: (params: { email: string; password: string; fullName: string; organizationName: string }) => Promise<void>;
  logout: () => void;
  switchOrganization: (organizationId: string) => void;
  refreshMemberships: () => Promise<void>;
}

const AuthContext = createContext<AuthContextValue | null>(null);

export function AuthProvider({ children }: { children: ReactNode }) {
  const [memberships, setMemberships] = useState<Membership[]>([]);
  const [activeOrganizationId, setActiveOrganizationId] = useState<string | null>(
    localStorage.getItem("organization_id")
  );
  const [isLoading, setIsLoading] = useState(true);

  const refreshMemberships = useCallback(async () => {
    if (!localStorage.getItem("access_token")) {
      setIsLoading(false);
      return;
    }
    try {
      const result = await api.get<Membership[]>("/api/v1/auth/me");
      setMemberships(result);
      if (!localStorage.getItem("organization_id") && result.length > 0) {
        setActiveOrganization(result[0].organization_id);
        setActiveOrganizationId(result[0].organization_id);
      }
    } catch {
      clearStoredAuth();
    } finally {
      setIsLoading(false);
    }
  }, []);

  useEffect(() => {
    refreshMemberships();
  }, [refreshMemberships]);

  const login = useCallback(
    async (email: string, password: string) => {
      const tokens = await api.post<{ access_token: string; refresh_token: string }>(
        "/api/v1/auth/login",
        { email, password },
        { skipAuth: true }
      );
      setStoredAuth(tokens.access_token, tokens.refresh_token);
      await refreshMemberships();
    },
    [refreshMemberships]
  );

  const signup = useCallback(
    async (params: { email: string; password: string; fullName: string; organizationName: string }) => {
      const tokens = await api.post<{ access_token: string; refresh_token: string }>(
        "/api/v1/auth/signup",
        {
          email: params.email,
          password: params.password,
          full_name: params.fullName,
          organization_name: params.organizationName,
        },
        { skipAuth: true }
      );
      setStoredAuth(tokens.access_token, tokens.refresh_token);
      await refreshMemberships();
    },
    [refreshMemberships]
  );

  const logout = useCallback(() => {
    clearStoredAuth();
    setMemberships([]);
    setActiveOrganizationId(null);
    window.location.href = "/login";
  }, []);

  const switchOrganization = useCallback((organizationId: string) => {
    setActiveOrganization(organizationId);
    setActiveOrganizationId(organizationId);
    window.location.reload();
  }, []);

  return (
    <AuthContext.Provider
      value={{
        memberships,
        activeOrganizationId,
        isLoading,
        isAuthenticated: memberships.length > 0,
        login,
        signup,
        logout,
        switchOrganization,
        refreshMemberships,
      }}
    >
      {children}
    </AuthContext.Provider>
  );
}

export function useAuth() {
  const ctx = useContext(AuthContext);
  if (!ctx) throw new Error("useAuth must be used within AuthProvider");
  return ctx;
}
