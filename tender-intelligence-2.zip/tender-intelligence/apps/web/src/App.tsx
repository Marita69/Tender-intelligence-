import { BrowserRouter, Navigate, Route, Routes } from "react-router-dom";
import { AuthProvider } from "@/hooks/useAuth";
import { ThemeProvider } from "@/hooks/useTheme";
import { ProtectedRoute } from "@/components/ProtectedRoute";
import { AdminRoute } from "@/components/AdminRoute";
import { AppShell } from "@/components/AppShell";
import { Landing } from "@/pages/Landing";
import { Login } from "@/pages/Login";
import { Signup } from "@/pages/Signup";
import { DashboardPage } from "@/pages/DashboardPage";
import { TendersList } from "@/pages/TendersList";
import { TenderDetail } from "@/pages/TenderDetail";
import { ComplianceMatrixPage } from "@/pages/ComplianceMatrixPage";
import { TaskManagementPage } from "@/pages/TaskManagementPage";
import { DocumentViewerPage } from "@/pages/DocumentViewerPage";
import { ReportPreviewPage } from "@/pages/ReportPreviewPage";
import { CompanyProfilePage } from "@/pages/CompanyProfilePage";
import { ReviewQueuePage } from "@/pages/ReviewQueuePage";
import { NotificationCenterPage } from "@/pages/NotificationCenterPage";
import { UserSettingsPage } from "@/pages/UserSettingsPage";
import { AdminDashboardPage } from "@/pages/AdminDashboardPage";
import { BillingPage } from "@/pages/BillingPage";

export function App() {
  return (
    <ThemeProvider>
      <AuthProvider>
        <BrowserRouter>
          <Routes>
            <Route path="/" element={<Landing />} />
            <Route path="/login" element={<Login />} />
            <Route path="/signup" element={<Signup />} />

            <Route
              path="/app"
              element={
                <ProtectedRoute>
                  <AppShell />
                </ProtectedRoute>
              }
            >
              <Route index element={<Navigate to="dashboard" replace />} />
              <Route path="dashboard" element={<DashboardPage />} />
              <Route path="tenders" element={<TendersList />} />
              <Route path="tenders/:tenderId" element={<TenderDetail />} />
              <Route path="tenders/:tenderId/compliance" element={<ComplianceMatrixPage />} />
              <Route path="tenders/:tenderId/tasks" element={<TaskManagementPage />} />
              <Route path="tenders/:tenderId/documents/:documentId" element={<DocumentViewerPage />} />
              <Route path="tenders/:tenderId/report" element={<ReportPreviewPage />} />
              <Route path="review-queue" element={<ReviewQueuePage />} />
              <Route path="company-profile" element={<CompanyProfilePage />} />
              <Route path="notifications" element={<NotificationCenterPage />} />
              <Route path="settings" element={<UserSettingsPage />} />
              <Route path="billing" element={<BillingPage />} />
              <Route
                path="admin"
                element={
                  <AdminRoute>
                    <AdminDashboardPage />
                  </AdminRoute>
                }
              />
            </Route>

            <Route path="*" element={<Navigate to="/" replace />} />
          </Routes>
        </BrowserRouter>
      </AuthProvider>
    </ThemeProvider>
  );
}
