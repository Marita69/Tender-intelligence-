def test_billing_balance_disabled_by_default(client, auth_headers):
    resp = client.get("/api/v1/billing/balance", headers=auth_headers)
    assert resp.status_code == 200
    body = resp.json()
    assert body["billing_enabled"] is False


def test_checkout_session_rejected_when_billing_disabled(client, auth_headers):
    resp = client.post(
        "/api/v1/billing/checkout-session",
        json={"success_url": "https://example.com/ok", "cancel_url": "https://example.com/cancel"},
        headers=auth_headers,
    )
    assert resp.status_code == 400


def test_billing_webhook_404_when_provider_not_stripe(client):
    resp = client.post("/api/v1/admin/billing/webhook", json={"id": "evt_fake", "type": "checkout.session.completed"})
    assert resp.status_code == 404  # BILLING_PROVIDER=none in test env


def test_billing_webhook_requires_signature_when_enabled(client, monkeypatch):
    from app.core.config import settings

    monkeypatch.setattr(settings, "BILLING_PROVIDER", "stripe")
    resp = client.post("/api/v1/admin/billing/webhook", json={"id": "evt_fake", "type": "checkout.session.completed"})
    assert resp.status_code == 400  # missing Stripe-Signature header
