# Backend tests

`pytest` runs the full suite against an in-memory SQLite database (see
`conftest.py`) with `AI_PROVIDER=mock` and `CELERY_TASK_ALWAYS_EAGER=true`,
so it needs **no** Postgres, Redis, or Anthropic API key. This makes it
fast and runnable anywhere, including CI without infra.

**What this does and doesn't prove:**
- Proves: routing, auth/tenant-isolation, request validation, service
  logic, the end-to-end pipeline shape (upload → mock-extract → mock-AI →
  checklist → report).
- Does NOT prove: real Postgres-specific behavior (JSONB operators, ARRAY
  containment, migration correctness), real OCR/Tesseract behavior, or
  real Anthropic API integration/prompt quality.

**A note on the Celery/SQLite interaction in tests:** with
`CELERY_TASK_ALWAYS_EAGER=true`, the analysis task runs inline during the
HTTP request instead of in a separate worker process — but it still opens
its own SQLAlchemy session (mirroring how a real out-of-process worker
would). `conftest.py` patches that session to share the same in-memory
SQLite engine as the request session, via `StaticPool` (a single physical
connection for the whole test). This keeps everything working in a single
synchronous test run, but it's a testing convenience specific to SQLite +
eager mode — it says nothing about real concurrent-session behavior
against Postgres with a real worker process, which you should still
exercise manually (Part 1, step 4 of PRODUCTION_GUIDE.md) before launch.

Before production launch, also run (see PRODUCTION_GUIDE.md):
1. `alembic upgrade head` against a real Postgres instance and confirm it
   applies cleanly.
2. At least one manual end-to-end run with `AI_PROVIDER=anthropic` and a
   real tender PDF, including a scanned/OCR document.
3. Celery worker running for real (not eager) against Redis, to confirm
   task serialization works as expected.

Run: `pytest -v` from `apps/api/`.
