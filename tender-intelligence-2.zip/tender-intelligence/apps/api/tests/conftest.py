import os
import uuid

os.environ.setdefault("AI_PROVIDER", "mock")
os.environ.setdefault("STORAGE_BACKEND", "local")
os.environ.setdefault("STORAGE_LOCAL_PATH", "/tmp/tender_intelligence_test_storage")
os.environ.setdefault("CELERY_TASK_ALWAYS_EAGER", "true")
os.environ.setdefault("SECRET_KEY", "test-secret-key")
os.environ.setdefault("BILLING_PROVIDER", "none")

import pytest
from fastapi.testclient import TestClient
from sqlalchemy import create_engine
from sqlalchemy.orm import sessionmaker
from sqlalchemy.pool import StaticPool

from app.db.base import Base
from app.db.session import get_db
import app.models  # noqa: F401 populates metadata
from app.main import app


@pytest.fixture()
def db_session(monkeypatch):
    # In-memory SQLite is intentionally used for fast, hermetic unit tests
    # of API/service logic. It does NOT validate Postgres-specific types
    # (JSONB, ARRAY, UUID-as-native) — see tests/README.md. Run the real
    # integration suite against Postgres in CI before trusting this alone.
    engine = create_engine("sqlite://", connect_args={"check_same_thread": False}, poolclass=StaticPool)
    Base.metadata.create_all(engine)
    TestingSessionLocal = sessionmaker(bind=engine, autoflush=False, autocommit=False)

    # The Celery task (run eagerly here via CELERY_TASK_ALWAYS_EAGER=true)
    # does NOT go through FastAPI's `get_db` dependency override below — it
    # opens its own session via the module-level `SessionLocal` imported in
    # app/workers/tasks.py, which by default is bound to the real Postgres
    # URL from settings. Without patching both references, an eager task
    # run inside a test tries to hit a real Postgres instance and fails
    # with psycopg2.OperationalError. Patching both to this same
    # StaticPool-backed engine keeps everything on one shared connection
    # for the duration of the test.
    monkeypatch.setattr("app.db.session.SessionLocal", TestingSessionLocal)
    monkeypatch.setattr("app.workers.tasks.SessionLocal", TestingSessionLocal)

    session = TestingSessionLocal()
    try:
        yield session
    finally:
        session.close()


@pytest.fixture()
def client(db_session):
    def _override_get_db():
        try:
            yield db_session
        finally:
            pass

    app.dependency_overrides[get_db] = _override_get_db
    with TestClient(app) as c:
        yield c
    app.dependency_overrides.clear()


@pytest.fixture()
def auth_headers(client):
    """Signs up a fresh user+org and returns headers ready for authenticated calls."""
    email = f"test-{uuid.uuid4().hex[:8]}@example.com"
    resp = client.post(
        "/api/v1/auth/signup",
        json={
            "email": email,
            "password": "supersecretpassword123",
            "full_name": "Test User",
            "organization_name": "Test Org",
        },
    )
    assert resp.status_code == 201, resp.text
    token = resp.json()["access_token"]

    me = client.get("/api/v1/auth/me", headers={"Authorization": f"Bearer {token}"})
    org_id = me.json()[0]["organization_id"]

    return {"Authorization": f"Bearer {token}", "X-Organization-Id": org_id}
