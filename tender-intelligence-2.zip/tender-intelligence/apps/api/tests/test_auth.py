def test_signup_creates_org_and_returns_tokens(client):
    resp = client.post(
        "/api/v1/auth/signup",
        json={
            "email": "alice@example.com",
            "password": "supersecretpassword123",
            "full_name": "Alice Example",
            "organization_name": "Alice Consulting",
        },
    )
    assert resp.status_code == 201
    body = resp.json()
    assert "access_token" in body and "refresh_token" in body


def test_signup_duplicate_email_rejected(client):
    payload = {
        "email": "bob@example.com",
        "password": "supersecretpassword123",
        "full_name": "Bob Example",
        "organization_name": "Bob Co",
    }
    first = client.post("/api/v1/auth/signup", json=payload)
    assert first.status_code == 201
    second = client.post("/api/v1/auth/signup", json=payload)
    assert second.status_code == 409


def test_login_wrong_password_rejected(client):
    client.post(
        "/api/v1/auth/signup",
        json={
            "email": "carol@example.com",
            "password": "supersecretpassword123",
            "full_name": "Carol Example",
            "organization_name": "Carol Co",
        },
    )
    resp = client.post("/api/v1/auth/login", json={"email": "carol@example.com", "password": "wrong-password"})
    assert resp.status_code == 401


def test_me_lists_organization_membership(client, auth_headers):
    resp = client.get("/api/v1/auth/me", headers={"Authorization": auth_headers["Authorization"]})
    assert resp.status_code == 200
    body = resp.json()
    assert len(body) == 1
    assert body[0]["role"] == "owner"


def test_protected_route_requires_org_header(client, auth_headers):
    resp = client.get("/api/v1/tenders", headers={"Authorization": auth_headers["Authorization"]})
    assert resp.status_code == 422  # missing required X-Organization-Id header
