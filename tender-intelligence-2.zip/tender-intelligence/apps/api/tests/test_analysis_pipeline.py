import io


def _make_test_pdf_bytes(text: str) -> bytes:
    from reportlab.lib.pagesizes import A4
    from reportlab.pdfgen import canvas

    buffer = io.BytesIO()
    c = canvas.Canvas(buffer, pagesize=A4)
    c.drawString(72, 800, text)
    c.showPage()
    c.save()
    return buffer.getvalue()


def test_full_pipeline_upload_analyze_checklist_report(client, auth_headers):
    tender_resp = client.post(
        "/api/v1/tenders", json={"title": "Water Supply Tender"}, headers=auth_headers
    )
    tender_id = tender_resp.json()["id"]

    pdf_bytes = _make_test_pdf_bytes("Submission deadline: 15 Dec 2026. Bidders must submit a tax clearance certificate.")
    upload_resp = client.post(
        f"/api/v1/tenders/{tender_id}/documents",
        files={"file": ("tender.pdf", pdf_bytes, "application/pdf")},
        headers=auth_headers,
    )
    assert upload_resp.status_code == 201

    # CELERY_TASK_ALWAYS_EAGER=true means this call runs the whole pipeline
    # synchronously before returning.
    run_resp = client.post(f"/api/v1/tenders/{tender_id}/analysis/run", headers=auth_headers)
    assert run_resp.status_code in (200, 202)

    analysis_resp = client.get(f"/api/v1/tenders/{tender_id}/analysis", headers=auth_headers)
    assert analysis_resp.status_code == 200
    body = analysis_resp.json()
    assert body["job"]["status"] in ("succeeded", "partially_succeeded")
    # The mock provider heuristically finds the "15 Dec 2026" date pattern.
    assert any(r["type"] == "deadline" for r in body["requirements"])

    checklist_resp = client.get(f"/api/v1/tenders/{tender_id}/checklist", headers=auth_headers)
    assert checklist_resp.status_code == 200

    pdf_report_resp = client.get(f"/api/v1/tenders/{tender_id}/reports/pdf", headers=auth_headers)
    assert pdf_report_resp.status_code == 200
    assert pdf_report_resp.headers["content-type"] == "application/pdf"


def test_upload_rejects_disallowed_extension(client, auth_headers):
    tender_resp = client.post("/api/v1/tenders", json={"title": "Some Tender"}, headers=auth_headers)
    tender_id = tender_resp.json()["id"]

    resp = client.post(
        f"/api/v1/tenders/{tender_id}/documents",
        files={"file": ("malware.exe", b"not a real exe", "application/octet-stream")},
        headers=auth_headers,
    )
    assert resp.status_code == 400
