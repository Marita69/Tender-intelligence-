import io


def _make_test_pdf_bytes(text: str) -> bytes:
    from reportlab.lib.pagesizes import A4
    from reportlab.pdfgen import canvas

    buffer = io.BytesIO()
    c = canvas.Canvas(buffer, pagesize=A4)
    c.drawString(72, 800, text)
    c.showPage()
    c.save()
    return buffer.getvalue()


def test_review_queue_populated_after_analysis(client, auth_headers):
    """The mock provider reports 'unknown' confidence when it can't find a
    deadline pattern, which should land a review_item in the queue."""
    tender_resp = client.post("/api/v1/tenders", json={"title": "Ambiguous Tender"}, headers=auth_headers)
    tender_id = tender_resp.json()["id"]

    pdf_bytes = _make_test_pdf_bytes("This document has no clear submission date mentioned anywhere.")
    client.post(
        f"/api/v1/tenders/{tender_id}/documents",
        files={"file": ("tender.pdf", pdf_bytes, "application/pdf")},
        headers=auth_headers,
    )
    client.post(f"/api/v1/tenders/{tender_id}/analysis/run", headers=auth_headers)

    resp = client.get("/api/v1/review-queue", headers=auth_headers)
    assert resp.status_code == 200
    items = resp.json()
    assert any(i["reason"] == "uncertain_deadline" for i in items)


def test_review_queue_scoped_to_organization(client, auth_headers):
    resp = client.get("/api/v1/review-queue", headers=auth_headers)
    assert resp.status_code == 200

    signup_resp = client.post(
        "/api/v1/auth/signup",
        json={
            "email": "reviewer-other-org@example.com",
            "password": "anothersecretpassword123",
            "full_name": "Other Org User",
            "organization_name": "Other Review Org",
        },
    )
    other_token = signup_resp.json()["access_token"]
    me = client.get("/api/v1/auth/me", headers={"Authorization": f"Bearer {other_token}"})
    other_org_id = me.json()[0]["organization_id"]
    other_headers = {"Authorization": f"Bearer {other_token}", "X-Organization-Id": other_org_id}

    resp = client.get("/api/v1/review-queue", headers=other_headers)
    assert resp.status_code == 200
    assert resp.json() == []  # sees none of the first org's flagged items


def test_update_review_item_not_found_for_bogus_id(client, auth_headers):
    resp = client.patch(
        "/api/v1/review-queue/00000000-0000-0000-0000-000000000000",
        json={"status": "reviewed"},
        headers=auth_headers,
    )
    assert resp.status_code == 404
