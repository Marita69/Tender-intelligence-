def test_create_and_get_tender(client, auth_headers):
    resp = client.post("/api/v1/tenders", json={"title": "Road Maintenance Tender"}, headers=auth_headers)
    assert resp.status_code == 201
    tender_id = resp.json()["id"]

    get_resp = client.get(f"/api/v1/tenders/{tender_id}", headers=auth_headers)
    assert get_resp.status_code == 200
    assert get_resp.json()["title"] == "Road Maintenance Tender"


def test_list_tenders_scoped_to_organization(client, auth_headers):
    client.post("/api/v1/tenders", json={"title": "Tender A"}, headers=auth_headers)
    client.post("/api/v1/tenders", json={"title": "Tender B"}, headers=auth_headers)

    resp = client.get("/api/v1/tenders", headers=auth_headers)
    assert resp.status_code == 200
    body = resp.json()
    assert body["total"] == 2


def test_tender_not_visible_to_other_organization(client, auth_headers):
    create_resp = client.post("/api/v1/tenders", json={"title": "Secret Tender"}, headers=auth_headers)
    tender_id = create_resp.json()["id"]

    # Sign up a second, unrelated user/org.
    signup_resp = client.post(
        "/api/v1/auth/signup",
        json={
            "email": "other-org-user@example.com",
            "password": "anothersecretpassword123",
            "full_name": "Other User",
            "organization_name": "Other Org",
        },
    )
    other_token = signup_resp.json()["access_token"]
    me = client.get("/api/v1/auth/me", headers={"Authorization": f"Bearer {other_token}"})
    other_org_id = me.json()[0]["organization_id"]
    other_headers = {"Authorization": f"Bearer {other_token}", "X-Organization-Id": other_org_id}

    resp = client.get(f"/api/v1/tenders/{tender_id}", headers=other_headers)
    assert resp.status_code == 404  # never 403 with details — must look identical to "doesn't exist"


def test_update_and_delete_tender(client, auth_headers):
    create_resp = client.post("/api/v1/tenders", json={"title": "Old Title"}, headers=auth_headers)
    tender_id = create_resp.json()["id"]

    patch_resp = client.patch(f"/api/v1/tenders/{tender_id}", json={"title": "New Title"}, headers=auth_headers)
    assert patch_resp.status_code == 200
    assert patch_resp.json()["title"] == "New Title"

    delete_resp = client.delete(f"/api/v1/tenders/{tender_id}", headers=auth_headers)
    assert delete_resp.status_code == 204

    get_resp = client.get(f"/api/v1/tenders/{tender_id}", headers=auth_headers)
    assert get_resp.status_code == 404  # soft-deleted tenders are not retrievable via the normal API
