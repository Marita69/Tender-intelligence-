"""
Postgres-native types (UUID, JSONB, ARRAY) don't have SQLite equivalents,
but the test suite (tests/conftest.py) intentionally runs against in-memory
SQLite for speed. Rather than force every test through a real Postgres
container, models here use dialect-portable types:

  - GUID: native UUID on Postgres, CHAR(32) hex string elsewhere.
  - JSON_VARIANT: JSONB on Postgres, plain JSON elsewhere.
  - STRING_ARRAY: real ARRAY(String) on Postgres, JSON-encoded list elsewhere.

This keeps SQLite tests meaningful for business logic and API contracts.
It does NOT replace running the real integration suite against Postgres in
CI (see docs/architecture/testing-strategy.md) — Postgres-only behavior
(ARRAY containment queries, JSONB operators, etc.) is not exercised by the
SQLite suite.
"""
import uuid

from sqlalchemy import JSON, CHAR, TypeDecorator
from sqlalchemy.dialects.postgresql import ARRAY as PG_ARRAY
from sqlalchemy.dialects.postgresql import JSONB
from sqlalchemy.dialects.postgresql import UUID as PG_UUID
from sqlalchemy.types import String


class GUID(TypeDecorator):
    """Platform-independent UUID type."""

    impl = CHAR
    cache_ok = True

    def load_dialect_impl(self, dialect):
        if dialect.name == "postgresql":
            return dialect.type_descriptor(PG_UUID(as_uuid=True))
        return dialect.type_descriptor(CHAR(32))

    def process_bind_param(self, value, dialect):
        if value is None:
            return value
        if dialect.name == "postgresql":
            return str(value)
        if not isinstance(value, uuid.UUID):
            value = uuid.UUID(value)
        return value.hex

    def process_result_value(self, value, dialect):
        if value is None:
            return value
        if isinstance(value, uuid.UUID):
            return value
        return uuid.UUID(value)


def json_variant():
    """JSONB on Postgres, plain JSON on everything else (same Python-side dict/list API)."""
    return JSON().with_variant(JSONB, "postgresql")


def string_array():
    """ARRAY(String) on Postgres, JSON-encoded list on everything else."""
    return JSON().with_variant(PG_ARRAY(String), "postgresql")
