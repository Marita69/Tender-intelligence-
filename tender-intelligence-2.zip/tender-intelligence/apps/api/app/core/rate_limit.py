"""
Rate limiting (flagged as a gap in PRODUCTION_GUIDE.md — now closed).

Uses slowapi (a Flask-limiter-style wrapper around `limits`) keyed by
client IP by default. In production behind a load balancer/CDN, make sure
`X-Forwarded-For` is trusted correctly (see get_remote_address behavior)
or your rate limit will key off the proxy's IP instead of the real client.

Limits are intentionally strict on auth endpoints (brute-force surface)
and looser elsewhere. Tune via the `@limiter.limit(...)` decorators in
each router — this module only sets up the shared limiter instance.
"""
from slowapi import Limiter
from slowapi.util import get_remote_address

from app.core.config import settings

# In-memory storage is fine for a single-process dev/small deployment; for
# multi-instance production, point storage_uri at the same Redis you're
# already running for Celery so limits are enforced across all replicas,
# e.g. storage_uri=settings.REDIS_URL.
limiter = Limiter(
    key_func=get_remote_address,
    storage_uri=settings.REDIS_URL if settings.APP_ENV != "development" else "memory://",
    default_limits=["200/minute"],
)
