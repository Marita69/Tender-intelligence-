"""
Password hashing and JWT issuance/verification.

Tenant isolation (spec §117.D) is NOT enforced here — this module only
handles identity. Isolation is enforced per-request in
app/security/tenancy.py via the `current_membership` dependency, which
scopes every query to the caller's organization_id.
"""
from datetime import datetime, timedelta, timezone
from typing import Any

from jose import JWTError, jwt
from passlib.context import CryptContext

from app.core.config import settings

pwd_context = CryptContext(schemes=["bcrypt"], deprecated="auto")

_BCRYPT_MAX_BYTES = 72


def _truncate_to_bcrypt_limit(password: str) -> str:
    """
    bcrypt ignores/rejects anything past 72 bytes. Rather than let a long
    passphrase 500 at signup, truncate deterministically (by UTF-8 bytes,
    not characters, so multi-byte input truncates safely) before hashing —
    the same truncation is applied on verify, so this is transparent to the
    user in both directions.
    """
    encoded = password.encode("utf-8")
    if len(encoded) <= _BCRYPT_MAX_BYTES:
        return password
    return encoded[:_BCRYPT_MAX_BYTES].decode("utf-8", errors="ignore")


def hash_password(password: str) -> str:
    return pwd_context.hash(_truncate_to_bcrypt_limit(password))


def verify_password(plain: str, hashed: str) -> bool:
    return pwd_context.verify(_truncate_to_bcrypt_limit(plain), hashed)


def create_token(subject: str, expires_minutes: int, token_type: str, extra: dict[str, Any] | None = None) -> str:
    now = datetime.now(timezone.utc)
    payload: dict[str, Any] = {
        "sub": subject,
        "type": token_type,
        "iat": now,
        "exp": now + timedelta(minutes=expires_minutes),
    }
    if extra:
        payload.update(extra)
    return jwt.encode(payload, settings.SECRET_KEY, algorithm=settings.JWT_ALGORITHM)


def create_access_token(user_id: str) -> str:
    return create_token(user_id, settings.ACCESS_TOKEN_EXPIRE_MINUTES, "access")


def create_refresh_token(user_id: str) -> str:
    return create_token(user_id, settings.REFRESH_TOKEN_EXPIRE_MINUTES, "refresh")


def decode_token(token: str) -> dict[str, Any] | None:
    try:
        return jwt.decode(token, settings.SECRET_KEY, algorithms=[settings.JWT_ALGORITHM])
    except JWTError:
        return None
