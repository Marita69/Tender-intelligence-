"""
Central application configuration.

All configuration is sourced from environment variables (see .env.example
at the repo root). Nothing here should be hard-coded per spec §1.1 (brand
name must be configurable) and §4.5 (no hard vendor dependency).
"""
from functools import lru_cache
from typing import Literal

from pydantic import Field
from pydantic_settings import BaseSettings, SettingsConfigDict


class Settings(BaseSettings):
    model_config = SettingsConfigDict(env_file=".env", extra="ignore")

    # --- Branding (never hard-code brand name elsewhere in the app) ---
    APP_NAME: str = Field(default="Tender Intelligence")
    APP_ENV: Literal["development", "staging", "production", "test"] = "development"
    API_BASE_URL: str = "http://localhost:8003"
    WEB_BASE_URL: str = "http://localhost:5174"

    # --- Security ---
    SECRET_KEY: str = Field(default="change-me-in-env")
    ACCESS_TOKEN_EXPIRE_MINUTES: int = 60 * 24
    REFRESH_TOKEN_EXPIRE_MINUTES: int = 60 * 24 * 14
    JWT_ALGORITHM: str = "HS256"

    # --- Platform admin ---
    # There is exactly one platform admin account, identified by email, not
    # by any in-app "make me admin" action. Whoever controls this mailbox
    # controls the admin panel — treat it like any other production secret.
    # On every signup/login, the matching user (if any) has
    # is_platform_admin set to True; every other account is guaranteed
    # False (see auth_service.py). Leave empty to disable platform admin
    # entirely.
    ADMIN_EMAIL: str = ""

    # --- Database ---
    DATABASE_URL: str = "postgresql+psycopg2://tender:tender@localhost:5432/tender_intelligence"
    ASYNC_DATABASE_URL: str = "postgresql+asyncpg://tender:tender@localhost:5432/tender_intelligence"

    # --- Redis / job queue ---
    REDIS_URL: str = "redis://localhost:6379/0"
    CELERY_TASK_ALWAYS_EAGER: bool = False  # True lets it run without a broker (dev fallback)

    # --- Object storage abstraction (spec §4.4) ---
    STORAGE_BACKEND: Literal["local", "s3"] = "local"
    STORAGE_LOCAL_PATH: str = "./storage/local"
    S3_BUCKET: str = ""
    S3_REGION: str = "eu-west-1"
    S3_ENDPOINT_URL: str | None = None  # set for MinIO / non-AWS S3-compatible
    S3_ACCESS_KEY_ID: str = ""
    S3_SECRET_ACCESS_KEY: str = ""

    # --- AI provider abstraction (spec §4.5) ---
    # Any of these can be the active provider (AI_PROVIDER); OPENROUTER and
    # NVIDIA both speak the OpenAI-compatible chat-completions API, so they
    # share one implementation (app/ai/providers/openai_compatible_provider.py)
    # parametrized by base_url/api_key/model — see PRODUCTION_GUIDE.md for
    # where to get free-tier keys and which model strings to use.
    #
    # This env-var value is only the STARTUP default. The actual active
    # provider/model can be changed at runtime without a redeploy via the
    # admin-only AI Provider panel (Admin Dashboard) — see
    # app/models/ai_settings.py / app/services/ai_settings_service.py. The
    # env vars below are what a fresh install falls back to before an
    # admin has ever changed anything.
    AI_PROVIDER: Literal["anthropic", "openrouter", "nvidia", "gemini", "deepseek", "mock"] = "mock"
    AI_TEMPERATURE: float = 0.0
    AI_MAX_RETRIES: int = 3
    AI_TIMEOUT_SECONDS: int = 120

    ANTHROPIC_API_KEY: str = ""
    AI_MODEL: str = "claude-sonnet-4-6"  # only used when AI_PROVIDER=anthropic

    # OpenRouter (https://openrouter.ai) — aggregates many providers behind
    # one OpenAI-compatible API/key, including several genuinely free
    # models (":free" suffix). Sign up, create a key at
    # openrouter.ai/keys, and pick any model from openrouter.ai/models.
    OPENROUTER_API_KEY: str = ""
    OPENROUTER_MODEL: str = "meta-llama/llama-3.3-70b-instruct:free"
    OPENROUTER_BASE_URL: str = "https://openrouter.ai/api/v1"

    # NVIDIA NIM (https://build.nvidia.com) — NVIDIA's hosted inference
    # API, OpenAI-compatible, with a free evaluation tier. Sign up, create
    # a key at build.nvidia.com, and pick a model from their catalog.
    NVIDIA_API_KEY: str = ""
    NVIDIA_MODEL: str = "meta/llama-3.1-70b-instruct"
    NVIDIA_BASE_URL: str = "https://integrate.api.nvidia.com/v1"

    # Google Gemini, via Google's OpenAI-compatibility endpoint (not the
    # native Gemini SDK/API shape — this lets it share the same generic
    # provider as OpenRouter/NVIDIA instead of a bespoke client). Get a
    # free-tier key at aistudio.google.com/apikey.
    GEMINI_API_KEY: str = ""
    GEMINI_MODEL: str = "gemini-2.0-flash"
    GEMINI_BASE_URL: str = "https://generativelanguage.googleapis.com/v1beta/openai"

    # DeepSeek (https://platform.deepseek.com) — OpenAI-compatible, low
    # cost rather than free, but explicitly requested alongside the free
    # options. Get a key at platform.deepseek.com/api_keys.
    DEEPSEEK_API_KEY: str = ""
    DEEPSEEK_MODEL: str = "deepseek-chat"
    DEEPSEEK_BASE_URL: str = "https://api.deepseek.com"

    # --- OCR (spec §4.6) ---
    OCR_PROVIDER: Literal["tesseract", "none"] = "tesseract"

    # --- Billing (stubbed abstraction; see services/billing_service.py) ---
    BILLING_PROVIDER: Literal["stripe", "none"] = "none"
    STRIPE_SECRET_KEY: str = ""
    STRIPE_WEBHOOK_SECRET: str = ""
    STRIPE_PRICE_ID: str = ""
    STRIPE_CREDITS_PER_PURCHASE: int = 10

    # --- Observability ---
    SENTRY_DSN: str = ""
    LOG_LEVEL: str = "INFO"

    # --- CORS ---
    CORS_ORIGINS: list[str] = ["http://localhost:5174"]

    # --- Uploads ---
    MAX_UPLOAD_SIZE_MB: int = 50
    ALLOWED_UPLOAD_EXTENSIONS: list[str] = [".pdf", ".docx", ".doc"]


@lru_cache
def get_settings() -> Settings:
    return Settings()


settings = get_settings()
