"""
Implements the pipeline diagram in spec §4.6:

    Uploaded PDF -> can extract text? -> yes: extract / no: OCR -> normalize -> page mapping

Every page's text is returned with its page number attached so that every
downstream Requirement can cite (document_id, page_number) per the
evidence model (spec §2.2, §2.6).
"""
from __future__ import annotations

from dataclasses import dataclass
from io import BytesIO

from app.core.logging import get_logger
from app.core.config import settings

logger = get_logger(__name__)


class PasswordProtectedError(Exception):
    pass


class CorruptedDocumentError(Exception):
    pass


@dataclass
class ExtractedPage:
    page_number: int  # 1-indexed
    text: str
    method: str  # "text" | "ocr"
    ocr_confidence: float | None = None


@dataclass
class ExtractionResult:
    pages: list[ExtractedPage]
    page_count: int
    has_text_layer: bool
    ocr_used: bool


MIN_CHARS_PER_PAGE_FOR_TEXT_LAYER = 20


def extract_pdf(file_bytes: bytes) -> ExtractionResult:
    """
    Extract text per page, falling back to OCR for pages with no usable
    text layer. Never raises for "just some pages failed" — per spec
    principle #9, an analysis must remain useful even if some pages can't
    be parsed; individual page failures are recorded as empty text with
    method="ocr" and a low/zero confidence rather than aborting the whole
    document.
    """
    import pypdf

    try:
        reader = pypdf.PdfReader(BytesIO(file_bytes))
    except Exception as exc:  # noqa: BLE001 - any parse failure is "corrupted" from our perspective
        raise CorruptedDocumentError(str(exc)) from exc

    if reader.is_encrypted:
        # Try an empty password first (common for "restricted" not "protected" PDFs)
        try:
            if reader.decrypt("") == 0:
                raise PasswordProtectedError("Document requires a password")
        except Exception as exc:
            raise PasswordProtectedError("Document requires a password") from exc

    pages: list[ExtractedPage] = []
    any_text_layer = False
    any_ocr = False

    for i, page in enumerate(reader.pages, start=1):
        try:
            text = (page.extract_text() or "").strip()
        except Exception:  # noqa: BLE001
            text = ""

        if len(text) >= MIN_CHARS_PER_PAGE_FOR_TEXT_LAYER:
            any_text_layer = True
            pages.append(ExtractedPage(page_number=i, text=text, method="text"))
        else:
            ocr_text, confidence = _ocr_page(file_bytes, i)
            any_ocr = True
            pages.append(ExtractedPage(page_number=i, text=ocr_text, method="ocr", ocr_confidence=confidence))

    return ExtractionResult(
        pages=pages,
        page_count=len(pages),
        has_text_layer=any_text_layer,
        ocr_used=any_ocr,
    )


def _ocr_page(file_bytes: bytes, page_number: int) -> tuple[str, float]:
    """
    Rasterize a single page and run OCR. Returns (text, confidence 0-1).
    If OCR is disabled or fails, returns ("", 0.0) rather than raising —
    the page is then surfaced in the UI as "could not be parsed" per
    spec §107/§2.9, not silently dropped.
    """
    if settings.OCR_PROVIDER == "none":
        logger.warning("ocr_disabled_page_skipped", page_number=page_number)
        return "", 0.0

    try:
        import pytesseract
        from pdf2image import convert_from_bytes

        images = convert_from_bytes(file_bytes, first_page=page_number, last_page=page_number)
        if not images:
            return "", 0.0
        data = pytesseract.image_to_data(images[0], output_type=pytesseract.Output.DICT)
        words = [w for w in data.get("text", []) if w.strip()]
        confidences = [int(c) for c in data.get("conf", []) if str(c).lstrip("-").isdigit() and int(c) >= 0]
        avg_conf = (sum(confidences) / len(confidences) / 100.0) if confidences else 0.0
        return " ".join(words), avg_conf
    except Exception as exc:  # noqa: BLE001
        logger.error("ocr_page_failed", page_number=page_number, error=str(exc))
        return "", 0.0


def extract_docx(file_bytes: bytes) -> ExtractionResult:
    """DOCX has no OCR fallback path — it's already-digital text by definition."""
    import docx

    document = docx.Document(BytesIO(file_bytes))
    full_text = "\n".join(p.text for p in document.paragraphs)
    # DOCX has no native page concept; we treat the whole document as "page 1"
    # and rely on paragraph-index citation for finer granularity if needed later.
    return ExtractionResult(
        pages=[ExtractedPage(page_number=1, text=full_text, method="text")],
        page_count=1,
        has_text_layer=bool(full_text.strip()),
        ocr_used=False,
    )
