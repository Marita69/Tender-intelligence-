"""
Tenant isolation enforcement (spec §117.D — non-negotiable).

Every organization-scoped route depends on `current_membership`, which:
  1. Verifies the JWT and loads the User.
  2. Resolves which Organization the request is acting on (via
     X-Organization-Id header, since a user may belong to several).
  3. Confirms an OrganizationMembership row exists for that (user, org) pair.
  4. Returns a CurrentContext that every service function must use to scope
     queries — services should filter by `context.organization_id` on every
     tenant-scoped table, never trust an organization_id from the request body.

This is deliberately the ONLY sanctioned way to get an organization_id into
a service call.
"""
from __future__ import annotations

import uuid
from dataclasses import dataclass

from fastapi import Depends, Header, HTTPException, status
from fastapi.security import OAuth2PasswordBearer
from sqlalchemy import select
from sqlalchemy.orm import Session

from app.core.security import decode_token
from app.db.session import get_db
from app.models.enums import MembershipRole
from app.models.organization import Organization, OrganizationMembership, User

oauth2_scheme = OAuth2PasswordBearer(tokenUrl="/api/v1/auth/login", auto_error=False)


@dataclass
class CurrentContext:
    user: User
    organization_id: uuid.UUID
    role: MembershipRole


def get_current_user(
    token: str | None = Depends(oauth2_scheme),
    db: Session = Depends(get_db),
) -> User:
    if not token:
        raise HTTPException(status.HTTP_401_UNAUTHORIZED, "Not authenticated")
    payload = decode_token(token)
    if not payload or payload.get("type") != "access":
        raise HTTPException(status.HTTP_401_UNAUTHORIZED, "Invalid or expired token")
    user = db.get(User, uuid.UUID(payload["sub"]))
    if not user or not user.is_active:
        raise HTTPException(status.HTTP_401_UNAUTHORIZED, "User not found or inactive")
    return user


def current_membership(
    x_organization_id: str = Header(..., alias="X-Organization-Id"),
    user: User = Depends(get_current_user),
    db: Session = Depends(get_db),
) -> CurrentContext:
    try:
        org_id = uuid.UUID(x_organization_id)
    except ValueError as exc:
        raise HTTPException(status.HTTP_400_BAD_REQUEST, "Invalid X-Organization-Id") from exc

    membership = db.execute(
        select(OrganizationMembership).where(
            OrganizationMembership.user_id == user.id,
            OrganizationMembership.organization_id == org_id,
        )
    ).scalar_one_or_none()

    if membership is None:
        # Deliberately identical error to "org doesn't exist" — never leak
        # whether an organization_id is valid to a non-member.
        raise HTTPException(status.HTTP_403_FORBIDDEN, "Not a member of this organization")

    organization = db.get(Organization, org_id)
    if organization is not None and organization.is_suspended and not user.is_platform_admin:
        # A suspended org's members are locked out of every org-scoped
        # route (this dependency gates all of them) — but the platform
        # admin can still reach admin-only routes about it (e.g. to
        # un-suspend). Admin routes don't use this dependency at all, so
        # this exemption only matters if the admin also happens to be a
        # member of the suspended org.
        raise HTTPException(status.HTTP_403_FORBIDDEN, "This organization has been suspended")

    return CurrentContext(user=user, organization_id=org_id, role=membership.role)


def require_role(*allowed: MembershipRole):
    def _checker(ctx: CurrentContext = Depends(current_membership)) -> CurrentContext:
        if ctx.role not in allowed:
            raise HTTPException(status.HTTP_403_FORBIDDEN, "Insufficient role for this action")
        return ctx

    return _checker


def require_platform_admin(user: User = Depends(get_current_user)) -> User:
    if not user.is_platform_admin:
        raise HTTPException(status.HTTP_403_FORBIDDEN, "Platform admin only")
    return user
