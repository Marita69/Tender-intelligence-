import uuid

from sqlalchemy import ForeignKey, Integer, String, Text
from sqlalchemy.orm import Mapped, mapped_column

from app.db.types import GUID, json_variant, string_array
from app.db.base import Base, TimestampMixin, UUIDPKMixin


class CompanyProfile(Base, UUIDPKMixin, TimestampMixin):
    """
    One profile per organization (spec §6 'Set company profile' step).
    Used by the bid/no-bid scoring service to compare tender requirements
    against what the company can actually demonstrate.
    """

    __tablename__ = "company_profiles"

    organization_id: Mapped[uuid.UUID] = mapped_column(
        GUID(), ForeignKey("organizations.id"), nullable=False, unique=True
    )

    legal_name: Mapped[str] = mapped_column(String(255), nullable=False)
    registration_number: Mapped[str | None] = mapped_column(String(100), nullable=True)
    years_in_operation: Mapped[int | None] = mapped_column(Integer, nullable=True)
    sectors: Mapped[list[str]] = mapped_column(string_array(), default=list)
    certifications: Mapped[list[str]] = mapped_column(string_array(), default=list)
    annual_turnover_band: Mapped[str | None] = mapped_column(String(100), nullable=True)
    key_personnel: Mapped[dict] = mapped_column(json_variant(), default=dict)  # {name, role, years_experience}[]
    past_performance: Mapped[dict] = mapped_column(json_variant(), default=dict)  # references/similar contracts
    financial_capacity_notes: Mapped[str | None] = mapped_column(Text, nullable=True)
    standard_documents: Mapped[dict] = mapped_column(
        json_variant(), default=dict
    )  # library refs: registration cert, tax clearance, etc.
