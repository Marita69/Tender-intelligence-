import uuid
from datetime import date

from sqlalchemy import BigInteger, Date, ForeignKey, String
from sqlalchemy.orm import Mapped, mapped_column

from app.db.base import Base, SoftDeleteMixin, TimestampMixin, UUIDPKMixin
from app.db.types import GUID
from app.models.enums import CompanyDocumentStatus


class CompanyDocument(Base, UUIDPKMixin, TimestampMixin, SoftDeleteMixin):
    """
    Reusable compliance evidence at the organization level (spec: "Document
    Library" on the Company Profile page) — things like a registration
    certificate or ISO certification that get re-used across many tenders,
    as opposed to TenderDocument which is the tender notice itself.

    Deliberately a separate table/model from TenderDocument even though
    both wrap a stored file: their lifecycle, ownership (org vs tender),
    and semantics (expiry-tracked evidence vs a document to be parsed) are
    different enough that merging them would mean nullable-everything on
    both sides. ChecklistItem.linked_document_id still points at
    TenderDocument (the tender-specific proof actually submitted); this
    table is the org's reusable library those get copied/uploaded from.
    """

    __tablename__ = "company_documents"

    organization_id: Mapped[uuid.UUID] = mapped_column(GUID(), ForeignKey("organizations.id"), nullable=False, index=True)
    uploaded_by_user_id: Mapped[uuid.UUID] = mapped_column(GUID(), ForeignKey("users.id"), nullable=False)

    name: Mapped[str] = mapped_column(String(500), nullable=False)
    category: Mapped[str] = mapped_column(String(100), nullable=False)  # e.g. "legal", "financial", "certification"
    issuing_body: Mapped[str | None] = mapped_column(String(255), nullable=True)

    storage_key: Mapped[str] = mapped_column(String(1000), nullable=False)
    original_filename: Mapped[str] = mapped_column(String(500), nullable=False)
    content_type: Mapped[str] = mapped_column(String(100), nullable=False)
    size_bytes: Mapped[int] = mapped_column(BigInteger, nullable=False)

    expiry_date: Mapped[date | None] = mapped_column(Date, nullable=True)
    # Set by an AI classification pass in a future iteration; nullable and
    # unused by any pipeline today — see PAGES.md for why this is stubbed.
    ai_confidence: Mapped[float | None] = mapped_column(nullable=True)

    @property
    def status(self) -> CompanyDocumentStatus:
        from datetime import date as _date, timedelta

        if self.expiry_date is None:
            return CompanyDocumentStatus.NO_EXPIRY
        today = _date.today()
        if self.expiry_date < today:
            return CompanyDocumentStatus.EXPIRED
        if self.expiry_date <= today + timedelta(days=30):
            return CompanyDocumentStatus.EXPIRING_SOON
        return CompanyDocumentStatus.VALID
