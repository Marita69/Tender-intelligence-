import uuid
from datetime import datetime

from sqlalchemy import DateTime, ForeignKey, String, Text
from sqlalchemy.orm import Mapped, mapped_column, relationship

from app.db.types import GUID
from app.db.base import Base, SoftDeleteMixin, TimestampMixin, UUIDPKMixin
from app.models.enums import TenderStatus


class Tender(Base, UUIDPKMixin, TimestampMixin, SoftDeleteMixin):
    __tablename__ = "tenders"

    organization_id: Mapped[uuid.UUID] = mapped_column(
        GUID(), ForeignKey("organizations.id"), nullable=False, index=True
    )
    created_by_user_id: Mapped[uuid.UUID] = mapped_column(GUID(), ForeignKey("users.id"), nullable=False)

    title: Mapped[str] = mapped_column(String(500), nullable=False)
    reference_number: Mapped[str | None] = mapped_column(String(255), nullable=True)
    issuing_entity: Mapped[str | None] = mapped_column(String(500), nullable=True)
    status: Mapped[TenderStatus] = mapped_column(default=TenderStatus.DRAFT, nullable=False)

    # Denormalized for fast dashboard/list rendering; source of truth is the
    # extracted Requirement rows of type DEADLINE (with evidence).
    submission_deadline: Mapped[datetime | None] = mapped_column(DateTime(timezone=True), nullable=True)
    submission_deadline_timezone: Mapped[str | None] = mapped_column(String(64), nullable=True)
    submission_deadline_is_uncertain: Mapped[bool] = mapped_column(default=False, nullable=False)

    bid_outcome: Mapped[str | None] = mapped_column(String(50), nullable=True)  # won/lost/withdrawn/not_submitted
    notes: Mapped[str | None] = mapped_column(Text, nullable=True)

    documents: Mapped[list["TenderDocument"]] = relationship(back_populates="tender", cascade="all, delete-orphan")
