"""
Import every model module here so that `Base.metadata` is fully populated
before Alembic's `--autogenerate` (or `Base.metadata.create_all` in tests)
runs. If you add a new model file, add its import here too.
"""
from app.models.analysis import BidAssessment, Evidence, Requirement, Risk  # noqa: F401
from app.models.billing import BillingEvent, UsageCredit  # noqa: F401
from app.models.checklist import ChecklistItem, Task, TenderQuestion  # noqa: F401
from app.models.company_document import CompanyDocument  # noqa: F401
from app.models.company_profile import CompanyProfile  # noqa: F401
from app.models.ai_settings import AIProviderSetting  # noqa: F401
from app.models.document import AnalysisJob, DocumentPage, TenderDocument  # noqa: F401
from app.models.notification import Notification, NotificationPreference  # noqa: F401
from app.models.organization import Organization, OrganizationMembership, User  # noqa: F401
from app.models.review import AuditLog, FieldCorrection, ReviewItem, TenderDecision  # noqa: F401
from app.models.tender import Tender  # noqa: F401
