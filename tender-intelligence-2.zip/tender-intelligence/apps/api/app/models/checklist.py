import uuid
from datetime import datetime

from sqlalchemy import Boolean, DateTime, ForeignKey, String, Text
from sqlalchemy.orm import Mapped, mapped_column

from app.db.types import GUID
from app.db.base import Base, TimestampMixin, UUIDPKMixin
from app.models.enums import ChecklistItemStatus, TaskPriority, TaskStatus


class ChecklistItem(Base, UUIDPKMixin, TimestampMixin):
    """
    One compliance checklist row, usually generated 1:1 from a
    RequirementType.MANDATORY_DOCUMENT or ELIGIBILITY requirement, plus a
    link into the company's document library if a matching doc exists.
    """

    __tablename__ = "checklist_items"

    tender_id: Mapped[uuid.UUID] = mapped_column(GUID(), ForeignKey("tenders.id"), nullable=False, index=True)
    requirement_id: Mapped[uuid.UUID | None] = mapped_column(
        GUID(), ForeignKey("requirements.id"), nullable=True
    )

    label: Mapped[str] = mapped_column(String(500), nullable=False)
    status: Mapped[ChecklistItemStatus] = mapped_column(default=ChecklistItemStatus.MISSING, nullable=False)
    linked_document_id: Mapped[uuid.UUID | None] = mapped_column(
        GUID(), ForeignKey("tender_documents.id"), nullable=True
    )
    notes: Mapped[str | None] = mapped_column(Text, nullable=True)


class Task(Base, UUIDPKMixin, TimestampMixin):
    """Preparation task, may be auto-generated from a checklist item or manual."""

    __tablename__ = "tasks"

    tender_id: Mapped[uuid.UUID] = mapped_column(GUID(), ForeignKey("tenders.id"), nullable=False, index=True)
    checklist_item_id: Mapped[uuid.UUID | None] = mapped_column(
        GUID(), ForeignKey("checklist_items.id"), nullable=True
    )
    assigned_to_user_id: Mapped[uuid.UUID | None] = mapped_column(GUID(), ForeignKey("users.id"), nullable=True)

    title: Mapped[str] = mapped_column(String(500), nullable=False)
    description: Mapped[str | None] = mapped_column(Text, nullable=True)
    status: Mapped[TaskStatus] = mapped_column(default=TaskStatus.TODO, nullable=False)
    priority: Mapped[TaskPriority] = mapped_column(default=TaskPriority.MEDIUM, nullable=False)
    due_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True), nullable=True)


class TenderQuestion(Base, UUIDPKMixin, TimestampMixin):
    """
    An ambiguity or open question the AI flagged (spec: 'Tender questions /
    ambiguities' step) — distinct from Risk because it's something the user
    may need to ask the procuring entity to clarify, not necessarily a risk.
    """

    __tablename__ = "tender_questions"

    tender_id: Mapped[uuid.UUID] = mapped_column(GUID(), ForeignKey("tenders.id"), nullable=False, index=True)
    related_requirement_id: Mapped[uuid.UUID | None] = mapped_column(
        GUID(), ForeignKey("requirements.id"), nullable=True
    )
    question_text: Mapped[str] = mapped_column(Text, nullable=False)
    is_resolved: Mapped[bool] = mapped_column(Boolean, default=False, nullable=False)
    resolution_notes: Mapped[str | None] = mapped_column(Text, nullable=True)
