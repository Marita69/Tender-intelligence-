import enum


class MembershipRole(str, enum.Enum):
    OWNER = "owner"
    ADMIN = "admin"
    MEMBER = "member"
    VIEWER = "viewer"


class DocumentStatus(str, enum.Enum):
    UPLOADED = "uploaded"
    VALIDATING = "validating"
    VALID = "valid"
    INVALID = "invalid"
    EXTRACTING = "extracting"
    EXTRACTED = "extracted"
    FAILED = "failed"


class TenderStatus(str, enum.Enum):
    DRAFT = "draft"
    PROCESSING = "processing"
    ANALYZED = "analyzed"
    FAILED = "failed"
    ARCHIVED = "archived"


class AnalysisJobStatus(str, enum.Enum):
    PENDING = "pending"
    RUNNING = "running"
    SUCCEEDED = "succeeded"
    FAILED = "failed"
    PARTIALLY_SUCCEEDED = "partially_succeeded"


class RequirementType(str, enum.Enum):
    ELIGIBILITY = "eligibility"
    MANDATORY_DOCUMENT = "mandatory_document"
    DEADLINE = "deadline"
    FINANCIAL = "financial"
    BID_SECURITY = "bid_security"
    TECHNICAL = "technical"
    EVALUATION_CRITERION = "evaluation_criterion"
    SUBMISSION_INSTRUCTION = "submission_instruction"
    CONTRACT_TERM = "contract_term"


class ConfidenceLevel(str, enum.Enum):
    HIGH = "high"
    MEDIUM = "medium"
    LOW = "low"
    UNKNOWN = "unknown"


class RiskSeverity(str, enum.Enum):
    CRITICAL = "critical"
    HIGH = "high"
    MEDIUM = "medium"
    LOW = "low"


class BidRecommendation(str, enum.Enum):
    BID = "bid"
    CONDITIONAL_BID = "conditional_bid"
    NO_BID = "no_bid"
    INSUFFICIENT_INFORMATION = "insufficient_information"


class ChecklistItemStatus(str, enum.Enum):
    MISSING = "missing"
    IN_PROGRESS = "in_progress"
    COMPLETE = "complete"
    NOT_APPLICABLE = "not_applicable"


class CompanyDocumentStatus(str, enum.Enum):
    """Computed, not stored directly — see CompanyDocument.status property.
    Kept as an enum for a consistent frontend contract (icon/color per
    value), the same pattern as every other status field in this app."""

    VALID = "valid"
    EXPIRING_SOON = "expiring_soon"
    EXPIRED = "expired"
    NO_EXPIRY = "no_expiry"


class TaskStatus(str, enum.Enum):
    TODO = "todo"
    IN_PROGRESS = "in_progress"
    UNDER_REVIEW = "under_review"
    DONE = "done"
    BLOCKED = "blocked"


class TaskPriority(str, enum.Enum):
    CRITICAL = "critical"
    HIGH = "high"
    MEDIUM = "medium"
    LOW = "low"


class ReviewStatus(str, enum.Enum):
    NEEDS_REVIEW = "needs_review"
    REVIEWED = "reviewed"
    REJECTED = "rejected"
    CORRECTED = "corrected"
