import enum
import uuid

from sqlalchemy import Boolean, ForeignKey, String, Text
from sqlalchemy.orm import Mapped, mapped_column

from app.db.base import Base, TimestampMixin, UUIDPKMixin
from app.db.types import GUID


class NotificationType(str, enum.Enum):
    DEADLINE = "deadline"
    COMPLIANCE = "compliance"
    ANALYSIS = "analysis"
    DOCUMENT_EXPIRY = "document_expiry"
    TASK = "task"
    SYSTEM = "system"


class Notification(Base, UUIDPKMixin, TimestampMixin):
    """
    Org-scoped by default; `user_id` narrows it to one person (e.g. "your
    analysis finished") — NULL means every member of the organization sees
    it (e.g. "a shared document is expiring"). There is no separate
    "dismissed" vs "read" state; read is enough for this app's needs.
    """

    __tablename__ = "notifications"

    organization_id: Mapped[uuid.UUID] = mapped_column(GUID(), ForeignKey("organizations.id"), nullable=False, index=True)
    user_id: Mapped[uuid.UUID | None] = mapped_column(GUID(), ForeignKey("users.id"), nullable=True, index=True)
    tender_id: Mapped[uuid.UUID | None] = mapped_column(GUID(), ForeignKey("tenders.id"), nullable=True)

    type: Mapped[NotificationType] = mapped_column(nullable=False)
    title: Mapped[str] = mapped_column(String(500), nullable=False)
    body: Mapped[str | None] = mapped_column(Text, nullable=True)
    is_read: Mapped[bool] = mapped_column(Boolean, default=False, nullable=False)


class NotificationPreference(Base, UUIDPKMixin, TimestampMixin):
    """One row per user. Created lazily with defaults on first read/write —
    see notification_service.get_preferences."""

    __tablename__ = "notification_preferences"

    user_id: Mapped[uuid.UUID] = mapped_column(GUID(), ForeignKey("users.id"), nullable=False, unique=True)

    email_digest: Mapped[bool] = mapped_column(Boolean, default=False, nullable=False)
    in_app_alerts: Mapped[bool] = mapped_column(Boolean, default=True, nullable=False)
    alert_critical_deadlines: Mapped[bool] = mapped_column(Boolean, default=True, nullable=False)
    alert_compliance: Mapped[bool] = mapped_column(Boolean, default=True, nullable=False)
    alert_analysis_complete: Mapped[bool] = mapped_column(Boolean, default=True, nullable=False)
    alert_team_activity: Mapped[bool] = mapped_column(Boolean, default=False, nullable=False)
