import uuid
from datetime import datetime

from sqlalchemy import Boolean, DateTime, Float, ForeignKey, Integer, String, Text
from sqlalchemy.orm import Mapped, mapped_column, relationship

from app.db.types import GUID, json_variant
from app.db.base import Base, TimestampMixin, UUIDPKMixin
from app.models.enums import BidRecommendation, ConfidenceLevel, RequirementType, RiskSeverity


class Requirement(Base, UUIDPKMixin, TimestampMixin):
    """
    A single extracted fact of any RequirementType (eligibility, mandatory
    document, deadline, financial, bid security, technical, evaluation
    criterion, submission instruction, or contract term).

    Non-negotiable per spec §117.C: every critical extracted fact must have
    source evidence -> see Evidence, linked 1..N per requirement.
    Corrections are tracked separately (see review.py) and never overwrite
    history (spec §110).
    """

    __tablename__ = "requirements"

    tender_id: Mapped[uuid.UUID] = mapped_column(GUID(), ForeignKey("tenders.id"), nullable=False, index=True)
    analysis_job_id: Mapped[uuid.UUID] = mapped_column(GUID(), ForeignKey("analysis_jobs.id"), nullable=False)

    type: Mapped[RequirementType] = mapped_column(nullable=False, index=True)
    summary: Mapped[str] = mapped_column(Text, nullable=False)  # short human-readable statement
    detail: Mapped[str | None] = mapped_column(Text, nullable=True)
    structured_value: Mapped[dict] = mapped_column(json_variant(), default=dict)  # type-specific fields, e.g. currency/amount

    confidence: Mapped[ConfidenceLevel] = mapped_column(default=ConfidenceLevel.MEDIUM, nullable=False)
    is_inferred: Mapped[bool] = mapped_column(
        Boolean, default=False, nullable=False
    )  # True = AI inference, False = directly stated in source (spec principle #3)
    is_unknown: Mapped[bool] = mapped_column(Boolean, default=False, nullable=False)  # explicitly "could not determine"

    # Deadline-specific denormalized fields for fast querying/sorting.
    deadline_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True), nullable=True)
    deadline_timezone: Mapped[str | None] = mapped_column(String(64), nullable=True)
    supersedes_requirement_id: Mapped[uuid.UUID | None] = mapped_column(
        GUID(), ForeignKey("requirements.id"), nullable=True
    )  # for amended deadlines / addenda (spec §107)

    has_conflict: Mapped[bool] = mapped_column(Boolean, default=False, nullable=False)
    conflict_notes: Mapped[str | None] = mapped_column(Text, nullable=True)

    references_missing_document: Mapped[bool] = mapped_column(Boolean, default=False, nullable=False)
    referenced_document_name: Mapped[str | None] = mapped_column(String(500), nullable=True)  # spec §108

    evidence: Mapped[list["Evidence"]] = relationship(back_populates="requirement", cascade="all, delete-orphan")


class Evidence(Base, UUIDPKMixin, TimestampMixin):
    """Source citation: exact page + quoted span backing a Requirement."""

    __tablename__ = "evidence"

    requirement_id: Mapped[uuid.UUID] = mapped_column(GUID(), ForeignKey("requirements.id"), nullable=False)
    document_id: Mapped[uuid.UUID] = mapped_column(GUID(), ForeignKey("tender_documents.id"), nullable=False)
    page_number: Mapped[int] = mapped_column(Integer, nullable=False)
    quoted_text: Mapped[str] = mapped_column(Text, nullable=False)
    char_start: Mapped[int | None] = mapped_column(Integer, nullable=True)
    char_end: Mapped[int | None] = mapped_column(Integer, nullable=True)

    requirement: Mapped["Requirement"] = relationship(back_populates="evidence")


class Risk(Base, UUIDPKMixin, TimestampMixin):
    __tablename__ = "risks"

    tender_id: Mapped[uuid.UUID] = mapped_column(GUID(), ForeignKey("tenders.id"), nullable=False, index=True)
    analysis_job_id: Mapped[uuid.UUID] = mapped_column(GUID(), ForeignKey("analysis_jobs.id"), nullable=False)

    title: Mapped[str] = mapped_column(String(500), nullable=False)
    description: Mapped[str] = mapped_column(Text, nullable=False)
    severity: Mapped[RiskSeverity] = mapped_column(nullable=False)
    is_disqualifying: Mapped[bool] = mapped_column(Boolean, default=False, nullable=False)
    related_requirement_id: Mapped[uuid.UUID | None] = mapped_column(
        GUID(), ForeignKey("requirements.id"), nullable=True
    )


class BidAssessment(Base, UUIDPKMixin, TimestampMixin):
    """
    Bid/no-bid recommendation for one analysis run. Never auto-decides for
    the user (spec §117.M) — this is a recommendation with a documented
    rationale and score breakdown, always overridable by a human decision
    recorded in TenderDecision (see review.py).
    """

    __tablename__ = "bid_assessments"

    tender_id: Mapped[uuid.UUID] = mapped_column(GUID(), ForeignKey("tenders.id"), nullable=False, index=True)
    analysis_job_id: Mapped[uuid.UUID] = mapped_column(GUID(), ForeignKey("analysis_jobs.id"), nullable=False)

    recommendation: Mapped[BidRecommendation] = mapped_column(nullable=False)
    score: Mapped[float] = mapped_column(Float, nullable=False)  # 0-100
    confidence: Mapped[ConfidenceLevel] = mapped_column(default=ConfidenceLevel.MEDIUM, nullable=False)
    rationale: Mapped[str] = mapped_column(Text, nullable=False)
    score_breakdown: Mapped[dict] = mapped_column(json_variant(), default=dict)  # {criterion: {score, weight, notes}}
    disqualifying_factors: Mapped[list] = mapped_column(json_variant(), default=list)
