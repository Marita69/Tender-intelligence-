import uuid

from sqlalchemy import ForeignKey, Integer, String
from sqlalchemy.orm import Mapped, mapped_column

from app.db.types import GUID, json_variant
from app.db.base import Base, TimestampMixin, UUIDPKMixin


class UsageCredit(Base, UUIDPKMixin, TimestampMixin):
    """
    Spec §117.I: payment events must be idempotent. We model credits as a
    ledger (append-only balance changes) rather than a single mutable
    integer, so replayed webhooks are naturally idempotent when keyed by
    external_event_id.
    """

    __tablename__ = "usage_credits"

    organization_id: Mapped[uuid.UUID] = mapped_column(GUID(), ForeignKey("organizations.id"), nullable=False, index=True)
    delta: Mapped[int] = mapped_column(Integer, nullable=False)  # positive = credit added, negative = consumed
    reason: Mapped[str] = mapped_column(String(100), nullable=False)  # "purchase" | "analysis_consumed" | "plan_grant"
    external_event_id: Mapped[str | None] = mapped_column(String(255), unique=True, nullable=True)
    metadata_json: Mapped[dict] = mapped_column(json_variant(), default=dict)


class BillingEvent(Base, UUIDPKMixin, TimestampMixin):
    """Raw webhook events from the billing provider, stored for replay/audit."""

    __tablename__ = "billing_events"

    provider: Mapped[str] = mapped_column(String(50), nullable=False)
    external_event_id: Mapped[str] = mapped_column(String(255), unique=True, nullable=False)
    event_type: Mapped[str] = mapped_column(String(100), nullable=False)
    payload: Mapped[dict] = mapped_column(json_variant(), default=dict)
    processed: Mapped[bool] = mapped_column(default=False, nullable=False)
