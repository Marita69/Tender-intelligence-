import uuid

from sqlalchemy import BigInteger, ForeignKey, Integer, String, Text
from sqlalchemy.orm import Mapped, mapped_column, relationship

from app.db.types import GUID, json_variant
from app.db.base import Base, SoftDeleteMixin, TimestampMixin, UUIDPKMixin
from app.models.enums import AnalysisJobStatus, DocumentStatus


class TenderDocument(Base, UUIDPKMixin, TimestampMixin, SoftDeleteMixin):
    """
    A single uploaded file attached to a tender (spec §107: multiple addenda,
    external forms, annexes are all separate TenderDocument rows linked to
    the same tender_id).
    """

    __tablename__ = "tender_documents"

    tender_id: Mapped[uuid.UUID] = mapped_column(GUID(), ForeignKey("tenders.id"), nullable=False)
    organization_id: Mapped[uuid.UUID] = mapped_column(
        GUID(), ForeignKey("organizations.id"), nullable=False, index=True
    )

    original_filename: Mapped[str] = mapped_column(String(500), nullable=False)
    storage_key: Mapped[str] = mapped_column(String(1000), nullable=False)  # opaque key into storage abstraction
    content_type: Mapped[str] = mapped_column(String(100), nullable=False)
    size_bytes: Mapped[int] = mapped_column(BigInteger, nullable=False)
    sha256: Mapped[str] = mapped_column(String(64), nullable=False)

    document_kind: Mapped[str] = mapped_column(
        String(50), default="tender_document"
    )  # tender_document | addendum | referenced_form | company_evidence

    status: Mapped[DocumentStatus] = mapped_column(default=DocumentStatus.UPLOADED, nullable=False)
    status_reason: Mapped[str | None] = mapped_column(Text, nullable=True)  # e.g. "password protected"
    page_count: Mapped[int | None] = mapped_column(Integer, nullable=True)
    has_text_layer: Mapped[bool | None] = mapped_column(nullable=True)
    ocr_used: Mapped[bool] = mapped_column(default=False, nullable=False)

    tender: Mapped["Tender"] = relationship(back_populates="documents")
    pages: Mapped[list["DocumentPage"]] = relationship(back_populates="document", cascade="all, delete-orphan")


class DocumentPage(Base, UUIDPKMixin, TimestampMixin):
    """
    Page-level extracted text, kept separate from the raw file so every
    extracted fact can cite (document_id, page_number) per spec §2.2/§2.6.
    """

    __tablename__ = "document_pages"

    document_id: Mapped[uuid.UUID] = mapped_column(
        GUID(), ForeignKey("tender_documents.id"), nullable=False, index=True
    )
    page_number: Mapped[int] = mapped_column(Integer, nullable=False)
    raw_text: Mapped[str | None] = mapped_column(Text, nullable=True)
    extraction_method: Mapped[str] = mapped_column(String(30), default="text")  # text | ocr
    ocr_confidence: Mapped[float | None] = mapped_column(nullable=True)

    document: Mapped["TenderDocument"] = relationship(back_populates="pages")


class AnalysisJob(Base, UUIDPKMixin, TimestampMixin):
    """
    One run of the full extraction+AI-analysis pipeline for a tender.
    Spec §117.H: historical analysis must remain reproducible, so we pin
    the model/prompt version used for this specific job.
    """

    __tablename__ = "analysis_jobs"

    tender_id: Mapped[uuid.UUID] = mapped_column(GUID(), ForeignKey("tenders.id"), nullable=False)
    organization_id: Mapped[uuid.UUID] = mapped_column(
        GUID(), ForeignKey("organizations.id"), nullable=False, index=True
    )

    status: Mapped[AnalysisJobStatus] = mapped_column(default=AnalysisJobStatus.PENDING, nullable=False)
    ai_provider: Mapped[str] = mapped_column(String(50), nullable=False)
    ai_model: Mapped[str] = mapped_column(String(100), nullable=False)
    prompt_version: Mapped[str] = mapped_column(String(50), nullable=False)
    pipeline_version: Mapped[str] = mapped_column(String(50), nullable=False)

    error_message: Mapped[str | None] = mapped_column(Text, nullable=True)
    step_log: Mapped[list] = mapped_column(json_variant(), default=list)  # [{step, status, started_at, finished_at}]
    token_usage: Mapped[dict] = mapped_column(json_variant(), default=dict)  # {input_tokens, output_tokens, cost_estimate}
