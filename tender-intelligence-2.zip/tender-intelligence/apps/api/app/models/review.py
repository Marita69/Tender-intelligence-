import uuid
from datetime import datetime

from sqlalchemy import DateTime, ForeignKey, String, Text
from sqlalchemy.orm import Mapped, mapped_column

from app.db.types import GUID, json_variant
from app.db.base import Base, TimestampMixin, UUIDPKMixin
from app.models.enums import ReviewStatus


class ReviewItem(Base, UUIDPKMixin, TimestampMixin):
    """
    Spec §109 Human Review Queue. Created automatically for low-confidence
    facts, conflicting requirements, missing referenced documents, critical
    eligibility decisions, uncertain deadlines, and uncertain bid scores.
    """

    __tablename__ = "review_items"

    tender_id: Mapped[uuid.UUID] = mapped_column(GUID(), ForeignKey("tenders.id"), nullable=False, index=True)
    requirement_id: Mapped[uuid.UUID | None] = mapped_column(GUID(), ForeignKey("requirements.id"), nullable=True)
    reason: Mapped[str] = mapped_column(String(255), nullable=False)  # e.g. "low_confidence", "conflicting_requirement"
    status: Mapped[ReviewStatus] = mapped_column(default=ReviewStatus.NEEDS_REVIEW, nullable=False)
    reviewed_by_user_id: Mapped[uuid.UUID | None] = mapped_column(GUID(), ForeignKey("users.id"), nullable=True)
    reviewed_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True), nullable=True)


class FieldCorrection(Base, UUIDPKMixin, TimestampMixin):
    """
    Spec §110 AI Corrections: never silently overwrite AI output. Every
    correction is an additive row; the "current" value is whatever the
    latest correction says, but original_value is always preserved.
    """

    __tablename__ = "field_corrections"

    requirement_id: Mapped[uuid.UUID] = mapped_column(GUID(), ForeignKey("requirements.id"), nullable=False)
    field_name: Mapped[str] = mapped_column(String(100), nullable=False)
    original_value: Mapped[str] = mapped_column(Text, nullable=False)
    corrected_value: Mapped[str] = mapped_column(Text, nullable=False)
    corrected_by_user_id: Mapped[uuid.UUID] = mapped_column(GUID(), ForeignKey("users.id"), nullable=False)
    reason: Mapped[str | None] = mapped_column(Text, nullable=True)


class TenderDecision(Base, UUIDPKMixin, TimestampMixin):
    """The human's final bid/no-bid call — always separate from BidAssessment (the AI's recommendation)."""

    __tablename__ = "tender_decisions"

    tender_id: Mapped[uuid.UUID] = mapped_column(GUID(), ForeignKey("tenders.id"), nullable=False, index=True)
    decided_by_user_id: Mapped[uuid.UUID] = mapped_column(GUID(), ForeignKey("users.id"), nullable=False)
    decision: Mapped[str] = mapped_column(String(50), nullable=False)  # bid | no_bid
    rationale: Mapped[str | None] = mapped_column(Text, nullable=True)


class AuditLog(Base, UUIDPKMixin, TimestampMixin):
    """Append-only. Spec §117.J: critical user actions must be auditable."""

    __tablename__ = "audit_logs"

    # Nullable: most audit events are org-scoped, but some are genuinely
    # platform-wide (e.g. an admin changing the global AI provider
    # setting) and have no organization to attach to.
    organization_id: Mapped[uuid.UUID | None] = mapped_column(GUID(), ForeignKey("organizations.id"), nullable=True, index=True)
    actor_user_id: Mapped[uuid.UUID | None] = mapped_column(GUID(), ForeignKey("users.id"), nullable=True)
    action: Mapped[str] = mapped_column(String(100), nullable=False)  # e.g. "tender.deleted", "document.uploaded"
    resource_type: Mapped[str] = mapped_column(String(100), nullable=False)
    resource_id: Mapped[str | None] = mapped_column(String(100), nullable=True)
    metadata_json: Mapped[dict] = mapped_column(json_variant(), default=dict)
    ip_address: Mapped[str | None] = mapped_column(String(64), nullable=True)
