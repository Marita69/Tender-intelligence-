import uuid

from sqlalchemy import ForeignKey, String
from sqlalchemy.orm import Mapped, mapped_column

from app.db.base import Base, TimestampMixin, UUIDPKMixin
from app.db.types import GUID


class AIProviderSetting(Base, UUIDPKMixin, TimestampMixin):
    """
    Platform-wide runtime override for which AI provider/model is active,
    editable by the platform admin (Admin Dashboard -> AI Provider) without
    a redeploy. There is at most one row in practice — see
    app/services/ai_settings_service.py, which always reads/writes "the
    most recently updated row" rather than enforcing a DB-level singleton
    constraint (simpler, and the admin-only write path already prevents
    anyone else from creating a second one).

    When no row exists, app/ai/provider.py falls back to the AI_PROVIDER /
    *_MODEL environment variables — this table only ever overrides, never
    replaces, that env-based default.
    """

    __tablename__ = "ai_provider_settings"

    provider: Mapped[str] = mapped_column(String(50), nullable=False)  # anthropic | openrouter | nvidia | mock
    model: Mapped[str] = mapped_column(String(255), nullable=False)
    updated_by_user_id: Mapped[uuid.UUID | None] = mapped_column(GUID(), ForeignKey("users.id"), nullable=True)
