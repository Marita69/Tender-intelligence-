import uuid

from sqlalchemy import Boolean, ForeignKey, String, UniqueConstraint
from sqlalchemy.orm import Mapped, mapped_column, relationship

from app.db.types import GUID
from app.db.base import Base, TimestampMixin, UUIDPKMixin
from app.models.enums import MembershipRole


class User(Base, UUIDPKMixin, TimestampMixin):
    __tablename__ = "users"

    email: Mapped[str] = mapped_column(String(320), unique=True, index=True, nullable=False)
    hashed_password: Mapped[str] = mapped_column(String(255), nullable=False)
    full_name: Mapped[str] = mapped_column(String(255), nullable=False)
    job_title: Mapped[str | None] = mapped_column(String(255), nullable=True)
    avatar_storage_key: Mapped[str | None] = mapped_column(String(1000), nullable=True)
    is_active: Mapped[bool] = mapped_column(Boolean, default=True, nullable=False)
    is_platform_admin: Mapped[bool] = mapped_column(Boolean, default=False, nullable=False)

    memberships: Mapped[list["OrganizationMembership"]] = relationship(back_populates="user")


class Organization(Base, UUIDPKMixin, TimestampMixin):
    """
    A workspace. Every tenant-scoped table carries organization_id and every
    query MUST filter on it (spec §117.D — organizations must be isolated).
    """

    __tablename__ = "organizations"

    name: Mapped[str] = mapped_column(String(255), nullable=False)
    slug: Mapped[str] = mapped_column(String(255), unique=True, index=True, nullable=False)
    # Display-only today — no plan-gated feature limits are enforced
    # anywhere in the codebase yet; see PAGES.md for why that's out of
    # scope for this pass. Billing credits (app/models/billing.py) are the
    # actual usage-limiting mechanism currently wired up.
    plan: Mapped[str] = mapped_column(String(50), default="free", nullable=False)
    is_suspended: Mapped[bool] = mapped_column(Boolean, default=False, nullable=False)

    memberships: Mapped[list["OrganizationMembership"]] = relationship(back_populates="organization")


class OrganizationMembership(Base, UUIDPKMixin, TimestampMixin):
    __tablename__ = "organization_memberships"

    user_id: Mapped[uuid.UUID] = mapped_column(GUID(), ForeignKey("users.id"), nullable=False)
    organization_id: Mapped[uuid.UUID] = mapped_column(
        GUID(), ForeignKey("organizations.id"), nullable=False
    )
    role: Mapped[MembershipRole] = mapped_column(default=MembershipRole.MEMBER, nullable=False)

    user: Mapped["User"] = relationship(back_populates="memberships")
    organization: Mapped["Organization"] = relationship(back_populates="memberships")

    __table_args__ = (UniqueConstraint("user_id", "organization_id", name="uq_membership_user_org"),)
