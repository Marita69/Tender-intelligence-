"""
Prompt + JSON Schema definitions for the extraction pipeline.

PROMPT_VERSION must be bumped whenever the prompt text changes, because
AnalysisJob.prompt_version is stored per job for reproducibility
(spec §117.H). Treat this file as versioned data, not just code.
"""

PROMPT_VERSION = "extraction-v1"

SYSTEM_PROMPT = """You are a meticulous procurement/tender analyst assistant.

Rules you must follow exactly:
1. Only report requirements that are explicitly stated in the provided text or that follow from direct, unambiguous inference. Never invent requirements.
2. Every requirement you report MUST include a `quoted_text` field containing the exact source text it was derived from (used for evidence citation). If you cannot find supporting text, do not report the requirement.
3. Set `is_inferred` = true only if the fact required combining multiple statements rather than being directly stated; otherwise false.
4. If information is genuinely missing or unclear, report it with `is_unknown` = true and confidence = "unknown" rather than guessing.
5. Never fabricate dates, amounts, or document names.
6. If you notice two requirements that conflict with each other, still report both and note the conflict in `detail`.
7. For type='deadline' requirements, always populate `deadline_iso` with a precise ISO 8601 timestamp when the source text gives an unambiguous date (and time, if stated). If the date is relative, partial, or ambiguous, leave `deadline_iso` null and set `is_unknown`=true rather than guessing.
8. If a requirement depends on a form, annex, or schedule that is referenced by name but not included in the text you were given, set `references_missing_document`=true and `referenced_document_name` to that document's name.
"""

REQUIREMENT_EXTRACTION_SCHEMA = {
    "title": "RequirementExtractionBatch",
    "type": "object",
    "properties": {
        "requirements": {
            "type": "array",
            "items": {
                "type": "object",
                "properties": {
                    "type": {
                        "type": "string",
                        "enum": [
                            "eligibility",
                            "mandatory_document",
                            "deadline",
                            "financial",
                            "bid_security",
                            "technical",
                            "evaluation_criterion",
                            "submission_instruction",
                            "contract_term",
                        ],
                    },
                    "summary": {"type": "string"},
                    "detail": {"type": ["string", "null"]},
                    "structured_value": {"type": "object"},
                    "deadline_iso": {
                        "type": ["string", "null"],
                        "description": (
                            "Only for type='deadline': the date/time in ISO 8601 "
                            "(e.g. '2026-12-15T14:00:00'). Null if the exact date "
                            "cannot be determined from the source text — never guess."
                        ),
                    },
                    "deadline_timezone": {
                        "type": ["string", "null"],
                        "description": "IANA timezone name if stated or clearly implied (e.g. 'Africa/Nairobi'); otherwise null.",
                    },
                    "confidence": {"type": "string", "enum": ["high", "medium", "low", "unknown"]},
                    "is_inferred": {"type": "boolean"},
                    "is_unknown": {"type": "boolean"},
                    "quoted_text": {"type": "string"},
                    "references_missing_document": {
                        "type": "boolean",
                        "description": (
                            "True if this requirement depends on an external form/annex/schedule "
                            "(e.g. 'complete Form C-4', 'see Schedule B') that was not included in "
                            "the text supplied to you. False otherwise."
                        ),
                    },
                    "referenced_document_name": {
                        "type": ["string", "null"],
                        "description": "The name of the missing referenced document, if references_missing_document is true; otherwise null.",
                    },
                },
                "required": ["type", "summary", "confidence", "is_inferred", "is_unknown", "quoted_text"],
            },
        }
    },
    "required": ["requirements"],
}

BID_ASSESSMENT_SCHEMA = {
    "title": "BidAssessmentResult",
    "type": "object",
    "properties": {
        "recommendation": {
            "type": "string",
            "enum": ["bid", "conditional_bid", "no_bid", "insufficient_information"],
        },
        "score": {"type": "number", "minimum": 0, "maximum": 100},
        "confidence": {"type": "string", "enum": ["high", "medium", "low", "unknown"]},
        "rationale": {"type": "string"},
        "score_breakdown": {"type": "object"},
        "disqualifying_factors": {"type": "array", "items": {"type": "string"}},
    },
    "required": ["recommendation", "score", "confidence", "rationale"],
}


def build_extraction_prompt(page_texts: list[tuple[int, str]]) -> str:
    """page_texts: list of (page_number, text)."""
    joined = "\n\n".join(f"--- PAGE {num} ---\n{text}" for num, text in page_texts)
    return (
        "Extract every tender requirement from the following tender document pages. "
        "Cover eligibility criteria, mandatory documents, deadlines, financial and bid-security "
        "requirements, technical specifications, evaluation criteria, submission instructions, "
        "and contract/payment terms.\n\n" + joined
    )


def build_bid_assessment_prompt(requirements_summary: str, company_profile_summary: str) -> str:
    return (
        "Given the following extracted tender requirements and the bidding company's profile, "
        "produce a bid/no-bid recommendation. Be conservative: if information is missing, prefer "
        "'insufficient_information' over guessing.\n\n"
        f"TENDER REQUIREMENTS:\n{requirements_summary}\n\n"
        f"COMPANY PROFILE:\n{company_profile_summary}\n"
    )
