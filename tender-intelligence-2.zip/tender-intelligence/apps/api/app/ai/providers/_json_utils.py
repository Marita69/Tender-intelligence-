"""
Shared by every LLM provider that asks a model to "respond with only
JSON" rather than using native structured-output/tool-calling (which not
every provider or free model supports reliably) — see AnthropicProvider
and OpenAICompatibleProvider.
"""
from __future__ import annotations

import json
from typing import Any

from app.core.logging import get_logger

logger = get_logger(__name__)


def parse_json_safely(text: str) -> dict[str, Any]:
    cleaned = text.strip()
    if cleaned.startswith("```"):
        cleaned = cleaned.strip("`")
        if cleaned.lower().startswith("json"):
            cleaned = cleaned[4:]
    try:
        return json.loads(cleaned)
    except json.JSONDecodeError:
        logger.error("ai_json_parse_failed", raw_text=text[:2000])
        # Returning an explicit "unparseable" marker rather than raising lets
        # the caller mark this extraction step as failed/low-confidence
        # instead of crashing the whole analysis job (spec principle #9).
        return {"_parse_error": True, "_raw_text": text}
