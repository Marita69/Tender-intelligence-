"""
Generic provider for any OpenAI-compatible chat-completions API. Both
OpenRouter (https://openrouter.ai) and NVIDIA NIM
(https://build.nvidia.com) expose this same API shape — only the
base_url, api_key, and model differ — so rather than writing two nearly
identical provider classes, this one is parametrized by those three
values (see get_openrouter_provider / get_nvidia_provider below, and
PRODUCTION_GUIDE.md for where to get free-tier keys).

Unlike AnthropicProvider, this does NOT use native tool-calling/JSON-mode
for structured output. Reason: many free-tier models (especially on
OpenRouter's ":free" tier) either don't support `response_format` /
function calling at all, or support it unreliably. The same
prompt-for-JSON-and-parse-leniently approach already used for Anthropic
is more portable across the wide range of models this provider might be
pointed at, at the cost of slightly less reliable structure than a model
with real JSON-mode support would give.
"""
from __future__ import annotations

import json

from app.ai.provider import GenerationResult, StructuredResult
from app.ai.providers._json_utils import parse_json_safely
from app.ai.providers._retry import llm_retry
from app.core.config import settings
from app.core.logging import get_logger

logger = get_logger(__name__)


class OpenAICompatibleProvider:
    def __init__(self, *, base_url: str, api_key: str, model: str, provider_label: str) -> None:
        from openai import AsyncOpenAI

        if not api_key:
            raise ValueError(
                f"{provider_label} is selected as the AI provider but no API key is configured. "
                f"Set the corresponding *_API_KEY environment variable (see .env.example)."
            )

        default_headers = {}
        if "openrouter.ai" in base_url:
            # OpenRouter asks integrations to identify themselves via these
            # optional headers for their own analytics/rate-limit tiers —
            # harmless to omit, but nice to include. Not required by NVIDIA.
            default_headers = {
                "HTTP-Referer": settings.WEB_BASE_URL or "http://localhost:5174",
                "X-Title": settings.APP_NAME,
            }

        self._client = AsyncOpenAI(
            base_url=base_url,
            api_key=api_key,
            timeout=settings.AI_TIMEOUT_SECONDS,
            default_headers=default_headers or None,
        )
        self._model = model
        self._provider_label = provider_label

    @llm_retry
    async def generate(
        self,
        prompt: str,
        *,
        system: str | None = None,
        temperature: float = 0.0,
        max_tokens: int = 4096,
    ) -> GenerationResult:
        messages = []
        if system:
            messages.append({"role": "system", "content": system})
        messages.append({"role": "user", "content": prompt})

        response = await self._client.chat.completions.create(
            model=self._model,
            max_tokens=max_tokens,
            temperature=temperature,
            messages=messages,
        )
        text = response.choices[0].message.content or ""
        usage = response.usage
        logger.info(
            "ai_generate",
            provider=self._provider_label,
            model=self._model,
            input_tokens=usage.prompt_tokens if usage else 0,
            output_tokens=usage.completion_tokens if usage else 0,
        )
        return GenerationResult(
            text=text,
            model=self._model,
            input_tokens=usage.prompt_tokens if usage else 0,
            output_tokens=usage.completion_tokens if usage else 0,
            raw=response.model_dump(),
        )

    @llm_retry
    async def generate_structured(
        self,
        prompt: str,
        *,
        json_schema: dict,
        system: str | None = None,
        temperature: float = 0.0,
        max_tokens: int = 4096,
    ) -> StructuredResult:
        schema_instruction = (
            "\n\nRespond with ONLY valid JSON matching this JSON Schema, no prose, "
            f"no markdown fences:\n{json.dumps(json_schema)}"
        )
        messages = [{"role": "system", "content": (system or "") + schema_instruction}]
        messages.append({"role": "user", "content": prompt})

        # Attempt JSON mode where the model/provider supports it (many do,
        # including most OpenRouter and NVIDIA-hosted instruct models) —
        # fall back to plain prompting if the API rejects the parameter,
        # since not every free/hosted model recognizes it.
        try:
            response = await self._client.chat.completions.create(
                model=self._model,
                max_tokens=max_tokens,
                temperature=temperature,
                messages=messages,
                response_format={"type": "json_object"},
            )
        except Exception as exc:  # noqa: BLE001 — provider-specific rejection of response_format
            logger.warning(
                "ai_json_mode_unsupported_falling_back", provider=self._provider_label, model=self._model, error=str(exc)
            )
            response = await self._client.chat.completions.create(
                model=self._model,
                max_tokens=max_tokens,
                temperature=temperature,
                messages=messages,
            )

        text = response.choices[0].message.content or ""
        data = parse_json_safely(text)
        usage = response.usage
        logger.info(
            "ai_generate_structured",
            provider=self._provider_label,
            model=self._model,
            input_tokens=usage.prompt_tokens if usage else 0,
            output_tokens=usage.completion_tokens if usage else 0,
        )
        return StructuredResult(
            data=data,
            model=self._model,
            input_tokens=usage.prompt_tokens if usage else 0,
            output_tokens=usage.completion_tokens if usage else 0,
            raw=response.model_dump(),
        )


def get_openrouter_provider(api_key: str | None = None, model: str | None = None) -> OpenAICompatibleProvider:
    return OpenAICompatibleProvider(
        base_url=settings.OPENROUTER_BASE_URL,
        api_key=api_key or settings.OPENROUTER_API_KEY,
        model=model or settings.OPENROUTER_MODEL,
        provider_label="openrouter",
    )


def get_nvidia_provider(api_key: str | None = None, model: str | None = None) -> OpenAICompatibleProvider:
    return OpenAICompatibleProvider(
        base_url=settings.NVIDIA_BASE_URL,
        api_key=api_key or settings.NVIDIA_API_KEY,
        model=model or settings.NVIDIA_MODEL,
        provider_label="nvidia",
    )


def get_gemini_provider(api_key: str | None = None, model: str | None = None) -> OpenAICompatibleProvider:
    return OpenAICompatibleProvider(
        base_url=settings.GEMINI_BASE_URL,
        api_key=api_key or settings.GEMINI_API_KEY,
        model=model or settings.GEMINI_MODEL,
        provider_label="gemini",
    )


def get_deepseek_provider(api_key: str | None = None, model: str | None = None) -> OpenAICompatibleProvider:
    return OpenAICompatibleProvider(
        base_url=settings.DEEPSEEK_BASE_URL,
        api_key=api_key or settings.DEEPSEEK_API_KEY,
        model=model or settings.DEEPSEEK_MODEL,
        provider_label="deepseek",
    )
