"""
Deterministic mock provider. Used when AI_PROVIDER=mock (the default), so
the whole pipeline — upload, extraction, "AI" analysis, checklist, report —
can be exercised end-to-end in local dev/CI without an API key or network
access. Swap to AI_PROVIDER=anthropic + ANTHROPIC_API_KEY for real analysis.

It does simple heuristic keyword scanning of the input text so results are
not pure placeholders — e.g. it will find something resembling a deadline
if the text contains a date-like pattern near the word "deadline".
"""
from __future__ import annotations

import re
from typing import Any

from app.ai.provider import GenerationResult, StructuredResult

DATE_PATTERN = re.compile(
    r"\b(\d{1,2}\s+(?:Jan|Feb|Mar|Apr|May|Jun|Jul|Aug|Sep|Oct|Nov|Dec)[a-z]*\s+\d{4})\b", re.IGNORECASE
)


class MockProvider:
    def __init__(self) -> None:
        self._model = "mock-v1"

    async def generate(
        self,
        prompt: str,
        *,
        system: str | None = None,
        temperature: float = 0.0,
        max_tokens: int = 4096,
    ) -> GenerationResult:
        return GenerationResult(
            text=f"[mock provider response for prompt of length {len(prompt)}]",
            model="mock-v1",
            input_tokens=len(prompt.split()),
            output_tokens=10,
        )

    async def generate_structured(
        self,
        prompt: str,
        *,
        json_schema: dict[str, Any],
        system: str | None = None,
        temperature: float = 0.0,
        max_tokens: int = 4096,
    ) -> StructuredResult:
        data = self._heuristic_extract(prompt, json_schema)
        return StructuredResult(data=data, model="mock-v1", input_tokens=len(prompt.split()), output_tokens=20)

    def _heuristic_extract(self, prompt: str, json_schema: dict[str, Any]) -> dict[str, Any]:
        schema_name = json_schema.get("title", "")

        if schema_name == "RequirementExtractionBatch":
            requirements: list[dict[str, Any]] = []
            for match in DATE_PATTERN.finditer(prompt):
                deadline_iso = self._try_parse_date(match.group(1))
                requirements.append(
                    {
                        "type": "deadline",
                        "summary": f"Deadline mentioned: {match.group(1)}",
                        "detail": None,
                        "structured_value": {"raw_date_text": match.group(1)},
                        "deadline_iso": deadline_iso,
                        "deadline_timezone": None,
                        "confidence": "medium" if deadline_iso else "low",
                        "is_inferred": False,
                        "is_unknown": deadline_iso is None,
                        "quoted_text": prompt[max(0, match.start() - 60) : match.end() + 20],
                    }
                )
            if not requirements:
                requirements.append(
                    {
                        "type": "deadline",
                        "summary": "No clear submission deadline found in the supplied text",
                        "detail": None,
                        "structured_value": {},
                        "deadline_iso": None,
                        "confidence": "unknown",
                        "is_inferred": False,
                        "is_unknown": True,
                        "quoted_text": "",
                    }
                )
            return {"requirements": requirements}

        if schema_name == "BidAssessmentResult":
            return {
                "recommendation": "insufficient_information",
                "score": 50.0,
                "confidence": "low",
                "rationale": (
                    "Mock provider: this is a placeholder assessment. Configure AI_PROVIDER=anthropic "
                    "with a valid ANTHROPIC_API_KEY to get a real bid/no-bid recommendation."
                ),
                "score_breakdown": {},
                "disqualifying_factors": [],
            }

        return {"_mock": True, "note": "No heuristic implemented for this schema in MockProvider"}

    @staticmethod
    def _try_parse_date(raw: str) -> str | None:
        from datetime import datetime

        for fmt in ("%d %b %Y", "%d %B %Y"):
            try:
                return datetime.strptime(raw, fmt).isoformat()
            except ValueError:
                continue
        return None
