"""
Shared retry policy for every LLM provider call.

The bug this fixes: the original `@retry(stop=stop_after_attempt(3),
wait=wait_exponential(...))` retried EVERY exception, including
non-transient ones like a bad API key (401) or a permission-denied /
model-not-entitled error (403). Those will never succeed on retry, so
this wasted three slow, exponentially-backed-off attempts before
tenacity's default behavior wrapped the final exception in an opaque
`RetryError[...]`, hiding the actual underlying error from both logs and
the admin's "Test connection" button.

`llm_retry` below only retries errors that are plausibly transient
(rate limits, timeouts, connection errors, 5xx) and immediately re-raises
(`reraise=True`) the ORIGINAL exception — never a RetryError wrapper — on
both non-retryable errors and final retry exhaustion, so callers always
see the real error type and message.
"""
from __future__ import annotations

from tenacity import retry, retry_if_exception, stop_after_attempt, wait_exponential


def _is_transient(exc: BaseException) -> bool:
    # Both the `anthropic` and `openai` SDKs use this same exception
    # naming convention (they're both built on httpx + a similar
    # exception hierarchy), so checking class names as strings lets one
    # predicate work for both without importing either SDK unconditionally
    # at module load time (keeping this module dependency-light).
    name = type(exc).__name__
    non_transient = {
        "AuthenticationError",  # 401 — bad/missing API key, retrying won't help
        "PermissionDeniedError",  # 403 — key valid but not entitled to this model/resource
        "BadRequestError",  # 400 — malformed request (e.g. invalid model name)
        "NotFoundError",  # 404 — e.g. unknown model id
        "UnprocessableEntityError",  # 422
    }
    if name in non_transient:
        return False
    # Rate limits, timeouts, connection errors, and 5xx are worth retrying.
    return True


llm_retry = retry(
    stop=stop_after_attempt(3),
    wait=wait_exponential(multiplier=1, min=2, max=20),
    retry=retry_if_exception(_is_transient),
    reraise=True,
)
