"""
Real LLM provider backed by the Anthropic API. This is what runs in
production once ANTHROPIC_API_KEY is set and AI_PROVIDER=anthropic.
"""
from __future__ import annotations

import json

from app.ai.provider import GenerationResult, StructuredResult
from app.ai.providers._json_utils import parse_json_safely
from app.ai.providers._retry import llm_retry
from app.core.config import settings
from app.core.logging import get_logger

logger = get_logger(__name__)


class AnthropicProvider:
    def __init__(self, model: str | None = None) -> None:
        import anthropic

        self._client = anthropic.AsyncAnthropic(
            api_key=settings.ANTHROPIC_API_KEY,
            timeout=settings.AI_TIMEOUT_SECONDS,
        )
        self._model = model or settings.AI_MODEL

    @llm_retry
    async def generate(
        self,
        prompt: str,
        *,
        system: str | None = None,
        temperature: float = 0.0,
        max_tokens: int = 4096,
    ) -> GenerationResult:
        response = await self._client.messages.create(
            model=self._model,
            max_tokens=max_tokens,
            temperature=temperature,
            system=system or "",
            messages=[{"role": "user", "content": prompt}],
        )
        text = "".join(block.text for block in response.content if block.type == "text")
        logger.info(
            "ai_generate",
            model=self._model,
            input_tokens=response.usage.input_tokens,
            output_tokens=response.usage.output_tokens,
        )
        return GenerationResult(
            text=text,
            model=self._model,
            input_tokens=response.usage.input_tokens,
            output_tokens=response.usage.output_tokens,
            raw=response.model_dump(),
        )

    @llm_retry
    async def generate_structured(
        self,
        prompt: str,
        *,
        json_schema: dict[str, Any],
        system: str | None = None,
        temperature: float = 0.0,
        max_tokens: int = 4096,
    ) -> StructuredResult:
        schema_instruction = (
            "\n\nRespond with ONLY valid JSON matching this JSON Schema, no prose, "
            f"no markdown fences:\n{json.dumps(json_schema)}"
        )
        response = await self._client.messages.create(
            model=self._model,
            max_tokens=max_tokens,
            temperature=temperature,
            system=(system or "") + schema_instruction,
            messages=[{"role": "user", "content": prompt}],
        )
        text = "".join(block.text for block in response.content if block.type == "text")
        data = parse_json_safely(text)
        logger.info(
            "ai_generate_structured",
            model=self._model,
            input_tokens=response.usage.input_tokens,
            output_tokens=response.usage.output_tokens,
        )
        return StructuredResult(
            data=data,
            model=self._model,
            input_tokens=response.usage.input_tokens,
            output_tokens=response.usage.output_tokens,
            raw=response.model_dump(),
        )
