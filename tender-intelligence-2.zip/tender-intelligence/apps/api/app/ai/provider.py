"""
LLM provider abstraction (spec §4.5). Business logic in
app/services/ai_analysis_service.py depends only on this interface, never
on a specific vendor SDK, so swapping providers is a config + adapter
change, not a rewrite of extraction logic.
"""
from __future__ import annotations

from dataclasses import dataclass, field
from typing import TYPE_CHECKING, Any, Protocol

if TYPE_CHECKING:
    from sqlalchemy.orm import Session


@dataclass
class GenerationResult:
    text: str
    model: str
    input_tokens: int
    output_tokens: int
    raw: dict[str, Any] = field(default_factory=dict)


@dataclass
class StructuredResult:
    data: dict[str, Any]
    model: str
    input_tokens: int
    output_tokens: int
    raw: dict[str, Any] = field(default_factory=dict)


class LLMProvider(Protocol):
    async def generate(
        self,
        prompt: str,
        *,
        system: str | None = None,
        temperature: float = 0.0,
        max_tokens: int = 4096,
    ) -> GenerationResult: ...

    async def generate_structured(
        self,
        prompt: str,
        *,
        json_schema: dict[str, Any],
        system: str | None = None,
        temperature: float = 0.0,
        max_tokens: int = 4096,
    ) -> StructuredResult:
        """Must return data that validates against json_schema. Providers that
        don't natively support structured output should parse/repair the
        model's JSON text themselves before returning."""
        ...


def get_ai_provider(db: Session | None = None) -> LLMProvider:
    """
    Resolves the active provider. If `db` is passed, an admin-configured
    runtime override (AIProviderSetting — see Admin Dashboard -> AI
    Provider) takes precedence over the AI_PROVIDER/*_MODEL environment
    variables; without a db session (e.g. very early startup code), the
    env vars are used directly. `run_tender_analysis` always passes `db`,
    so in practice the admin override is always honored during real
    pipeline runs.
    """
    from app.core.config import settings

    provider_name = settings.AI_PROVIDER
    model_override: str | None = None

    if db is not None:
        from sqlalchemy import select

        from app.models.ai_settings import AIProviderSetting

        row = db.execute(select(AIProviderSetting).order_by(AIProviderSetting.updated_at.desc())).scalars().first()
        if row is not None:
            provider_name = row.provider
            model_override = row.model

    if provider_name == "anthropic":
        from app.ai.providers.anthropic_provider import AnthropicProvider

        return AnthropicProvider(model=model_override)

    if provider_name == "openrouter":
        from app.ai.providers.openai_compatible_provider import get_openrouter_provider

        return get_openrouter_provider(model=model_override)

    if provider_name == "nvidia":
        from app.ai.providers.openai_compatible_provider import get_nvidia_provider

        return get_nvidia_provider(model=model_override)

    if provider_name == "gemini":
        from app.ai.providers.openai_compatible_provider import get_gemini_provider

        return get_gemini_provider(model=model_override)

    if provider_name == "deepseek":
        from app.ai.providers.openai_compatible_provider import get_deepseek_provider

        return get_deepseek_provider(model=model_override)

    from app.ai.providers.mock_provider import MockProvider

    return MockProvider()
