from contextlib import asynccontextmanager

from fastapi import FastAPI, HTTPException, Request
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import JSONResponse
from slowapi import _rate_limit_exceeded_handler
from slowapi.errors import RateLimitExceeded
from slowapi.middleware import SlowAPIMiddleware

from app.api import admin, analysis, auth, checklist, billing, company_document, company_profile, dashboard, documents, health, notifications, organization, reports, review, tenders
from app.core.config import settings
from app.core.logging import configure_logging, get_logger
from app.core.rate_limit import limiter

configure_logging()
logger = get_logger("main")


@asynccontextmanager
async def lifespan(app: FastAPI):
    logger.info("startup", app_env=settings.APP_ENV, app_name=settings.APP_NAME)
    if settings.SENTRY_DSN:
        import sentry_sdk

        sentry_sdk.init(dsn=settings.SENTRY_DSN, environment=settings.APP_ENV, traces_sample_rate=0.1)
    yield
    logger.info("shutdown")


app = FastAPI(
    title=settings.APP_NAME,
    version="0.1.0",
    lifespan=lifespan,
    # Brand name is never hard-coded elsewhere (spec §1.1) — it flows from
    # settings.APP_NAME everywhere it's needed, including report exports.
)

app.add_middleware(
    CORSMiddleware,
    allow_origins=settings.CORS_ORIGINS,
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

app.state.limiter = limiter
app.add_exception_handler(RateLimitExceeded, _rate_limit_exceeded_handler)
# Without this middleware, `Limiter(default_limits=...)` silently does
# nothing -- only routes with an explicit @limiter.limit(...) decorator
# (currently just the auth endpoints) would be rate-limited. This applies
# the 200/minute default to every route as a baseline, on top of the
# stricter per-route limits on signup/login/refresh.
app.add_middleware(SlowAPIMiddleware)


@app.exception_handler(HTTPException)
async def http_exception_handler(request: Request, exc: HTTPException):
    # Uniform error shape for the frontend's toast/notification system
    # (spec §3.1) — every error response looks like {"detail": "..."}.
    return JSONResponse(status_code=exc.status_code, content={"detail": exc.detail})


@app.exception_handler(Exception)
async def unhandled_exception_handler(request: Request, exc: Exception):
    logger.error("unhandled_exception", path=str(request.url), error=str(exc))
    return JSONResponse(status_code=500, content={"detail": "An unexpected error occurred"})


app.include_router(health.router)
app.include_router(auth.router)
app.include_router(dashboard.router)
app.include_router(tenders.router)
app.include_router(documents.router)
app.include_router(organization.router)
app.include_router(analysis.router)
app.include_router(checklist.router)
app.include_router(company_profile.router)
app.include_router(company_document.router)
app.include_router(billing.router)
app.include_router(reports.router)
app.include_router(review.router)
app.include_router(notifications.router)
app.include_router(admin.router)
