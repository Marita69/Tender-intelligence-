import uuid

from fastapi import HTTPException, status
from sqlalchemy import func, select
from sqlalchemy.orm import Session

from app.models.tender import Tender
from app.schemas.tender import TenderCreate, TenderUpdate
from app.security.tenancy import CurrentContext
from app.utils.audit import record_audit


def create_tender(db: Session, ctx: CurrentContext, payload: TenderCreate) -> Tender:
    tender = Tender(
        organization_id=ctx.organization_id,
        created_by_user_id=ctx.user.id,
        title=payload.title,
        reference_number=payload.reference_number,
        issuing_entity=payload.issuing_entity,
    )
    db.add(tender)
    db.flush()
    record_audit(
        db,
        organization_id=ctx.organization_id,
        actor_user_id=ctx.user.id,
        action="tender.created",
        resource_type="tender",
        resource_id=str(tender.id),
    )
    db.commit()
    db.refresh(tender)
    return tender


def get_tender_or_404(db: Session, ctx: CurrentContext, tender_id: uuid.UUID) -> Tender:
    tender = db.execute(
        select(Tender).where(
            Tender.id == tender_id,
            Tender.organization_id == ctx.organization_id,  # tenant isolation — never skip this filter
            Tender.deleted_at.is_(None),
        )
    ).scalar_one_or_none()
    if tender is None:
        raise HTTPException(status.HTTP_404_NOT_FOUND, "Tender not found")
    return tender


def list_tenders(
    db: Session, ctx: CurrentContext, *, search: str | None, page: int, page_size: int
) -> tuple[list[Tender], int]:
    stmt = select(Tender).where(Tender.organization_id == ctx.organization_id, Tender.deleted_at.is_(None))
    count_stmt = select(func.count()).select_from(Tender).where(
        Tender.organization_id == ctx.organization_id, Tender.deleted_at.is_(None)
    )
    if search:
        like = f"%{search}%"
        stmt = stmt.where(Tender.title.ilike(like))
        count_stmt = count_stmt.where(Tender.title.ilike(like))

    total = db.execute(count_stmt).scalar_one()
    items = (
        db.execute(stmt.order_by(Tender.created_at.desc()).offset((page - 1) * page_size).limit(page_size))
        .scalars()
        .all()
    )
    return list(items), total


def update_tender(db: Session, ctx: CurrentContext, tender_id: uuid.UUID, payload: TenderUpdate) -> Tender:
    tender = get_tender_or_404(db, ctx, tender_id)
    for field, value in payload.model_dump(exclude_unset=True).items():
        setattr(tender, field, value)
    record_audit(
        db,
        organization_id=ctx.organization_id,
        actor_user_id=ctx.user.id,
        action="tender.updated",
        resource_type="tender",
        resource_id=str(tender.id),
        metadata=payload.model_dump(exclude_unset=True),
    )
    db.commit()
    db.refresh(tender)
    return tender


def soft_delete_tender(db: Session, ctx: CurrentContext, tender_id: uuid.UUID) -> None:
    from datetime import datetime, timezone

    tender = get_tender_or_404(db, ctx, tender_id)
    tender.deleted_at = datetime.now(timezone.utc)
    record_audit(
        db,
        organization_id=ctx.organization_id,
        actor_user_id=ctx.user.id,
        action="tender.deleted",
        resource_type="tender",
        resource_id=str(tender.id),
    )
    db.commit()
