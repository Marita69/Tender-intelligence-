from datetime import datetime, timedelta, timezone

from sqlalchemy import func, select
from sqlalchemy.orm import Session

from app.models.analysis import BidAssessment, Risk
from app.models.checklist import Task
from app.models.enums import TaskStatus, TenderStatus
from app.models.organization import User
from app.models.tender import Tender
from app.schemas.dashboard import DashboardOverview, DashboardStats, PipelineTenderOut, UrgentTaskOut
from app.security.tenancy import CurrentContext

ACTIVE_STATUSES = (TenderStatus.DRAFT, TenderStatus.PROCESSING, TenderStatus.ANALYZED, TenderStatus.FAILED)


def get_overview(db: Session, ctx: CurrentContext) -> DashboardOverview:
    now = datetime.now(timezone.utc)
    week_ago = now - timedelta(days=7)
    week_ahead = now + timedelta(days=7)

    base_filter = (Tender.organization_id == ctx.organization_id, Tender.deleted_at.is_(None))

    active_tenders = db.execute(
        select(func.count()).select_from(Tender).where(*base_filter, Tender.status.in_(ACTIVE_STATUSES))
    ).scalar_one()

    new_this_week = db.execute(
        select(func.count()).select_from(Tender).where(*base_filter, Tender.created_at >= week_ago)
    ).scalar_one()

    deadlines_this_week = db.execute(
        select(func.count())
        .select_from(Tender)
        .where(
            *base_filter,
            Tender.submission_deadline.isnot(None),
            Tender.submission_deadline >= now,
            Tender.submission_deadline <= week_ahead,
        )
    ).scalar_one()

    critical_blockers = db.execute(
        select(func.count())
        .select_from(Risk)
        .join(Tender, Risk.tender_id == Tender.id)
        .where(*base_filter, Risk.is_disqualifying.is_(True))
    ).scalar_one()

    stats = DashboardStats(
        active_tenders=active_tenders,
        new_this_week=new_this_week,
        deadlines_this_week=deadlines_this_week,
        critical_blockers=critical_blockers,
    )

    # Pipeline: active tenders with their latest bid assessment, if any.
    tenders = list(
        db.execute(
            select(Tender)
            .where(*base_filter, Tender.status.in_(ACTIVE_STATUSES))
            .order_by(Tender.submission_deadline.asc().nulls_last(), Tender.created_at.desc())
            .limit(20)
        ).scalars()
    )
    pipeline: list[PipelineTenderOut] = []
    for tender in tenders:
        assessment = db.execute(
            select(BidAssessment)
            .where(BidAssessment.tender_id == tender.id)
            .order_by(BidAssessment.created_at.desc())
        ).scalars().first()
        pipeline.append(
            PipelineTenderOut(
                id=tender.id,
                title=tender.title,
                reference_number=tender.reference_number,
                issuing_entity=tender.issuing_entity,
                submission_deadline=tender.submission_deadline,
                bid_score=assessment.score if assessment else None,
                bid_recommendation=assessment.recommendation if assessment else None,
                status=tender.status,
            )
        )

    # Urgent tasks: not done, due soonest first, across the whole org.
    task_rows = db.execute(
        select(Task, Tender, User)
        .join(Tender, Task.tender_id == Tender.id)
        .outerjoin(User, Task.assigned_to_user_id == User.id)
        .where(
            Tender.organization_id == ctx.organization_id,
            Tender.deleted_at.is_(None),
            Task.status != TaskStatus.DONE,
            Task.due_at.isnot(None),
        )
        .order_by(Task.due_at.asc())
        .limit(10)
    ).all()
    urgent_tasks = [
        UrgentTaskOut(
            id=task.id,
            tender_id=tender.id,
            tender_title=tender.title,
            title=task.title,
            due_at=task.due_at,
            assigned_to_user_id=task.assigned_to_user_id,
            assigned_to_name=user.full_name if user else None,
            status=task.status,
        )
        for task, tender, user in task_rows
    ]

    return DashboardOverview(stats=stats, pipeline=pipeline, urgent_tasks=urgent_tasks)
