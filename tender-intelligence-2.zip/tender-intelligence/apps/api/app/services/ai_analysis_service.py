"""
Orchestrates the full pipeline described in spec §6 (User Journey) and §4.6:

    documents -> per-page text/OCR -> chunked AI extraction -> Requirement
    + Evidence rows -> conflict/low-confidence flagging -> ReviewItem
    creation -> ChecklistItem generation -> BidAssessment.

This is intentionally synchronous/callable code (not tied to Celery) so it
can be invoked either from a worker task (production) or directly/eagerly
in tests and local dev without Redis running.
"""
from __future__ import annotations

import uuid
from io import BytesIO

from sqlalchemy import delete, select
from sqlalchemy.orm import Session

from app.ai.prompts.extraction import (
    BID_ASSESSMENT_SCHEMA,
    PROMPT_VERSION,
    REQUIREMENT_EXTRACTION_SCHEMA,
    SYSTEM_PROMPT,
    build_bid_assessment_prompt,
    build_extraction_prompt,
)
from app.ai.provider import get_ai_provider
from app.core.config import settings
from app.core.logging import get_logger
from app.documents.extraction import CorruptedDocumentError, PasswordProtectedError, extract_docx, extract_pdf
from app.documents.storage import get_storage
from app.models.analysis import BidAssessment, Evidence, Requirement, Risk
from app.models.checklist import ChecklistItem
from app.models.company_profile import CompanyProfile
from app.models.document import AnalysisJob, DocumentPage, TenderDocument
from app.models.enums import (
    AnalysisJobStatus,
    ChecklistItemStatus,
    ConfidenceLevel,
    DocumentStatus,
    RequirementType,
    ReviewStatus,
)
from app.models.review import ReviewItem
from app.models.tender import Tender
from app.models.enums import TenderStatus
from app.models.notification import NotificationType
from app.services import notification_service

logger = get_logger(__name__)

PIPELINE_VERSION = "pipeline-v1"

# Requirement types that always generate a compliance checklist row.
CHECKLIST_GENERATING_TYPES = {RequirementType.MANDATORY_DOCUMENT, RequirementType.ELIGIBILITY}

LOW_CONFIDENCE_LEVELS = {ConfidenceLevel.LOW, ConfidenceLevel.UNKNOWN}

# Keep chunks well under typical context limits while preserving page boundaries.
MAX_PAGES_PER_CHUNK = 15


def _resolve_active_provider_name(db: Session) -> str:
    """Mirrors the DB-override-then-env-fallback resolution in
    app.ai.provider.get_ai_provider, but only for the provider NAME (used
    to record what AnalysisJob actually ran with — see run_tender_analysis)."""
    from sqlalchemy import select

    from app.models.ai_settings import AIProviderSetting

    row = db.execute(select(AIProviderSetting).order_by(AIProviderSetting.updated_at.desc())).scalars().first()
    return row.provider if row is not None else settings.AI_PROVIDER


def run_tender_analysis(db: Session, tender_id: uuid.UUID) -> AnalysisJob:
    """
    Entry point called by the worker task. Synchronous/blocking by design —
    the async boundary is handled by whoever queues this (Celery task or
    a direct call in eager/test mode).
    """
    tender = db.get(Tender, tender_id)
    if tender is None:
        raise ValueError(f"Tender {tender_id} not found")

    # Every run starts from a clean slate — without this, re-running
    # analysis on the same tender would accumulate duplicate Requirements/
    # Risks/ChecklistItems on top of the previous run's data instead of
    # replacing it (see _clear_analysis_data's docstring).
    _clear_analysis_data(db, tender)

    job = AnalysisJob(
        tender_id=tender.id,
        organization_id=tender.organization_id,
        status=AnalysisJobStatus.RUNNING,
        ai_provider=settings.AI_PROVIDER,  # placeholder; corrected below once the actual provider (env or admin override) resolves
        ai_model=settings.AI_MODEL,
        prompt_version=PROMPT_VERSION,
        pipeline_version=PIPELINE_VERSION,
        step_log=[],
    )
    db.add(job)
    tender.status = TenderStatus.PROCESSING
    db.commit()
    db.refresh(job)

    try:
        provider = get_ai_provider(db)
        # AnalysisJob.ai_provider/ai_model must reflect what was ACTUALLY
        # used (spec §117.H reproducibility), not just the env-var default
        # recorded above — an admin-configured runtime override (see
        # app/models/ai_settings.py) can differ from AI_PROVIDER/AI_MODEL.
        job.ai_provider = _resolve_active_provider_name(db)
        job.ai_model = getattr(provider, "_model", job.ai_model)
        db.commit()

        _step(job, db, "extract_documents", lambda: _extract_all_documents(db, tender))
        _step(job, db, "ai_extraction", lambda: _run_extraction_sync(db, tender, job, provider))
        _step(job, db, "sync_deadline", lambda: _sync_tender_deadline(db, tender))
        _step(job, db, "detect_conflicts", lambda: _detect_deadline_conflicts(db, tender))
        _step(job, db, "flag_reviews", lambda: _flag_reviews(db, tender, job))
        _step(job, db, "generate_checklist", lambda: _generate_checklist(db, tender))
        _step(job, db, "bid_assessment", lambda: _run_bid_assessment_sync(db, tender, job, provider))

        job.status = AnalysisJobStatus.SUCCEEDED
        tender.status = TenderStatus.ANALYZED
        notification_service.create_notification(
            db,
            organization_id=tender.organization_id,
            user_id=tender.created_by_user_id,
            type=NotificationType.ANALYSIS,
            title=f"Analysis complete: {tender.title}",
            body="Your tender analysis finished — review the requirements, risks, and bid recommendation.",
            tender_id=tender.id,
        )
    except Exception as exc:  # noqa: BLE001 — pipeline must never crash the request/worker uncaught
        logger.error("analysis_job_failed", job_id=str(job.id), tender_id=str(tender.id), error=str(exc))
        job.status = AnalysisJobStatus.FAILED
        job.error_message = str(exc)
        tender.status = TenderStatus.FAILED
        notification_service.create_notification(
            db,
            organization_id=tender.organization_id,
            user_id=tender.created_by_user_id,
            type=NotificationType.SYSTEM,
            title=f"Analysis failed: {tender.title}",
            body=f"The analysis pipeline hit an error: {exc}",
            tender_id=tender.id,
        )
        # Spec principle #9 / §117.G: keep whatever partial results exist —
        # do not roll back requirements/evidence already committed in
        # earlier steps.
    finally:
        db.commit()
        db.refresh(job)

    return job


def _step(job: AnalysisJob, db: Session, name: str, fn) -> None:
    import datetime as _dt

    started = _dt.datetime.now(_dt.timezone.utc)
    entry = {"step": name, "status": "running", "started_at": started.isoformat()}
    job.step_log = [*job.step_log, entry]
    db.commit()
    try:
        fn()
        entry["status"] = "succeeded"
    except Exception as exc:  # noqa: BLE001
        entry["status"] = "failed"
        entry["error"] = str(exc)
        raise
    finally:
        entry["finished_at"] = _dt.datetime.now(_dt.timezone.utc).isoformat()
        job.step_log = [*job.step_log[:-1], entry]
        db.commit()


def _extract_all_documents(db: Session, tender: Tender) -> None:
    storage = get_storage()
    docs = list(
        db.execute(
            select(TenderDocument).where(
                TenderDocument.tender_id == tender.id, TenderDocument.deleted_at.is_(None)
            )
        ).scalars()
    )
    for doc in docs:
        doc.status = DocumentStatus.EXTRACTING
        # Clear any DocumentPage rows from a previous analysis run before
        # re-extracting — without this, re-running analysis on the same
        # document (very routine now that analysis can be reset and
        # re-run) would append a second copy of every page rather than
        # replacing them, silently duplicating text sent to the AI on
        # every subsequent run.
        db.execute(delete(DocumentPage).where(DocumentPage.document_id == doc.id))
        db.commit()
        try:
            file_bytes = storage.get(doc.storage_key)
            if doc.content_type == "application/pdf" or doc.original_filename.lower().endswith(".pdf"):
                result = extract_pdf(file_bytes)
            else:
                result = extract_docx(file_bytes)

            for page in result.pages:
                db.add(
                    DocumentPage(
                        document_id=doc.id,
                        page_number=page.page_number,
                        raw_text=page.text,
                        extraction_method=page.method,
                        ocr_confidence=page.ocr_confidence,
                    )
                )
            doc.page_count = result.page_count
            doc.has_text_layer = result.has_text_layer
            doc.ocr_used = result.ocr_used
            doc.status = DocumentStatus.EXTRACTED
        except PasswordProtectedError:
            doc.status = DocumentStatus.INVALID
            doc.status_reason = "Document is password-protected and could not be opened"
        except CorruptedDocumentError as exc:
            doc.status = DocumentStatus.INVALID
            doc.status_reason = f"Document could not be parsed: {exc}"
        except Exception as exc:  # noqa: BLE001 — one bad document must not abort the whole tender
            doc.status = DocumentStatus.FAILED
            doc.status_reason = str(exc)
            logger.error("document_extraction_failed", document_id=str(doc.id), error=str(exc))
        db.commit()


def _run_extraction_sync(db: Session, tender: Tender, job: AnalysisJob, provider) -> None:
    import asyncio

    asyncio.run(_run_extraction(db, tender, job, provider))


async def _run_extraction(db: Session, tender: Tender, job: AnalysisJob, provider) -> None:
    pages = list(
        db.execute(
            select(DocumentPage, TenderDocument)
            .join(TenderDocument, DocumentPage.document_id == TenderDocument.id)
            .where(TenderDocument.tender_id == tender.id, TenderDocument.deleted_at.is_(None))
        ).all()
    )
    if not pages:
        return

    # Build (page_number, text) chunks per document, capped at MAX_PAGES_PER_CHUNK,
    # tracking which TenderDocument each chunk belongs to for evidence linking.
    by_document: dict[uuid.UUID, list[tuple[int, str]]] = {}
    for page_row, doc_row in pages:
        by_document.setdefault(doc_row.id, []).append((page_row.page_number, page_row.raw_text or ""))

    total_input_tokens = 0
    total_output_tokens = 0

    for document_id, page_list in by_document.items():
        page_list.sort(key=lambda p: p[0])
        for i in range(0, len(page_list), MAX_PAGES_PER_CHUNK):
            chunk = page_list[i : i + MAX_PAGES_PER_CHUNK]
            prompt = build_extraction_prompt(chunk)
            result = await provider.generate_structured(
                prompt,
                json_schema=REQUIREMENT_EXTRACTION_SCHEMA,
                system=SYSTEM_PROMPT,
                temperature=settings.AI_TEMPERATURE,
            )
            total_input_tokens += result.input_tokens
            total_output_tokens += result.output_tokens

            if result.data.get("_parse_error"):
                logger.error("extraction_chunk_unparseable", document_id=str(document_id))
                continue

            for req_data in result.data.get("requirements", []):
                _persist_requirement(db, tender, job, document_id, chunk, req_data)

    job.token_usage = {
        "input_tokens": job.token_usage.get("input_tokens", 0) + total_input_tokens,
        "output_tokens": job.token_usage.get("output_tokens", 0) + total_output_tokens,
    }
    db.commit()


def _persist_requirement(
    db: Session,
    tender: Tender,
    job: AnalysisJob,
    document_id: uuid.UUID,
    chunk: list[tuple[int, str]],
    req_data: dict,
) -> None:
    try:
        req_type = RequirementType(req_data["type"])
        confidence = ConfidenceLevel(req_data.get("confidence", "medium"))
    except ValueError:
        logger.warning("skipping_requirement_bad_enum", data=req_data)
        return

    requirement = Requirement(
        tender_id=tender.id,
        analysis_job_id=job.id,
        type=req_type,
        summary=req_data["summary"],
        detail=req_data.get("detail"),
        structured_value=req_data.get("structured_value") or {},
        confidence=confidence,
        is_inferred=bool(req_data.get("is_inferred", False)),
        is_unknown=bool(req_data.get("is_unknown", False)),
        references_missing_document=bool(req_data.get("references_missing_document", False)),
        referenced_document_name=req_data.get("referenced_document_name"),
    )

    if req_type == RequirementType.DEADLINE:
        parsed = _parse_deadline_iso(req_data.get("deadline_iso"))
        if parsed is not None:
            requirement.deadline_at = parsed
            requirement.deadline_timezone = req_data.get("deadline_timezone")
        else:
            # Couldn't get a machine-parseable date even though the model
            # tried — treat it the same as an explicit "unknown" so it
            # still lands in the review queue rather than silently
            # defaulting Tender.submission_deadline to nothing.
            requirement.is_unknown = True

    db.add(requirement)
    db.flush()

    quoted_text = (req_data.get("quoted_text") or "").strip()
    if quoted_text:
        # Find which page in this chunk actually contains the quote for an
        # accurate citation; fall back to the first page of the chunk.
        page_number = chunk[0][0]
        for pnum, ptext in chunk:
            if quoted_text[:40] and quoted_text[:40] in ptext:
                page_number = pnum
                break
        db.add(
            Evidence(
                requirement_id=requirement.id,
                document_id=document_id,
                page_number=page_number,
                quoted_text=quoted_text[:2000],
            )
        )
    db.commit()


def _parse_deadline_iso(value: str | None):
    if not value:
        return None
    try:
        from datetime import datetime

        parsed = datetime.fromisoformat(value)
        if parsed.tzinfo is None:
            from datetime import timezone as _tz

            parsed = parsed.replace(tzinfo=_tz.utc)
        return parsed
    except ValueError:
        logger.warning("unparseable_deadline_iso", value=value)
        return None


def _sync_tender_deadline(db: Session, tender: Tender) -> None:
    """
    Denormalizes the earliest known, non-uncertain deadline requirement
    onto Tender.submission_deadline so list/dashboard views don't need to
    join Requirement for something shown on every row. If every deadline
    requirement found was uncertain/unparseable, mark the tender's
    deadline as uncertain rather than leaving it looking like "no deadline
    was mentioned at all" — those are different states the UI should be
    able to tell apart.
    """
    candidates = list(
        db.execute(
            select(Requirement).where(
                Requirement.tender_id == tender.id,
                Requirement.type == RequirementType.DEADLINE,
            )
        ).scalars()
    )
    known = [r for r in candidates if r.deadline_at is not None and not r.is_unknown]
    if known:
        earliest = min(known, key=lambda r: r.deadline_at)
        tender.submission_deadline = earliest.deadline_at
        tender.submission_deadline_timezone = earliest.deadline_timezone
        tender.submission_deadline_is_uncertain = False
    elif candidates:
        tender.submission_deadline = None
        tender.submission_deadline_is_uncertain = True
    db.commit()


def _detect_deadline_conflicts(db: Session, tender: Tender) -> None:
    """
    Deterministic, non-AI conflict check: if extraction produced two or
    more DEADLINE requirements with different parsed timestamps more than
    an hour apart, that's a real, checkable disagreement in the source
    documents (e.g. the original notice says one date, an addendum says
    another, and it's ambiguous which supersedes) — flag every one of
    them `has_conflict=True` so `_flag_reviews` actually has something to
    act on. Previously `has_conflict` was defined on the model and read by
    `_flag_reviews` but nothing ever set it, making that review-queue
    trigger permanently dead code.
    """
    deadline_reqs = list(
        db.execute(
            select(Requirement).where(
                Requirement.tender_id == tender.id,
                Requirement.type == RequirementType.DEADLINE,
                Requirement.deadline_at.isnot(None),
            )
        ).scalars()
    )
    if len(deadline_reqs) < 2:
        return

    distinct_times = {r.deadline_at for r in deadline_reqs}
    if len(distinct_times) < 2:
        return  # every deadline requirement agrees — nothing to flag

    times_sorted = sorted(distinct_times)
    if (times_sorted[-1] - times_sorted[0]).total_seconds() <= 3600:
        return  # within an hour of each other — likely the same deadline stated twice, not a real conflict

    for req in deadline_reqs:
        req.has_conflict = True
        other_times = sorted(t for t in distinct_times if t != req.deadline_at)
        req.conflict_notes = (
            f"Conflicts with {len(other_times)} other stated deadline(s) for this tender: "
            f"{', '.join(t.isoformat() for t in other_times)}"
        )
    db.commit()


def _flag_reviews(db: Session, tender: Tender, job: AnalysisJob) -> None:
    """Spec §109: auto-create review items for anything risky enough to need a human look."""
    requirements = list(db.execute(select(Requirement).where(Requirement.tender_id == tender.id)).scalars())
    flagged_count = 0
    for req in requirements:
        reason = None
        if req.confidence in LOW_CONFIDENCE_LEVELS:
            reason = "low_confidence"
        elif req.has_conflict:
            reason = "conflicting_requirement"
        elif req.references_missing_document:
            reason = "missing_referenced_document"
        elif req.type == RequirementType.DEADLINE and req.is_unknown:
            reason = "uncertain_deadline"
        elif req.type == RequirementType.ELIGIBILITY and req.confidence != ConfidenceLevel.HIGH:
            reason = "critical_eligibility_decision"

        if reason:
            flagged_count += 1
            db.add(
                ReviewItem(
                    tender_id=tender.id,
                    requirement_id=req.id,
                    reason=reason,
                    status=ReviewStatus.NEEDS_REVIEW,
                )
            )

    if flagged_count > 0:
        # One notification per analysis run, not one per flagged item — a
        # tender with 8 low-confidence requirements should not spam the
        # notification center with 8 separate alerts.
        notification_service.create_notification(
            db,
            organization_id=tender.organization_id,
            user_id=tender.created_by_user_id,
            type=NotificationType.COMPLIANCE,
            title=f"{flagged_count} item{'s' if flagged_count != 1 else ''} need review: {tender.title}",
            body="The analysis flagged low-confidence or conflicting requirements for human review.",
            tender_id=tender.id,
        )
    db.commit()


def _generate_checklist(db: Session, tender: Tender) -> None:
    requirements = list(
        db.execute(
            select(Requirement).where(
                Requirement.tender_id == tender.id, Requirement.type.in_(CHECKLIST_GENERATING_TYPES)
            )
        ).scalars()
    )
    for req in requirements:
        db.add(
            ChecklistItem(
                tender_id=tender.id,
                requirement_id=req.id,
                label=req.summary,
                status=ChecklistItemStatus.MISSING,
            )
        )
    db.commit()


def _run_bid_assessment_sync(db: Session, tender: Tender, job: AnalysisJob, provider) -> None:
    import asyncio

    asyncio.run(_run_bid_assessment(db, tender, job, provider))


async def _run_bid_assessment(db: Session, tender: Tender, job: AnalysisJob, provider) -> None:
    requirements = list(db.execute(select(Requirement).where(Requirement.tender_id == tender.id)).scalars())
    requirements_summary = "\n".join(f"- [{r.type.value}] {r.summary}" for r in requirements) or "None extracted."

    profile = db.execute(
        select(CompanyProfile).where(CompanyProfile.organization_id == tender.organization_id)
    ).scalar_one_or_none()
    profile_summary = (
        f"Legal name: {profile.legal_name}; Sectors: {', '.join(profile.sectors)}; "
        f"Certifications: {', '.join(profile.certifications)}; Years in operation: {profile.years_in_operation}"
        if profile
        else "No company profile has been set up yet."
    )

    prompt = build_bid_assessment_prompt(requirements_summary, profile_summary)
    result = await provider.generate_structured(
        prompt,
        json_schema=BID_ASSESSMENT_SCHEMA,
        system=SYSTEM_PROMPT,
        temperature=settings.AI_TEMPERATURE,
    )
    if result.data.get("_parse_error"):
        return

    try:
        from app.models.enums import BidRecommendation

        assessment = BidAssessment(
            tender_id=tender.id,
            analysis_job_id=job.id,
            recommendation=BidRecommendation(result.data["recommendation"]),
            score=float(result.data["score"]),
            confidence=ConfidenceLevel(result.data.get("confidence", "medium")),
            rationale=result.data["rationale"],
            score_breakdown=result.data.get("score_breakdown") or {},
            disqualifying_factors=result.data.get("disqualifying_factors") or [],
        )
        db.add(assessment)

        if assessment.confidence in LOW_CONFIDENCE_LEVELS:
            db.add(
                ReviewItem(
                    tender_id=tender.id,
                    requirement_id=None,
                    reason="uncertain_bid_score",
                    status=ReviewStatus.NEEDS_REVIEW,
                )
            )
        db.commit()
    except (KeyError, ValueError) as exc:
        logger.error("bid_assessment_persist_failed", error=str(exc))


def _clear_analysis_data(db: Session, tender: Tender) -> None:
    """
    Deletes every analysis-derived row for a tender (all past AnalysisJob
    runs, Requirements + their Evidence, Risks, BidAssessments,
    ChecklistItems, ReviewItems, and FieldCorrections) WITHOUT touching
    the tender's status or documents. Shared by:
      - reset_tender_analysis (the explicit "Delete analysis" button),
        which additionally resets tender.status back to DRAFT.
      - run_tender_analysis, called automatically before every run so
        re-running analysis is idempotent instead of accumulating
        duplicate Requirements/Risks/ChecklistItems on top of the
        previous run's data (nothing in this pipeline was tender-scoped
        cleanup before this — every run just appended more rows).

    Deletion order matters: several tables have a plain FK column to
    Requirement.id with no ON DELETE CASCADE configured at the DB level
    (only Evidence has an ORM-level cascade via the `evidence`
    relationship on Requirement) — deleting Requirement rows first would
    raise a ForeignKeyViolation from ChecklistItem/ReviewItem/
    FieldCorrection still pointing at them. Children are deleted before
    parents throughout.
    """
    from app.models.analysis import Evidence
    from app.models.checklist import ChecklistItem, TenderQuestion
    from app.models.review import FieldCorrection

    requirement_ids_subq = select(Requirement.id).where(Requirement.tender_id == tender.id).scalar_subquery()

    db.execute(delete(Evidence).where(Evidence.requirement_id.in_(requirement_ids_subq)))
    db.execute(delete(FieldCorrection).where(FieldCorrection.requirement_id.in_(requirement_ids_subq)))
    db.execute(delete(ReviewItem).where(ReviewItem.tender_id == tender.id))
    db.execute(delete(ChecklistItem).where(ChecklistItem.tender_id == tender.id))
    db.execute(delete(TenderQuestion).where(TenderQuestion.tender_id == tender.id))
    db.execute(delete(Risk).where(Risk.tender_id == tender.id))
    db.execute(delete(BidAssessment).where(BidAssessment.tender_id == tender.id))
    db.execute(delete(Requirement).where(Requirement.tender_id == tender.id))
    db.execute(delete(AnalysisJob).where(AnalysisJob.tender_id == tender.id))
    db.commit()


def reset_tender_analysis(db: Session, tender: Tender) -> None:
    """
    Public entry point for the "Delete analysis" button — clears all
    analysis data AND resets the tender back to DRAFT. Documents
    themselves are NOT touched, so re-running analysis afterward doesn't
    require re-uploading anything.
    """
    _clear_analysis_data(db, tender)

    tender.status = TenderStatus.DRAFT
    tender.submission_deadline = None
    tender.submission_deadline_timezone = None
    tender.submission_deadline_is_uncertain = False
    db.commit()
