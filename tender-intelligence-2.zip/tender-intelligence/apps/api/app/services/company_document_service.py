import hashlib
import uuid
from io import BytesIO
from pathlib import Path

from fastapi import HTTPException, UploadFile, status
from sqlalchemy import select
from sqlalchemy.orm import Session

from app.core.config import settings
from app.documents.storage import get_storage
from app.models.company_document import CompanyDocument
from app.schemas.company_document import CompanyDocumentUpdate
from app.security.tenancy import CurrentContext
from app.utils.audit import record_audit

# Company library evidence is broader than tender-notice uploads (also
# accepts images of certificates, common in practice) — a slightly wider
# allow-list than app/services/document_service.py's tender-document one.
ALLOWED_EXTENSIONS = {".pdf", ".docx", ".doc", ".png", ".jpg", ".jpeg"}
MAX_UPLOAD_BYTES = settings.MAX_UPLOAD_SIZE_MB * 1024 * 1024


async def upload_company_document(
    db: Session,
    ctx: CurrentContext,
    file: UploadFile,
    *,
    name: str,
    category: str,
    issuing_body: str | None,
    expiry_date,
) -> CompanyDocument:
    ext = Path(file.filename or "").suffix.lower()
    if ext not in ALLOWED_EXTENSIONS:
        raise HTTPException(
            status.HTTP_400_BAD_REQUEST,
            f"Unsupported file type '{ext}'. Allowed: {', '.join(sorted(ALLOWED_EXTENSIONS))}",
        )

    contents = await file.read()
    if len(contents) > MAX_UPLOAD_BYTES:
        raise HTTPException(status.HTTP_413_REQUEST_ENTITY_TOO_LARGE, f"File exceeds the {settings.MAX_UPLOAD_SIZE_MB}MB limit")
    if len(contents) == 0:
        raise HTTPException(status.HTTP_400_BAD_REQUEST, "Uploaded file is empty")

    doc_id = uuid.uuid4()
    storage_key = f"org/{ctx.organization_id}/company-documents/{doc_id}{ext}"
    get_storage().put(storage_key, BytesIO(contents), file.content_type or "application/octet-stream")

    doc = CompanyDocument(
        id=doc_id,
        organization_id=ctx.organization_id,
        uploaded_by_user_id=ctx.user.id,
        name=name,
        category=category,
        issuing_body=issuing_body,
        storage_key=storage_key,
        original_filename=file.filename or "unnamed",
        content_type=file.content_type or "application/octet-stream",
        size_bytes=len(contents),
        expiry_date=expiry_date,
    )
    db.add(doc)
    record_audit(
        db,
        organization_id=ctx.organization_id,
        actor_user_id=ctx.user.id,
        action="company_document.uploaded",
        resource_type="company_document",
        resource_id=str(doc.id),
        metadata={"name": name, "category": category},
    )
    db.commit()
    db.refresh(doc)
    return doc


def list_company_documents(db: Session, ctx: CurrentContext) -> list[CompanyDocument]:
    return list(
        db.execute(
            select(CompanyDocument).where(
                CompanyDocument.organization_id == ctx.organization_id, CompanyDocument.deleted_at.is_(None)
            )
        ).scalars()
    )


def get_company_document_or_404(db: Session, ctx: CurrentContext, document_id: uuid.UUID) -> CompanyDocument:
    doc = db.execute(
        select(CompanyDocument).where(
            CompanyDocument.id == document_id,
            CompanyDocument.organization_id == ctx.organization_id,
            CompanyDocument.deleted_at.is_(None),
        )
    ).scalar_one_or_none()
    if doc is None:
        raise HTTPException(status.HTTP_404_NOT_FOUND, "Document not found")
    return doc


def update_company_document(
    db: Session, ctx: CurrentContext, document_id: uuid.UUID, payload: CompanyDocumentUpdate
) -> CompanyDocument:
    doc = get_company_document_or_404(db, ctx, document_id)
    for field, value in payload.model_dump(exclude_unset=True).items():
        setattr(doc, field, value)
    db.commit()
    db.refresh(doc)
    return doc


def delete_company_document(db: Session, ctx: CurrentContext, document_id: uuid.UUID) -> None:
    from datetime import datetime, timezone

    doc = get_company_document_or_404(db, ctx, document_id)
    doc.deleted_at = datetime.now(timezone.utc)
    record_audit(
        db,
        organization_id=ctx.organization_id,
        actor_user_id=ctx.user.id,
        action="company_document.deleted",
        resource_type="company_document",
        resource_id=str(doc.id),
    )
    db.commit()
