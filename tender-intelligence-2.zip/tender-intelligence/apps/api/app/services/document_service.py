import hashlib
import uuid
from pathlib import Path

from fastapi import HTTPException, UploadFile, status
from sqlalchemy import select
from sqlalchemy.orm import Session

from app.core.config import settings
from app.documents.storage import get_storage
from app.models.document import TenderDocument
from app.models.enums import DocumentStatus
from app.security.tenancy import CurrentContext
from app.services.tender_service import get_tender_or_404
from app.utils.audit import record_audit

MAX_UPLOAD_BYTES = settings.MAX_UPLOAD_SIZE_MB * 1024 * 1024


def _validate_extension(filename: str) -> str:
    ext = Path(filename).suffix.lower()
    if ext not in settings.ALLOWED_UPLOAD_EXTENSIONS:
        raise HTTPException(
            status.HTTP_400_BAD_REQUEST,
            f"Unsupported file type '{ext}'. Allowed: {', '.join(settings.ALLOWED_UPLOAD_EXTENSIONS)}",
        )
    return ext


async def upload_document(
    db: Session,
    ctx: CurrentContext,
    tender_id: uuid.UUID,
    file: UploadFile,
    document_kind: str = "tender_document",
) -> TenderDocument:
    """
    Spec §117.E: uploaded documents are untrusted data. We: (1) restrict
    extension, (2) enforce a size cap, (3) store under an opaque
    uuid-derived key (never the user-supplied filename) so no path
    traversal / overwrite is possible, (4) never execute or template
    anything from the file content.
    """
    tender = get_tender_or_404(db, ctx, tender_id)
    ext = _validate_extension(file.filename or "")

    contents = await file.read()
    if len(contents) > MAX_UPLOAD_BYTES:
        raise HTTPException(
            status.HTTP_413_REQUEST_ENTITY_TOO_LARGE,
            f"File exceeds the {settings.MAX_UPLOAD_SIZE_MB}MB limit",
        )
    if len(contents) == 0:
        raise HTTPException(status.HTTP_400_BAD_REQUEST, "Uploaded file is empty")

    sha256 = hashlib.sha256(contents).hexdigest()
    doc_id = uuid.uuid4()
    storage_key = f"org/{ctx.organization_id}/tender/{tender_id}/{doc_id}{ext}"

    storage = get_storage()
    from io import BytesIO

    storage.put(storage_key, BytesIO(contents), file.content_type or "application/octet-stream")

    document = TenderDocument(
        id=doc_id,
        tender_id=tender.id,
        organization_id=ctx.organization_id,
        original_filename=file.filename or "unnamed",
        storage_key=storage_key,
        content_type=file.content_type or "application/octet-stream",
        size_bytes=len(contents),
        sha256=sha256,
        document_kind=document_kind,
        status=DocumentStatus.UPLOADED,
    )
    db.add(document)
    record_audit(
        db,
        organization_id=ctx.organization_id,
        actor_user_id=ctx.user.id,
        action="document.uploaded",
        resource_type="tender_document",
        resource_id=str(document.id),
        metadata={"filename": document.original_filename, "size_bytes": document.size_bytes},
    )
    db.commit()
    db.refresh(document)
    return document


def list_documents(db: Session, ctx: CurrentContext, tender_id: uuid.UUID) -> list[TenderDocument]:
    get_tender_or_404(db, ctx, tender_id)  # 404s + enforces tenant scope
    return list(
        db.execute(
            select(TenderDocument).where(
                TenderDocument.tender_id == tender_id,
                TenderDocument.organization_id == ctx.organization_id,
                TenderDocument.deleted_at.is_(None),
            )
        ).scalars()
    )


def get_document_or_404(db: Session, ctx: CurrentContext, document_id: uuid.UUID) -> TenderDocument:
    doc = db.execute(
        select(TenderDocument).where(
            TenderDocument.id == document_id,
            TenderDocument.organization_id == ctx.organization_id,
            TenderDocument.deleted_at.is_(None),
        )
    ).scalar_one_or_none()
    if doc is None:
        raise HTTPException(status.HTTP_404_NOT_FOUND, "Document not found")
    return doc


def delete_document(db: Session, ctx: CurrentContext, document_id: uuid.UUID) -> None:
    from datetime import datetime, timezone

    doc = get_document_or_404(db, ctx, document_id)
    doc.deleted_at = datetime.now(timezone.utc)
    record_audit(
        db,
        organization_id=ctx.organization_id,
        actor_user_id=ctx.user.id,
        action="document.deleted",
        resource_type="tender_document",
        resource_id=str(doc.id),
    )
    db.commit()
    # Object storage bytes are purged by the retention worker on a delay,
    # not synchronously, so an accidental delete has a recovery window
    # (spec §106 Data Lifecycle).
