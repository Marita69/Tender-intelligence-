"""
Generates the professional tender analysis report described in spec §105:
cover, executive summary, score, key findings, tables, risks, action plan,
source references, footer/page numbers. Avoids decorative graphics and
unverifiable claims — every requirement listed includes its confidence and
whether it was directly stated vs inferred.
"""
from __future__ import annotations

import io
import uuid
from xml.sax.saxutils import escape as _xml_escape

from reportlab.lib import colors
from reportlab.lib.pagesizes import A4
from reportlab.lib.styles import ParagraphStyle, getSampleStyleSheet
from reportlab.lib.units import cm
from reportlab.platypus import (
    PageBreak,
    Paragraph,
    SimpleDocTemplate,
    Spacer,
    Table,
    TableStyle,
)
from sqlalchemy import select
from sqlalchemy.orm import Session

from app.models.analysis import BidAssessment, Requirement, Risk
from app.models.checklist import ChecklistItem
from app.models.tender import Tender


def _e(text: str | None) -> str:
    """
    Escape text for ReportLab's Paragraph, which parses its input as a
    small XML/HTML-like markup language -- NOT plain text. Any tender or
    AI-generated text containing '&', '<', or '>' (extremely common in
    real tender language: "Terms & Conditions", "less than 5 years",
    "R&D") would otherwise raise an XML parse error and crash PDF
    generation entirely. Every dynamic string interpolated into a
    Paragraph() call in this module MUST go through this first. Literal
    markup we intentionally emit ourselves (e.g. "<b>...</b>") is added
    AFTER escaping the dynamic parts, never escaped itself.
    """
    if not text:
        return ""
    return _xml_escape(str(text))


def _gather_report_data(db: Session, tender_id: uuid.UUID) -> dict:
    tender = db.get(Tender, tender_id)
    requirements = list(db.execute(select(Requirement).where(Requirement.tender_id == tender_id)).scalars())
    risks = list(db.execute(select(Risk).where(Risk.tender_id == tender_id)).scalars())
    checklist = list(db.execute(select(ChecklistItem).where(ChecklistItem.tender_id == tender_id)).scalars())
    assessment = db.execute(
        select(BidAssessment).where(BidAssessment.tender_id == tender_id).order_by(BidAssessment.created_at.desc())
    ).scalars().first()
    return {
        "tender": tender,
        "requirements": requirements,
        "risks": risks,
        "checklist": checklist,
        "assessment": assessment,
    }


def generate_pdf_report(db: Session, tender_id: uuid.UUID, brand_name: str) -> bytes:
    data = _gather_report_data(db, tender_id)
    tender: Tender = data["tender"]

    buffer = io.BytesIO()
    doc = SimpleDocTemplate(
        buffer,
        pagesize=A4,
        topMargin=2 * cm,
        bottomMargin=2 * cm,
        leftMargin=2 * cm,
        rightMargin=2 * cm,
        title=f"Tender Analysis Report - {tender.title}",
    )
    styles = getSampleStyleSheet()
    title_style = ParagraphStyle("TitleBig", parent=styles["Title"], fontSize=22, spaceAfter=12)
    h2 = ParagraphStyle("H2", parent=styles["Heading2"], spaceBefore=14, spaceAfter=8)
    body = styles["BodyText"]

    story = []

    # --- Cover ---
    story.append(Spacer(1, 4 * cm))
    story.append(Paragraph(_e(brand_name), styles["Heading3"]))
    story.append(Paragraph("Tender Analysis Report", title_style))
    story.append(Paragraph(_e(tender.title), styles["Heading2"]))
    if tender.reference_number:
        story.append(Paragraph(f"Reference: {_e(tender.reference_number)}", body))
    if tender.issuing_entity:
        story.append(Paragraph(f"Issuing entity: {_e(tender.issuing_entity)}", body))
    story.append(PageBreak())

    # --- Executive summary / score ---
    story.append(Paragraph("Executive Summary", h2))
    assessment: BidAssessment | None = data["assessment"]
    if assessment:
        story.append(
            Paragraph(
                f"<b>Recommendation:</b> {_e(assessment.recommendation.value.replace('_', ' ').title())} "
                f"&nbsp;&nbsp; <b>Score:</b> {assessment.score:.0f}/100 "
                f"&nbsp;&nbsp; <b>Confidence:</b> {_e(assessment.confidence.value.title())}",
                body,
            )
        )
        story.append(Spacer(1, 0.3 * cm))
        story.append(Paragraph(_e(assessment.rationale), body))
    else:
        story.append(Paragraph("No bid assessment is available for this tender yet.", body))

    # --- Key findings / requirements table ---
    story.append(Paragraph("Key Findings", h2))
    table_data = [["Type", "Requirement", "Confidence", "Source"]]
    for req in data["requirements"][:60]:  # cap to keep the report readable; full list is in-app
        source = f"p.{req.evidence[0].page_number}" if req.evidence else "Unverified / inferred"
        table_data.append(
            [
                req.type.value.replace("_", " ").title(),
                Paragraph(_e(req.summary), body),
                req.confidence.value.title(),
                source,
            ]
        )
    tbl = Table(table_data, colWidths=[3.2 * cm, 8 * cm, 2.5 * cm, 3 * cm], repeatRows=1)
    tbl.setStyle(
        TableStyle(
            [
                ("BACKGROUND", (0, 0), (-1, 0), colors.HexColor("#1f2937")),
                ("TEXTCOLOR", (0, 0), (-1, 0), colors.white),
                ("FONTSIZE", (0, 0), (-1, -1), 8),
                ("GRID", (0, 0), (-1, -1), 0.25, colors.HexColor("#d1d5db")),
                ("VALIGN", (0, 0), (-1, -1), "TOP"),
                ("ROWBACKGROUNDS", (0, 1), (-1, -1), [colors.white, colors.HexColor("#f9fafb")]),
            ]
        )
    )
    story.append(tbl)

    # --- Risks ---
    story.append(Paragraph("Risks & Disqualifying Clauses", h2))
    if data["risks"]:
        for risk in data["risks"]:
            marker = "⚠ DISQUALIFYING" if risk.is_disqualifying else risk.severity.value.upper()
            story.append(Paragraph(f"<b>[{_e(marker)}] {_e(risk.title)}</b> — {_e(risk.description)}", body))
            story.append(Spacer(1, 0.2 * cm))
    else:
        story.append(Paragraph("No risks were identified by the analysis.", body))

    # --- Action plan (checklist) ---
    story.append(Paragraph("Action Plan / Compliance Checklist", h2))
    checklist_data = [["Item", "Status"]]
    for item in data["checklist"]:
        checklist_data.append([Paragraph(_e(item.label), body), item.status.value.replace("_", " ").title()])
    if len(checklist_data) > 1:
        ctbl = Table(checklist_data, colWidths=[13 * cm, 3.5 * cm], repeatRows=1)
        ctbl.setStyle(
            TableStyle(
                [
                    ("BACKGROUND", (0, 0), (-1, 0), colors.HexColor("#1f2937")),
                    ("TEXTCOLOR", (0, 0), (-1, 0), colors.white),
                    ("FONTSIZE", (0, 0), (-1, -1), 8),
                    ("GRID", (0, 0), (-1, -1), 0.25, colors.HexColor("#d1d5db")),
                ]
            )
        )
        story.append(ctbl)
    else:
        story.append(Paragraph("No checklist items were generated for this tender.", body))

    def _footer(canvas, doc_):
        canvas.saveState()
        canvas.setFont("Helvetica", 8)
        canvas.setFillColor(colors.HexColor("#6b7280"))
        canvas.drawString(2 * cm, 1.3 * cm, f"{brand_name} — Decision-support analysis. Verify against source documents.")
        canvas.drawRightString(A4[0] - 2 * cm, 1.3 * cm, f"Page {doc_.page}")
        canvas.restoreState()

    doc.build(story, onFirstPage=_footer, onLaterPages=_footer)
    return buffer.getvalue()


def generate_docx_report(db: Session, tender_id: uuid.UUID, brand_name: str) -> bytes:
    import docx
    from docx.shared import Pt

    data = _gather_report_data(db, tender_id)
    tender: Tender = data["tender"]
    assessment: BidAssessment | None = data["assessment"]

    document = docx.Document()
    document.add_heading(brand_name, level=3)
    document.add_heading("Tender Analysis Report", level=0)
    document.add_heading(tender.title, level=1)
    if tender.reference_number:
        document.add_paragraph(f"Reference: {tender.reference_number}")
    if tender.issuing_entity:
        document.add_paragraph(f"Issuing entity: {tender.issuing_entity}")

    document.add_heading("Executive Summary", level=2)
    if assessment:
        p = document.add_paragraph()
        p.add_run(
            f"Recommendation: {assessment.recommendation.value.replace('_', ' ').title()}  |  "
            f"Score: {assessment.score:.0f}/100  |  Confidence: {assessment.confidence.value.title()}"
        ).bold = True
        document.add_paragraph(assessment.rationale)
    else:
        document.add_paragraph("No bid assessment is available for this tender yet.")

    document.add_heading("Key Findings", level=2)
    table = document.add_table(rows=1, cols=4)
    table.style = "Light Grid Accent 1"
    hdr = table.rows[0].cells
    hdr[0].text, hdr[1].text, hdr[2].text, hdr[3].text = "Type", "Requirement", "Confidence", "Source"
    for req in data["requirements"][:60]:
        row = table.add_row().cells
        row[0].text = req.type.value.replace("_", " ").title()
        row[1].text = req.summary
        row[2].text = req.confidence.value.title()
        row[3].text = f"p.{req.evidence[0].page_number}" if req.evidence else "Unverified / inferred"

    document.add_heading("Risks & Disqualifying Clauses", level=2)
    if data["risks"]:
        for risk in data["risks"]:
            marker = "DISQUALIFYING" if risk.is_disqualifying else risk.severity.value.upper()
            document.add_paragraph(f"[{marker}] {risk.title} — {risk.description}")
    else:
        document.add_paragraph("No risks were identified by the analysis.")

    document.add_heading("Action Plan / Compliance Checklist", level=2)
    if data["checklist"]:
        ctable = document.add_table(rows=1, cols=2)
        ctable.style = "Light Grid Accent 1"
        chdr = ctable.rows[0].cells
        chdr[0].text, chdr[1].text = "Item", "Status"
        for item in data["checklist"]:
            row = ctable.add_row().cells
            row[0].text = item.label
            row[1].text = item.status.value.replace("_", " ").title()
    else:
        document.add_paragraph("No checklist items were generated for this tender.")

    footer_p = document.sections[0].footer.paragraphs[0]
    footer_p.text = f"{brand_name} — Decision-support analysis. Verify against source documents."
    for run in footer_p.runs:
        run.font.size = Pt(8)

    buffer = io.BytesIO()
    document.save(buffer)
    return buffer.getvalue()
