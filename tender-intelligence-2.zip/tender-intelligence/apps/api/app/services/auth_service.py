import re
import uuid

from fastapi import HTTPException, status
from sqlalchemy import select
from sqlalchemy.orm import Session

from app.core.config import settings
from app.core.security import (
    create_access_token,
    create_refresh_token,
    decode_token,
    hash_password,
    verify_password,
)
from app.models.enums import MembershipRole
from app.models.organization import Organization, OrganizationMembership, User
from app.schemas.auth import LoginRequest, SignupRequest, TokenResponse, UserUpdate
from app.utils.audit import record_audit


def _slugify(name: str) -> str:
    slug = re.sub(r"[^a-z0-9]+", "-", name.lower()).strip("-")
    return slug or "org"


def _sync_platform_admin_flag(user: User) -> None:
    """
    The single source of truth for who is a platform admin is
    `settings.ADMIN_EMAIL`, compared case-insensitively. This runs on every
    signup and login so that: (a) the matching account is elevated the
    moment it authenticates, even if it existed before ADMIN_EMAIL was set,
    and (b) if ADMIN_EMAIL is ever changed or cleared, the previous admin's
    flag is revoked on their next login rather than lingering forever.
    Nothing else in the codebase is allowed to set is_platform_admin —
    there is no API endpoint that accepts it as input.
    """
    should_be_admin = bool(settings.ADMIN_EMAIL) and user.email.lower() == settings.ADMIN_EMAIL.lower()
    if user.is_platform_admin != should_be_admin:
        user.is_platform_admin = should_be_admin


def signup(db: Session, payload: SignupRequest) -> tuple[User, Organization, TokenResponse]:
    existing = db.execute(select(User).where(User.email == payload.email.lower())).scalar_one_or_none()
    if existing:
        raise HTTPException(status.HTTP_409_CONFLICT, "An account with this email already exists")

    user = User(
        email=payload.email.lower(),
        hashed_password=hash_password(payload.password),
        full_name=payload.full_name,
    )
    _sync_platform_admin_flag(user)
    db.add(user)
    db.flush()  # assign user.id without committing yet

    base_slug = _slugify(payload.organization_name)
    slug = base_slug
    suffix = 1
    while db.execute(select(Organization).where(Organization.slug == slug)).scalar_one_or_none():
        suffix += 1
        slug = f"{base_slug}-{suffix}"

    org = Organization(name=payload.organization_name, slug=slug)
    db.add(org)
    db.flush()

    membership = OrganizationMembership(user_id=user.id, organization_id=org.id, role=MembershipRole.OWNER)
    db.add(membership)

    record_audit(
        db,
        organization_id=org.id,
        actor_user_id=user.id,
        action="organization.created",
        resource_type="organization",
        resource_id=str(org.id),
    )
    record_audit(
        db,
        organization_id=org.id,
        actor_user_id=user.id,
        action="user.signed_up",
        resource_type="user",
        resource_id=str(user.id),
    )

    db.commit()
    db.refresh(user)
    db.refresh(org)

    tokens = TokenResponse(
        access_token=create_access_token(str(user.id)),
        refresh_token=create_refresh_token(str(user.id)),
    )
    return user, org, tokens


def login(db: Session, payload: LoginRequest) -> tuple[User, TokenResponse]:
    user = db.execute(select(User).where(User.email == payload.email.lower())).scalar_one_or_none()
    if not user or not verify_password(payload.password, user.hashed_password):
        # Identical error for "no such user" and "wrong password" —
        # never reveal which one it was.
        raise HTTPException(status.HTTP_401_UNAUTHORIZED, "Incorrect email or password")
    if not user.is_active:
        raise HTTPException(status.HTTP_403_FORBIDDEN, "Account is disabled")

    _sync_platform_admin_flag(user)
    db.commit()

    tokens = TokenResponse(
        access_token=create_access_token(str(user.id)),
        refresh_token=create_refresh_token(str(user.id)),
    )
    return user, tokens


def refresh(db: Session, refresh_token: str) -> TokenResponse:
    payload = decode_token(refresh_token)
    if not payload or payload.get("type") != "refresh":
        raise HTTPException(status.HTTP_401_UNAUTHORIZED, "Invalid or expired refresh token")
    user_id = uuid.UUID(payload["sub"])
    user = db.get(User, user_id)
    if not user or not user.is_active:
        raise HTTPException(status.HTTP_401_UNAUTHORIZED, "User not found or inactive")
    return TokenResponse(
        access_token=create_access_token(str(user.id)),
        refresh_token=create_refresh_token(str(user.id)),
    )


def update_profile(db: Session, user: User, payload: UserUpdate) -> User:
    for field, value in payload.model_dump(exclude_unset=True).items():
        setattr(user, field, value)
    db.commit()
    db.refresh(user)
    return user


def change_password(db: Session, user: User, current_password: str, new_password: str) -> None:
    if not verify_password(current_password, user.hashed_password):
        raise HTTPException(status.HTTP_401_UNAUTHORIZED, "Current password is incorrect")
    user.hashed_password = hash_password(new_password)
    db.commit()
