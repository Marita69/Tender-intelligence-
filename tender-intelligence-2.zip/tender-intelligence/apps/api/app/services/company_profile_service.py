from sqlalchemy import select
from sqlalchemy.orm import Session

from app.models.company_profile import CompanyProfile
from app.schemas.checklist import CompanyProfileIn
from app.security.tenancy import CurrentContext


def get_profile(db: Session, ctx: CurrentContext) -> CompanyProfile | None:
    return db.execute(
        select(CompanyProfile).where(CompanyProfile.organization_id == ctx.organization_id)
    ).scalar_one_or_none()


def upsert_profile(db: Session, ctx: CurrentContext, payload: CompanyProfileIn) -> CompanyProfile:
    profile = get_profile(db, ctx)
    if profile is None:
        profile = CompanyProfile(organization_id=ctx.organization_id, **payload.model_dump())
        db.add(profile)
    else:
        for field, value in payload.model_dump().items():
            setattr(profile, field, value)
    db.commit()
    db.refresh(profile)
    return profile
