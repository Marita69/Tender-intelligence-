"""
Billing abstraction (spec §117.I: payment events must be idempotent).

BILLING_PROVIDER=none disables real billing and gives every organization
unlimited analyses in dev. Set BILLING_PROVIDER=stripe and wire real keys
for production — see PRODUCTION_GUIDE.md. The credits ledger design means
switching or adding a second provider later doesn't require a schema
change, only a new webhook handler that writes UsageCredit rows.
"""
import uuid

from sqlalchemy import func, select
from sqlalchemy.orm import Session

from app.core.config import settings
from app.models.billing import BillingEvent, UsageCredit


def get_credit_balance(db: Session, organization_id: uuid.UUID) -> int:
    total = db.execute(
        select(func.coalesce(func.sum(UsageCredit.delta), 0)).where(UsageCredit.organization_id == organization_id)
    ).scalar_one()
    return int(total)


def has_available_credit(db: Session, organization_id: uuid.UUID) -> bool:
    if settings.BILLING_PROVIDER == "none":
        return True  # billing disabled: unlimited usage (dev / self-hosted mode)
    return get_credit_balance(db, organization_id) > 0


def consume_credit(db: Session, organization_id: uuid.UUID, reason: str = "analysis_consumed") -> None:
    if settings.BILLING_PROVIDER == "none":
        return
    db.add(UsageCredit(organization_id=organization_id, delta=-1, reason=reason))
    db.commit()


def record_webhook_event(db: Session, provider: str, external_event_id: str, event_type: str, payload: dict) -> bool:
    """
    Returns False (and does nothing else) if this event_id was already
    processed — this is the idempotency guarantee required by spec §117.I.
    Stripe (and most providers) retry webhooks, so this MUST be checked
    before applying any credit/plan change.
    """
    existing = db.execute(
        select(BillingEvent).where(BillingEvent.external_event_id == external_event_id)
    ).scalar_one_or_none()
    if existing is not None:
        return False
    db.add(
        BillingEvent(
            provider=provider,
            external_event_id=external_event_id,
            event_type=event_type,
            payload=payload,
        )
    )
    db.commit()
    return True


def grant_credits(db: Session, organization_id: uuid.UUID, amount: int, external_event_id: str) -> None:
    db.add(
        UsageCredit(
            organization_id=organization_id,
            delta=amount,
            reason="purchase",
            external_event_id=external_event_id,
        )
    )
    db.commit()


def create_checkout_session_url(organization_id: uuid.UUID, success_url: str, cancel_url: str) -> str:
    """
    Creates a Stripe Checkout Session for purchasing a fixed bundle of
    analysis credits (STRIPE_CREDITS_PER_PURCHASE per STRIPE_PRICE_ID —
    set both to match whatever product/price you create in the Stripe
    dashboard, see PRODUCTION_GUIDE.md Part 5). client_reference_id carries
    the organization_id through to the webhook so
    checkout.session.completed can credit the right org.
    """
    import stripe

    stripe.api_key = settings.STRIPE_SECRET_KEY
    session = stripe.checkout.Session.create(
        mode="payment",
        line_items=[{"price": settings.STRIPE_PRICE_ID, "quantity": 1}],
        client_reference_id=str(organization_id),
        metadata={"credits": str(settings.STRIPE_CREDITS_PER_PURCHASE), "organization_id": str(organization_id)},
        success_url=success_url,
        cancel_url=cancel_url,
    )
    return session.url
