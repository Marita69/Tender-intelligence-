import uuid
from datetime import datetime, timezone

from fastapi import HTTPException, status
from sqlalchemy import select
from sqlalchemy.orm import Session

from app.models.analysis import Requirement
from app.models.enums import ReviewStatus
from app.models.review import ReviewItem
from app.models.tender import Tender
from app.schemas.review import ReviewItemUpdate
from app.security.tenancy import CurrentContext
from app.utils.audit import record_audit


def list_review_queue(
    db: Session, ctx: CurrentContext, *, status_filter: ReviewStatus | None, tender_id: uuid.UUID | None
) -> list[tuple[ReviewItem, Requirement | None]]:
    """
    Org-wide review queue (spec §109) — not scoped to a single tender by
    default, since a reviewer's job is to work through everything flagged
    across all of the organization's tenders. Join to Tender to enforce
    tenant isolation without trusting ReviewItem.tender_id alone.
    """
    stmt = (
        select(ReviewItem, Requirement)
        .join(Tender, ReviewItem.tender_id == Tender.id)
        .outerjoin(Requirement, ReviewItem.requirement_id == Requirement.id)
        .where(Tender.organization_id == ctx.organization_id, Tender.deleted_at.is_(None))
    )
    if status_filter is not None:
        stmt = stmt.where(ReviewItem.status == status_filter)
    if tender_id is not None:
        stmt = stmt.where(ReviewItem.tender_id == tender_id)

    rows = db.execute(stmt.order_by(ReviewItem.created_at.desc())).all()
    return [(review, req) for review, req in rows]


def get_review_item_or_404(db: Session, ctx: CurrentContext, review_id: uuid.UUID) -> ReviewItem:
    review = db.execute(
        select(ReviewItem)
        .join(Tender, ReviewItem.tender_id == Tender.id)
        .where(ReviewItem.id == review_id, Tender.organization_id == ctx.organization_id)
    ).scalar_one_or_none()
    if review is None:
        raise HTTPException(status.HTTP_404_NOT_FOUND, "Review item not found")
    return review


def update_review_item(
    db: Session, ctx: CurrentContext, review_id: uuid.UUID, payload: ReviewItemUpdate
) -> tuple[ReviewItem, Requirement | None]:
    review = get_review_item_or_404(db, ctx, review_id)
    review.status = payload.status
    review.reviewed_by_user_id = ctx.user.id
    review.reviewed_at = datetime.now(timezone.utc)

    record_audit(
        db,
        organization_id=ctx.organization_id,
        actor_user_id=ctx.user.id,
        action="review_item.updated",
        resource_type="review_item",
        resource_id=str(review.id),
        metadata={"status": payload.status.value},
    )
    db.commit()
    db.refresh(review)

    requirement = None
    if review.requirement_id:
        requirement = db.get(Requirement, review.requirement_id)
    return review, requirement


def review_queue_counts(db: Session, ctx: CurrentContext) -> dict:
    items = list_review_queue(db, ctx, status_filter=None, tender_id=None)
    counts: dict[str, int] = {}
    for review, _req in items:
        counts[review.status.value] = counts.get(review.status.value, 0) + 1
    return counts
