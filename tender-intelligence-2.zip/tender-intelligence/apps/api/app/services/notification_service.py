import uuid

from fastapi import HTTPException, status
from sqlalchemy import func, or_, select
from sqlalchemy.orm import Session

from app.models.notification import Notification, NotificationPreference, NotificationType
from app.security.tenancy import CurrentContext


def create_notification(
    db: Session,
    *,
    organization_id: uuid.UUID,
    user_id: uuid.UUID | None,
    type: NotificationType,
    title: str,
    body: str | None = None,
    tender_id: uuid.UUID | None = None,
) -> Notification:
    """
    Does not commit — callers (analysis pipeline, scheduled workers) are
    already inside a transaction and should commit once at the end of
    their own unit of work. There's no email delivery implemented yet (see
    PAGES.md) — `email_digest` is stored as a preference but not acted on.
    """
    notification = Notification(
        organization_id=organization_id,
        user_id=user_id,
        type=type,
        title=title,
        body=body,
        tender_id=tender_id,
    )
    db.add(notification)
    return notification


def list_notifications(db: Session, ctx: CurrentContext, *, unread_only: bool = False) -> list[Notification]:
    stmt = select(Notification).where(
        Notification.organization_id == ctx.organization_id,
        or_(Notification.user_id == ctx.user.id, Notification.user_id.is_(None)),
    )
    if unread_only:
        stmt = stmt.where(Notification.is_read.is_(False))
    return list(db.execute(stmt.order_by(Notification.created_at.desc())).scalars())


def unread_count(db: Session, ctx: CurrentContext) -> int:
    return db.execute(
        select(func.count())
        .select_from(Notification)
        .where(
            Notification.organization_id == ctx.organization_id,
            or_(Notification.user_id == ctx.user.id, Notification.user_id.is_(None)),
            Notification.is_read.is_(False),
        )
    ).scalar_one()


def mark_read(db: Session, ctx: CurrentContext, notification_id: uuid.UUID) -> Notification:
    notification = db.execute(
        select(Notification).where(
            Notification.id == notification_id,
            Notification.organization_id == ctx.organization_id,
            or_(Notification.user_id == ctx.user.id, Notification.user_id.is_(None)),
        )
    ).scalar_one_or_none()
    if notification is None:
        raise HTTPException(status.HTTP_404_NOT_FOUND, "Notification not found")
    notification.is_read = True
    db.commit()
    db.refresh(notification)
    return notification


def mark_all_read(db: Session, ctx: CurrentContext) -> int:
    items = list_notifications(db, ctx, unread_only=True)
    for item in items:
        item.is_read = True
    db.commit()
    return len(items)


def get_preferences(db: Session, ctx: CurrentContext) -> NotificationPreference:
    prefs = db.execute(
        select(NotificationPreference).where(NotificationPreference.user_id == ctx.user.id)
    ).scalar_one_or_none()
    if prefs is None:
        prefs = NotificationPreference(user_id=ctx.user.id)
        db.add(prefs)
        db.commit()
        db.refresh(prefs)
    return prefs


def update_preferences(db: Session, ctx: CurrentContext, payload) -> NotificationPreference:
    prefs = get_preferences(db, ctx)
    for field, value in payload.model_dump(exclude_unset=True).items():
        setattr(prefs, field, value)
    db.commit()
    db.refresh(prefs)
    return prefs
