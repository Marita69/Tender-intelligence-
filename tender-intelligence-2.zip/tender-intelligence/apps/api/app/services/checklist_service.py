import uuid

from fastapi import HTTPException, status
from sqlalchemy import select
from sqlalchemy.orm import Session

from app.models.analysis import Evidence, Requirement
from app.models.checklist import ChecklistItem, Task
from app.schemas.checklist import ChecklistItemOut, ChecklistItemUpdate, TaskCreate, TaskUpdate
from app.security.tenancy import CurrentContext
from app.services.tender_service import get_tender_or_404
from app.utils.audit import record_audit


def _enrich(db: Session, items: list[ChecklistItem]) -> list[ChecklistItemOut]:
    requirement_ids = [i.requirement_id for i in items if i.requirement_id]
    requirements: dict[uuid.UUID, Requirement] = {}
    evidence_by_requirement: dict[uuid.UUID, Evidence] = {}
    if requirement_ids:
        requirements = {
            r.id: r
            for r in db.execute(select(Requirement).where(Requirement.id.in_(requirement_ids))).scalars()
        }
        for ev in db.execute(select(Evidence).where(Evidence.requirement_id.in_(requirement_ids))).scalars():
            evidence_by_requirement.setdefault(ev.requirement_id, ev)

    out: list[ChecklistItemOut] = []
    for item in items:
        req = requirements.get(item.requirement_id) if item.requirement_id else None
        ev = evidence_by_requirement.get(item.requirement_id) if item.requirement_id else None
        out.append(
            ChecklistItemOut(
                id=item.id,
                label=item.label,
                status=item.status,
                linked_document_id=item.linked_document_id,
                notes=item.notes,
                requirement_type=req.type.value if req else None,
                confidence=req.confidence if req else None,
                evidence_document_id=ev.document_id if ev else None,
                evidence_page_number=ev.page_number if ev else None,
                evidence_quote=ev.quoted_text if ev else None,
            )
        )
    return out


def list_checklist(db: Session, ctx: CurrentContext, tender_id: uuid.UUID) -> list[ChecklistItemOut]:
    """
    Returns checklist items enriched with their linked Requirement's type/
    confidence and first Evidence citation — the Compliance Matrix view
    needs "mandatory", "AI confidence", and "source" columns, which live on
    Requirement/Evidence, not duplicated onto ChecklistItem.
    """
    get_tender_or_404(db, ctx, tender_id)
    items = list(db.execute(select(ChecklistItem).where(ChecklistItem.tender_id == tender_id)).scalars())
    return _enrich(db, items)


def update_checklist_item(
    db: Session, ctx: CurrentContext, tender_id: uuid.UUID, item_id: uuid.UUID, payload: ChecklistItemUpdate
) -> ChecklistItemOut:
    get_tender_or_404(db, ctx, tender_id)
    item = db.execute(
        select(ChecklistItem).where(ChecklistItem.id == item_id, ChecklistItem.tender_id == tender_id)
    ).scalar_one_or_none()
    if item is None:
        raise HTTPException(status.HTTP_404_NOT_FOUND, "Checklist item not found")
    for field, value in payload.model_dump(exclude_unset=True).items():
        setattr(item, field, value)
    record_audit(
        db,
        organization_id=ctx.organization_id,
        actor_user_id=ctx.user.id,
        action="checklist_item.updated",
        resource_type="checklist_item",
        resource_id=str(item.id),
    )
    db.commit()
    db.refresh(item)
    return _enrich(db, [item])[0]


def list_tasks(db: Session, ctx: CurrentContext, tender_id: uuid.UUID) -> list[Task]:
    get_tender_or_404(db, ctx, tender_id)
    return list(db.execute(select(Task).where(Task.tender_id == tender_id)).scalars())


def create_task(db: Session, ctx: CurrentContext, tender_id: uuid.UUID, payload: TaskCreate) -> Task:
    get_tender_or_404(db, ctx, tender_id)
    task = Task(tender_id=tender_id, **payload.model_dump())
    db.add(task)
    record_audit(
        db,
        organization_id=ctx.organization_id,
        actor_user_id=ctx.user.id,
        action="task.created",
        resource_type="task",
        resource_id=None,
    )
    db.commit()
    db.refresh(task)
    return task


def update_task(db: Session, ctx: CurrentContext, tender_id: uuid.UUID, task_id: uuid.UUID, payload: TaskUpdate) -> Task:
    get_tender_or_404(db, ctx, tender_id)
    task = db.execute(select(Task).where(Task.id == task_id, Task.tender_id == tender_id)).scalar_one_or_none()
    if task is None:
        raise HTTPException(status.HTTP_404_NOT_FOUND, "Task not found")
    for field, value in payload.model_dump(exclude_unset=True).items():
        setattr(task, field, value)
    db.commit()
    db.refresh(task)
    return task


def delete_task(db: Session, ctx: CurrentContext, tender_id: uuid.UUID, task_id: uuid.UUID) -> None:
    get_tender_or_404(db, ctx, tender_id)
    task = db.execute(select(Task).where(Task.id == task_id, Task.tender_id == tender_id)).scalar_one_or_none()
    if task is None:
        raise HTTPException(status.HTTP_404_NOT_FOUND, "Task not found")
    db.delete(task)
    record_audit(
        db,
        organization_id=ctx.organization_id,
        actor_user_id=ctx.user.id,
        action="task.deleted",
        resource_type="task",
        resource_id=str(task.id),
    )
    db.commit()
