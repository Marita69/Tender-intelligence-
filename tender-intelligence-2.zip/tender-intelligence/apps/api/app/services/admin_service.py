import uuid
from datetime import datetime, timedelta, timezone

from fastapi import HTTPException, status
from sqlalchemy import func, select
from sqlalchemy.orm import Session

from app.models.billing import UsageCredit
from app.models.document import AnalysisJob, TenderDocument
from app.models.enums import AnalysisJobStatus, DocumentStatus
from app.models.organization import Organization, OrganizationMembership, User
from app.models.review import AuditLog
from app.models.tender import Tender
from app.schemas.admin import (
    AdminOrganizationOut,
    AdminStatsOut,
    AdminSystemLogOut,
    AdminTelemetryOut,
)
from app.services.dashboard_service import ACTIVE_STATUSES

# Coarse, keyword-based classification of audit-log actions into a log
# level for the System Logs panel — this app doesn't have a separate
# structured "severity" field on AuditLog (it's an append-only record of
# what happened, not an error log), so this is a display-layer heuristic,
# not a stored fact. Anything not matched below is "info".
_ERROR_HINTS = ("failed", "error", "rejected")
_WARNING_HINTS = ("suspended", "deleted", "corrected")


def _classify_log_level(action: str) -> str:
    lowered = action.lower()
    if any(hint in lowered for hint in _ERROR_HINTS):
        return "error"
    if any(hint in lowered for hint in _WARNING_HINTS):
        return "warning"
    return "info"


def get_platform_stats(db: Session) -> AdminStatsOut:
    organizations = db.execute(select(func.count()).select_from(Organization)).scalar_one()
    users = db.execute(select(func.count()).select_from(User)).scalar_one()
    active_tenders = db.execute(
        select(func.count()).select_from(Tender).where(Tender.deleted_at.is_(None), Tender.status.in_(ACTIVE_STATUSES))
    ).scalar_one()
    documents_processed = db.execute(
        select(func.count()).select_from(TenderDocument).where(TenderDocument.status == DocumentStatus.EXTRACTED)
    ).scalar_one()
    succeeded = db.execute(
        select(func.count()).select_from(AnalysisJob).where(AnalysisJob.status == AnalysisJobStatus.SUCCEEDED)
    ).scalar_one()
    failed = db.execute(
        select(func.count()).select_from(AnalysisJob).where(AnalysisJob.status == AnalysisJobStatus.FAILED)
    ).scalar_one()
    total_jobs = succeeded + failed
    success_rate = round((succeeded / total_jobs) * 100, 1) if total_jobs else 100.0

    return AdminStatsOut(
        organizations=organizations,
        users=users,
        active_tenders=active_tenders,
        documents_processed=documents_processed,
        analysis_jobs_succeeded=succeeded,
        analysis_jobs_failed=failed,
        extraction_success_rate_pct=success_rate,
    )


def get_telemetry(db: Session) -> AdminTelemetryOut:
    since = datetime.now(timezone.utc) - timedelta(hours=24)
    jobs = list(db.execute(select(AnalysisJob).where(AnalysisJob.created_at >= since)).scalars())

    tokens = sum((j.token_usage or {}).get("input_tokens", 0) + (j.token_usage or {}).get("output_tokens", 0) for j in jobs)

    durations = []
    for job in jobs:
        started = None
        finished = None
        for entry in job.step_log or []:
            if entry.get("started_at") and started is None:
                started = entry["started_at"]
            if entry.get("finished_at"):
                finished = entry["finished_at"]
        if started and finished:
            try:
                delta = datetime.fromisoformat(finished) - datetime.fromisoformat(started)
                durations.append(delta.total_seconds())
            except ValueError:
                continue
    avg_seconds = round(sum(durations) / len(durations), 2) if durations else None

    return AdminTelemetryOut(jobs_last_24h=len(jobs), tokens_last_24h=tokens, avg_pipeline_seconds=avg_seconds)


def list_organizations(db: Session, *, page: int, page_size: int) -> tuple[list[AdminOrganizationOut], int]:
    total = db.execute(select(func.count()).select_from(Organization)).scalar_one()
    orgs = list(
        db.execute(
            select(Organization).order_by(Organization.created_at.desc()).offset((page - 1) * page_size).limit(page_size)
        ).scalars()
    )

    out: list[AdminOrganizationOut] = []
    for org in orgs:
        member_count = db.execute(
            select(func.count()).select_from(OrganizationMembership).where(OrganizationMembership.organization_id == org.id)
        ).scalar_one()
        tender_count = db.execute(
            select(func.count()).select_from(Tender).where(Tender.organization_id == org.id, Tender.deleted_at.is_(None))
        ).scalar_one()
        credit_balance = db.execute(
            select(func.coalesce(func.sum(UsageCredit.delta), 0)).where(UsageCredit.organization_id == org.id)
        ).scalar_one()
        last_activity = db.execute(
            select(func.max(AuditLog.created_at)).where(AuditLog.organization_id == org.id)
        ).scalar_one()

        out.append(
            AdminOrganizationOut(
                id=org.id,
                name=org.name,
                slug=org.slug,
                plan=org.plan,
                is_suspended=org.is_suspended,
                member_count=member_count,
                tender_count=tender_count,
                credit_balance=int(credit_balance),
                created_at=org.created_at,
                last_activity_at=last_activity,
            )
        )
    return out, total


def set_organization_suspended(db: Session, organization_id: uuid.UUID, is_suspended: bool) -> Organization:
    org = db.get(Organization, organization_id)
    if org is None:
        raise HTTPException(status.HTTP_404_NOT_FOUND, "Organization not found")
    org.is_suspended = is_suspended
    db.commit()
    db.refresh(org)
    return org


def get_system_logs(db: Session, *, limit: int = 50) -> list[AdminSystemLogOut]:
    rows = list(db.execute(select(AuditLog).order_by(AuditLog.created_at.desc()).limit(limit)).scalars())
    return [
        AdminSystemLogOut(
            id=row.id,
            level=_classify_log_level(row.action),
            action=row.action,
            resource_type=row.resource_type,
            resource_id=row.resource_id,
            organization_id=row.organization_id,
            created_at=row.created_at,
        )
        for row in rows
    ]
