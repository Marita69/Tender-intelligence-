import uuid

from fastapi import HTTPException, status
from sqlalchemy import select
from sqlalchemy.orm import Session

from app.ai.provider import get_ai_provider
from app.core.config import settings
from app.models.ai_settings import AIProviderSetting
from app.schemas.ai_settings import AIProviderSettingOut, AIProviderSettingUpdate, AIProviderTestResult

VALID_PROVIDERS = {"anthropic", "openrouter", "nvidia", "gemini", "deepseek", "mock"}


def get_active_setting(db: Session) -> AIProviderSettingOut:
    row = db.execute(select(AIProviderSetting).order_by(AIProviderSetting.updated_at.desc())).scalars().first()
    if row is not None:
        return AIProviderSettingOut(provider=row.provider, model=row.model, is_override_active=True, updated_at=row.updated_at)
    return AIProviderSettingOut(
        provider=settings.AI_PROVIDER,
        model=_default_model_for(settings.AI_PROVIDER),
        is_override_active=False,
        updated_at=None,
    )


def _default_model_for(provider: str) -> str:
    return {
        "anthropic": settings.AI_MODEL,
        "openrouter": settings.OPENROUTER_MODEL,
        "nvidia": settings.NVIDIA_MODEL,
        "gemini": settings.GEMINI_MODEL,
        "deepseek": settings.DEEPSEEK_MODEL,
        "mock": "mock-v1",
    }.get(provider, "")


def update_setting(db: Session, admin_user_id: uuid.UUID, payload: AIProviderSettingUpdate) -> AIProviderSettingOut:
    if payload.provider not in VALID_PROVIDERS:
        raise HTTPException(status.HTTP_400_BAD_REQUEST, f"Unknown provider '{payload.provider}'")
    if not payload.model.strip():
        raise HTTPException(status.HTTP_400_BAD_REQUEST, "Model name cannot be empty")

    row = AIProviderSetting(provider=payload.provider, model=payload.model.strip(), updated_by_user_id=admin_user_id)
    db.add(row)
    db.commit()
    db.refresh(row)
    return AIProviderSettingOut(provider=row.provider, model=row.model, is_override_active=True, updated_at=row.updated_at)


async def test_connection(db: Session) -> AIProviderTestResult:
    """
    Sends one tiny real request through the currently-active provider
    (whatever get_ai_provider(db) resolves to) so an admin can confirm a
    newly entered API key/model actually works before relying on it for a
    real (credit-consuming) tender analysis.
    """
    try:
        provider = get_ai_provider(db)
    except ValueError as exc:
        # e.g. the selected provider has no API key configured
        return AIProviderTestResult(success=False, message=str(exc))

    try:
        result = await provider.generate(
            "Reply with exactly one short sentence confirming you received this test message.",
            max_tokens=60,
        )
        return AIProviderTestResult(success=True, message="Connected successfully.", sample_output=result.text.strip())
    except Exception as exc:  # noqa: BLE001 — surfacing the raw provider error is the whole point of a test-connection endpoint
        return AIProviderTestResult(success=False, message=f"Request failed: {exc}")
