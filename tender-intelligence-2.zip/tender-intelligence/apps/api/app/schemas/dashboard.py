import uuid
from datetime import datetime

from pydantic import BaseModel

from app.models.enums import BidRecommendation, TaskStatus, TenderStatus


class DashboardStats(BaseModel):
    active_tenders: int
    new_this_week: int
    deadlines_this_week: int
    critical_blockers: int


class PipelineTenderOut(BaseModel):
    id: uuid.UUID
    title: str
    reference_number: str | None
    issuing_entity: str | None
    submission_deadline: datetime | None
    bid_score: float | None
    bid_recommendation: BidRecommendation | None
    status: TenderStatus


class UrgentTaskOut(BaseModel):
    id: uuid.UUID
    tender_id: uuid.UUID
    tender_title: str
    title: str
    due_at: datetime | None
    assigned_to_user_id: uuid.UUID | None
    assigned_to_name: str | None
    status: TaskStatus


class DashboardOverview(BaseModel):
    stats: DashboardStats
    pipeline: list[PipelineTenderOut]
    urgent_tasks: list[UrgentTaskOut]
