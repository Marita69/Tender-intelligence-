import uuid
from datetime import datetime

from pydantic import BaseModel

from app.models.enums import (
    AnalysisJobStatus,
    BidRecommendation,
    ConfidenceLevel,
    RequirementType,
    RiskSeverity,
)


class EvidenceOut(BaseModel):
    id: uuid.UUID
    document_id: uuid.UUID
    page_number: int
    quoted_text: str

    model_config = {"from_attributes": True}


class RequirementOut(BaseModel):
    id: uuid.UUID
    type: RequirementType
    summary: str
    detail: str | None
    structured_value: dict
    confidence: ConfidenceLevel
    is_inferred: bool
    is_unknown: bool
    deadline_at: datetime | None
    deadline_timezone: str | None
    has_conflict: bool
    conflict_notes: str | None
    references_missing_document: bool
    referenced_document_name: str | None
    evidence: list[EvidenceOut]

    model_config = {"from_attributes": True}


class RiskOut(BaseModel):
    id: uuid.UUID
    title: str
    description: str
    severity: RiskSeverity
    is_disqualifying: bool

    model_config = {"from_attributes": True}


class BidAssessmentOut(BaseModel):
    id: uuid.UUID
    recommendation: BidRecommendation
    score: float
    confidence: ConfidenceLevel
    rationale: str
    score_breakdown: dict
    disqualifying_factors: list

    model_config = {"from_attributes": True}


class AnalysisJobOut(BaseModel):
    id: uuid.UUID
    status: AnalysisJobStatus
    ai_provider: str
    ai_model: str
    prompt_version: str
    error_message: str | None
    created_at: datetime

    model_config = {"from_attributes": True}


class TenderAnalysisOut(BaseModel):
    """Full analysis payload for the Tender Overview screen."""

    job: AnalysisJobOut
    requirements: list[RequirementOut]
    risks: list[RiskOut]
    bid_assessment: BidAssessmentOut | None


class FieldCorrectionCreate(BaseModel):
    field_name: str
    corrected_value: str
    reason: str | None = None
