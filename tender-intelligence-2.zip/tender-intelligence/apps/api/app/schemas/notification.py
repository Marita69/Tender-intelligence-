import uuid
from datetime import datetime

from pydantic import BaseModel

from app.models.notification import NotificationType


class NotificationOut(BaseModel):
    id: uuid.UUID
    type: NotificationType
    title: str
    body: str | None
    tender_id: uuid.UUID | None
    is_read: bool
    created_at: datetime

    model_config = {"from_attributes": True}


class NotificationPreferenceOut(BaseModel):
    email_digest: bool
    in_app_alerts: bool
    alert_critical_deadlines: bool
    alert_compliance: bool
    alert_analysis_complete: bool
    alert_team_activity: bool

    model_config = {"from_attributes": True}


class NotificationPreferenceUpdate(BaseModel):
    email_digest: bool | None = None
    in_app_alerts: bool | None = None
    alert_critical_deadlines: bool | None = None
    alert_compliance: bool | None = None
    alert_analysis_complete: bool | None = None
    alert_team_activity: bool | None = None
