from datetime import datetime

from pydantic import BaseModel


class AIProviderSettingOut(BaseModel):
    provider: str
    model: str
    is_override_active: bool  # False means this is just the env-var default, no admin override saved yet
    updated_at: datetime | None


class AIProviderSettingUpdate(BaseModel):
    provider: str  # "anthropic" | "openrouter" | "nvidia" | "mock"
    model: str


class AIProviderTestResult(BaseModel):
    success: bool
    message: str
    sample_output: str | None = None
