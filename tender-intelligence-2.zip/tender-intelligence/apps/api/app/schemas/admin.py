import uuid
from datetime import datetime

from pydantic import BaseModel


class AdminStatsOut(BaseModel):
    organizations: int
    users: int
    active_tenders: int
    documents_processed: int
    analysis_jobs_succeeded: int
    analysis_jobs_failed: int
    extraction_success_rate_pct: float


class AdminTelemetryOut(BaseModel):
    jobs_last_24h: int
    tokens_last_24h: int
    avg_pipeline_seconds: float | None


class AdminOrganizationOut(BaseModel):
    id: uuid.UUID
    name: str
    slug: str
    plan: str
    is_suspended: bool
    member_count: int
    tender_count: int
    credit_balance: int
    created_at: datetime
    last_activity_at: datetime | None


class AdminOrganizationListResponse(BaseModel):
    items: list[AdminOrganizationOut]
    total: int
    page: int
    page_size: int


class AdminSystemLogOut(BaseModel):
    id: uuid.UUID
    level: str  # "info" | "warning" | "error" — derived from the action name, see admin_service.py
    action: str
    resource_type: str
    resource_id: str | None
    organization_id: uuid.UUID | None
    created_at: datetime


class OrganizationSuspendRequest(BaseModel):
    is_suspended: bool
