import uuid
from datetime import datetime

from pydantic import BaseModel, Field

from app.models.enums import DocumentStatus, TenderStatus


class TenderCreate(BaseModel):
    title: str = Field(min_length=1, max_length=500)
    reference_number: str | None = None
    issuing_entity: str | None = None


class TenderUpdate(BaseModel):
    title: str | None = None
    reference_number: str | None = None
    issuing_entity: str | None = None
    notes: str | None = None
    bid_outcome: str | None = None


class TenderOut(BaseModel):
    id: uuid.UUID
    title: str
    reference_number: str | None
    issuing_entity: str | None
    status: TenderStatus
    submission_deadline: datetime | None
    submission_deadline_timezone: str | None
    submission_deadline_is_uncertain: bool
    bid_outcome: str | None
    created_at: datetime
    updated_at: datetime

    model_config = {"from_attributes": True}


class TenderDocumentOut(BaseModel):
    id: uuid.UUID
    tender_id: uuid.UUID
    original_filename: str
    content_type: str
    size_bytes: int
    document_kind: str
    status: DocumentStatus
    status_reason: str | None
    page_count: int | None
    has_text_layer: bool | None
    ocr_used: bool
    created_at: datetime

    model_config = {"from_attributes": True}


class TenderListResponse(BaseModel):
    items: list[TenderOut]
    total: int
    page: int
    page_size: int
