import uuid
from datetime import datetime

from pydantic import BaseModel

from app.models.enums import ChecklistItemStatus, ConfidenceLevel, TaskPriority, TaskStatus


class ChecklistItemOut(BaseModel):
    id: uuid.UUID
    label: str
    status: ChecklistItemStatus
    linked_document_id: uuid.UUID | None
    notes: str | None
    # Enriched from the linked Requirement (spec: Compliance Matrix needs
    # mandatory/confidence/evidence, not just a status) — populated by
    # checklist_service.list_checklist via a join, not stored redundantly.
    requirement_type: str | None = None
    confidence: ConfidenceLevel | None = None
    evidence_document_id: uuid.UUID | None = None
    evidence_page_number: int | None = None
    evidence_quote: str | None = None

    model_config = {"from_attributes": True}


class ChecklistItemUpdate(BaseModel):
    status: ChecklistItemStatus | None = None
    linked_document_id: uuid.UUID | None = None
    notes: str | None = None


class TaskCreate(BaseModel):
    title: str
    description: str | None = None
    due_at: datetime | None = None
    assigned_to_user_id: uuid.UUID | None = None
    checklist_item_id: uuid.UUID | None = None
    priority: TaskPriority = TaskPriority.MEDIUM


class TaskUpdate(BaseModel):
    title: str | None = None
    description: str | None = None
    status: TaskStatus | None = None
    priority: TaskPriority | None = None
    due_at: datetime | None = None
    assigned_to_user_id: uuid.UUID | None = None


class TaskOut(BaseModel):
    id: uuid.UUID
    title: str
    description: str | None
    status: TaskStatus
    priority: TaskPriority
    due_at: datetime | None
    assigned_to_user_id: uuid.UUID | None

    model_config = {"from_attributes": True}


class CompanyProfileIn(BaseModel):
    legal_name: str
    registration_number: str | None = None
    years_in_operation: int | None = None
    sectors: list[str] = []
    certifications: list[str] = []
    annual_turnover_band: str | None = None
    financial_capacity_notes: str | None = None


class CompanyProfileOut(CompanyProfileIn):
    id: uuid.UUID
    model_config = {"from_attributes": True}
