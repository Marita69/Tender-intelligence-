import uuid
from datetime import datetime

from pydantic import BaseModel

from app.models.enums import ReviewStatus


class ReviewItemOut(BaseModel):
    id: uuid.UUID
    tender_id: uuid.UUID
    requirement_id: uuid.UUID | None
    reason: str
    status: ReviewStatus
    reviewed_by_user_id: uuid.UUID | None
    reviewed_at: datetime | None
    created_at: datetime

    model_config = {"from_attributes": True}


class ReviewItemWithRequirement(ReviewItemOut):
    requirement_summary: str | None = None
    requirement_type: str | None = None


class ReviewItemUpdate(BaseModel):
    status: ReviewStatus
