import uuid
from datetime import date, datetime

from pydantic import BaseModel

from app.models.enums import CompanyDocumentStatus


class CompanyDocumentOut(BaseModel):
    id: uuid.UUID
    name: str
    category: str
    issuing_body: str | None
    original_filename: str
    content_type: str
    size_bytes: int
    expiry_date: date | None
    status: CompanyDocumentStatus
    ai_confidence: float | None
    created_at: datetime

    model_config = {"from_attributes": True}


class CompanyDocumentUpdate(BaseModel):
    name: str | None = None
    category: str | None = None
    issuing_body: str | None = None
    expiry_date: date | None = None
