import uuid

from sqlalchemy.orm import Session

from app.models.review import AuditLog


def record_audit(
    db: Session,
    *,
    organization_id: uuid.UUID | None,
    actor_user_id: uuid.UUID | None,
    action: str,
    resource_type: str,
    resource_id: str | None = None,
    metadata: dict | None = None,
    ip_address: str | None = None,
) -> None:
    """
    Spec §117.J: critical user actions must be auditable. Call this for
    every action listed in docs/architecture/audit-events.md (auth, org,
    document, tender-decision, billing, admin actions). Does not commit —
    caller's existing transaction commits it alongside the primary change.
    `organization_id=None` is valid for genuinely platform-wide actions
    (e.g. changing the global AI provider setting) that aren't scoped to
    any single organization — don't pass a user id or other unrelated id
    in its place.
    """
    db.add(
        AuditLog(
            organization_id=organization_id,
            actor_user_id=actor_user_id,
            action=action,
            resource_type=resource_type,
            resource_id=resource_id,
            metadata_json=metadata or {},
            ip_address=ip_address,
        )
    )
