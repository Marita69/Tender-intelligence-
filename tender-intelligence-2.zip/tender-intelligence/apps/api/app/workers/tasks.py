import uuid

from app.core.logging import get_logger
from app.db.session import SessionLocal
from app.workers.celery_app import celery_app

logger = get_logger(__name__)


@celery_app.task(name="run_tender_analysis", bind=True, max_retries=2)
def run_tender_analysis_task(self, tender_id: str) -> str:
    """
    Runs the full extraction + AI analysis pipeline for one tender. Retried
    up to twice on unexpected infra errors (DB connection, etc); a failure
    inside the pipeline itself is caught and recorded on the AnalysisJob
    row instead of raising (spec §117.G — failed processing must be
    recoverable, not just retried blindly).
    """
    from app.services.ai_analysis_service import run_tender_analysis

    db = SessionLocal()
    try:
        job = run_tender_analysis(db, uuid.UUID(tender_id))
        return str(job.id)
    except Exception as exc:  # noqa: BLE001 — infra-level failure, not a pipeline-logic failure
        logger.error("run_tender_analysis_task_infra_error", tender_id=tender_id, error=str(exc))
        raise self.retry(exc=exc)
    finally:
        db.close()


@celery_app.task(name="purge_expired_documents")
def purge_expired_documents_task() -> int:
    """
    Retention worker (spec §106 Data Lifecycle). Runs on a schedule (see
    infra/celery-beat schedule in docker-compose.yml) and hard-deletes
    object storage bytes + DB rows for tenders/documents whose deleted_at
    is older than the retention window. Retention window is a product
    decision — wire the real policy before production launch.
    """
    from datetime import datetime, timedelta, timezone

    from sqlalchemy import select

    from app.documents.storage import get_storage
    from app.models.document import TenderDocument

    RETENTION_DAYS = 30
    cutoff = datetime.now(timezone.utc) - timedelta(days=RETENTION_DAYS)

    db = SessionLocal()
    storage = get_storage()
    purged = 0
    try:
        docs = db.execute(
            select(TenderDocument).where(TenderDocument.deleted_at.isnot(None), TenderDocument.deleted_at < cutoff)
        ).scalars()
        for doc in docs:
            try:
                storage.delete(doc.storage_key)
            except FileNotFoundError:
                pass
            db.delete(doc)
            purged += 1
        db.commit()
    finally:
        db.close()
    return purged


@celery_app.task(name="check_upcoming_deadlines")
def check_upcoming_deadlines_task() -> int:
    """
    Spec: Notification Center "Critical Deadline" alerts. Runs daily (see
    beat_schedule in celery_app.py) and notifies each tender's creator
    once per deadline crossing into the 72-hour window — guarded by
    `_deadline_notification_key` so re-running this task doesn't spam a
    fresh notification every day the tender remains inside that window.
    """
    from datetime import datetime, timedelta, timezone

    from sqlalchemy import select

    from app.models.notification import NotificationType as _NT
    from app.models.enums import TenderStatus
    from app.models.notification import Notification
    from app.models.tender import Tender
    from app.services import notification_service

    WINDOW_HOURS = 72
    now = datetime.now(timezone.utc)
    window_end = now + timedelta(hours=WINDOW_HOURS)

    db = SessionLocal()
    notified = 0
    try:
        tenders = db.execute(
            select(Tender).where(
                Tender.deleted_at.is_(None),
                Tender.submission_deadline.isnot(None),
                Tender.submission_deadline >= now,
                Tender.submission_deadline <= window_end,
                Tender.status != TenderStatus.ARCHIVED,
            )
        ).scalars()
        for tender in tenders:
            dedup_title = f"Submission deadline approaching: {tender.title}"
            already_sent = db.execute(
                select(Notification).where(
                    Notification.tender_id == tender.id,
                    Notification.type == _NT.DEADLINE,
                    Notification.title == dedup_title,
                )
            ).scalar_one_or_none()
            if already_sent is not None:
                continue
            hours_left = round((tender.submission_deadline - now).total_seconds() / 3600)
            notification_service.create_notification(
                db,
                organization_id=tender.organization_id,
                user_id=tender.created_by_user_id,
                type=_NT.DEADLINE,
                title=dedup_title,
                body=f"Submission closes in approximately {hours_left} hours.",
                tender_id=tender.id,
            )
            notified += 1
        db.commit()
    finally:
        db.close()
    return notified


@celery_app.task(name="check_expiring_company_documents")
def check_expiring_company_documents_task() -> int:
    """
    Spec: Notification Center "Document Expiry" alerts. Org-wide
    notification (user_id=None) since a reusable compliance document
    (e.g. an ISO certificate) affects every tender in the organization,
    not just whoever uploaded it originally.
    """
    from datetime import date, timedelta

    from sqlalchemy import select

    from app.models.company_document import CompanyDocument
    from app.models.notification import NotificationType as _NT
    from app.models.notification import Notification
    from app.services import notification_service

    WINDOW_DAYS = 30
    today = date.today()
    window_end = today + timedelta(days=WINDOW_DAYS)

    db = SessionLocal()
    notified = 0
    try:
        docs = db.execute(
            select(CompanyDocument).where(
                CompanyDocument.deleted_at.is_(None),
                CompanyDocument.expiry_date.isnot(None),
                CompanyDocument.expiry_date <= window_end,
            )
        ).scalars()
        for doc in docs:
            dedup_title = f"Document expiring soon: {doc.name}"
            already_sent = db.execute(
                select(Notification).where(
                    Notification.organization_id == doc.organization_id,
                    Notification.type == _NT.DOCUMENT_EXPIRY,
                    Notification.title == dedup_title,
                )
            ).scalar_one_or_none()
            if already_sent is not None:
                continue
            status_word = "has expired" if doc.expiry_date < today else "expires soon"
            notification_service.create_notification(
                db,
                organization_id=doc.organization_id,
                user_id=None,  # org-wide: shared compliance evidence affects every tender
                type=_NT.DOCUMENT_EXPIRY,
                title=dedup_title,
                body=f"{doc.name} {status_word} ({doc.expiry_date.isoformat()}).",
            )
            notified += 1
        db.commit()
    finally:
        db.close()
    return notified
