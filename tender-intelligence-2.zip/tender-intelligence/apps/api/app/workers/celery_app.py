"""
Celery app instance. Heavy operations (extraction, OCR, AI analysis, report
generation, large exports) must never block the HTTP request thread per
spec §4.3 — routes enqueue a task here and return 202 immediately with a
job id the frontend polls.

Run the worker with:
    celery -A app.workers.celery_app worker --loglevel=info

CELERY_TASK_ALWAYS_EAGER=true (in .env) makes tasks run inline in the same
process, useful for local dev without Redis running — see .env.example.
"""
from celery import Celery

from app.core.config import settings

celery_app = Celery(
    "tender_intelligence",
    broker=settings.REDIS_URL,
    backend=settings.REDIS_URL,
    include=["app.workers.tasks"],
)

celery_app.conf.update(
    task_always_eager=settings.CELERY_TASK_ALWAYS_EAGER,
    task_eager_propagates=True,
    task_track_started=True,
    task_acks_late=True,
    worker_prefetch_multiplier=1,
    task_default_retry_delay=10,
    result_expires=60 * 60 * 24,
    beat_schedule={
        "purge-expired-documents-daily": {
            "task": "purge_expired_documents",
            "schedule": 60 * 60 * 24,  # once a day; tune via env/config once retention policy is finalized
        },
        "check-upcoming-deadlines-hourly": {
            "task": "check_upcoming_deadlines",
            "schedule": 60 * 60,  # hourly is frequent enough for a 72h window without being noisy
        },
        "check-expiring-company-documents-daily": {
            "task": "check_expiring_company_documents",
            "schedule": 60 * 60 * 24,
        },
    },
)
