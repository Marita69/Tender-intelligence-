from fastapi import APIRouter, Depends
from sqlalchemy import text
from sqlalchemy.orm import Session

from app.db.session import get_db

router = APIRouter(tags=["health"])


@router.get("/health")
def health():
    """Liveness probe — does not touch the DB, always fast."""
    return {"status": "ok"}


@router.get("/health/ready")
def readiness(db: Session = Depends(get_db)):
    """Readiness probe — confirms the DB is actually reachable. Point your
    orchestrator's readiness check (k8s, ECS, etc.) here, not at /health."""
    db.execute(text("SELECT 1"))
    return {"status": "ready"}
