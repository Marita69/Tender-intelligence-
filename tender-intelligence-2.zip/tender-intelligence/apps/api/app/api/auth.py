from fastapi import APIRouter, Depends, Request
from sqlalchemy import select
from sqlalchemy.orm import Session

from app.core.rate_limit import limiter
from app.db.session import get_db
from app.models.organization import OrganizationMembership
from app.schemas.auth import (
    ChangePasswordRequest,
    LoginRequest,
    MeResponse,
    RefreshRequest,
    SignupRequest,
    TokenResponse,
    UserOut,
    UserUpdate,
)
from app.security.tenancy import get_current_user
from app.services import auth_service

router = APIRouter(prefix="/api/v1/auth", tags=["auth"])


@router.post("/signup", response_model=TokenResponse, status_code=201)
@limiter.limit("5/hour")
def signup(request: Request, payload: SignupRequest, db: Session = Depends(get_db)):
    _, _, tokens = auth_service.signup(db, payload)
    return tokens


@router.post("/login", response_model=TokenResponse)
@limiter.limit("10/minute")
def login(request: Request, payload: LoginRequest, db: Session = Depends(get_db)):
    _, tokens = auth_service.login(db, payload)
    return tokens


@router.post("/refresh", response_model=TokenResponse)
@limiter.limit("30/minute")
def refresh(request: Request, payload: RefreshRequest, db: Session = Depends(get_db)):
    return auth_service.refresh(db, payload.refresh_token)


@router.get("/me", response_model=list[MeResponse])
def me(user=Depends(get_current_user), db: Session = Depends(get_db)):
    """Returns every organization membership for the logged-in user, so the
    frontend can present a workspace switcher (spec: consultants have
    multiple client organizations)."""
    memberships = db.execute(
        select(OrganizationMembership).where(OrganizationMembership.user_id == user.id)
    ).scalars()
    return [
        MeResponse(
            user=UserOut.model_validate(user),
            organization_id=m.organization_id,
            organization_name=m.organization.name,
            role=m.role.value,
        )
        for m in memberships
    ]


@router.patch("/me", response_model=UserOut)
def update_me(payload: UserUpdate, user=Depends(get_current_user), db: Session = Depends(get_db)):
    updated = auth_service.update_profile(db, user, payload)
    return UserOut.model_validate(updated)


@router.post("/me/change-password", status_code=204)
def change_password(payload: ChangePasswordRequest, user=Depends(get_current_user), db: Session = Depends(get_db)):
    auth_service.change_password(db, user, payload.current_password, payload.new_password)
