from fastapi import APIRouter, Depends
from sqlalchemy.orm import Session

from app.db.session import get_db
from app.schemas.dashboard import DashboardOverview
from app.security.tenancy import CurrentContext, current_membership
from app.services import dashboard_service

router = APIRouter(prefix="/api/v1/dashboard", tags=["dashboard"])


@router.get("/overview", response_model=DashboardOverview)
def get_overview(ctx: CurrentContext = Depends(current_membership), db: Session = Depends(get_db)):
    return dashboard_service.get_overview(db, ctx)
