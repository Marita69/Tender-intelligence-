import uuid

from fastapi import APIRouter, Depends, HTTPException, Query, Request, status
from sqlalchemy.orm import Session

from app.core.config import settings
from app.core.logging import get_logger
from app.db.session import get_db
from app.models.organization import User
from app.schemas.admin import (
    AdminOrganizationListResponse,
    AdminOrganizationOut,
    AdminStatsOut,
    AdminSystemLogOut,
    AdminTelemetryOut,
    OrganizationSuspendRequest,
)
from app.schemas.ai_settings import AIProviderSettingOut, AIProviderSettingUpdate, AIProviderTestResult
from app.security.tenancy import require_platform_admin
from app.services import admin_service, ai_settings_service, billing_service

logger = get_logger(__name__)

router = APIRouter(prefix="/api/v1/admin", tags=["admin"])


@router.get("/stats", response_model=AdminStatsOut)
def platform_stats(db: Session = Depends(get_db), _admin: User = Depends(require_platform_admin)):
    return admin_service.get_platform_stats(db)


@router.get("/telemetry", response_model=AdminTelemetryOut)
def telemetry(db: Session = Depends(get_db), _admin: User = Depends(require_platform_admin)):
    """
    24h processing telemetry (job count, token usage, avg pipeline
    duration). Deliberately does not include a cost estimate — that would
    need a real per-model pricing table kept in sync with the provider's
    published rates, which is easy to get quietly wrong; see PAGES.md for
    why that's scoped out rather than shipped as a guess.
    """
    return admin_service.get_telemetry(db)


@router.get("/organizations", response_model=AdminOrganizationListResponse)
def list_organizations(
    page: int = Query(1, ge=1),
    page_size: int = Query(20, ge=1, le=100),
    db: Session = Depends(get_db),
    _admin: User = Depends(require_platform_admin),
):
    items, total = admin_service.list_organizations(db, page=page, page_size=page_size)
    return AdminOrganizationListResponse(items=items, total=total, page=page, page_size=page_size)


@router.post("/organizations/{organization_id}/suspend", response_model=AdminOrganizationOut)
def suspend_organization(
    organization_id: uuid.UUID,
    payload: OrganizationSuspendRequest,
    db: Session = Depends(get_db),
    admin: User = Depends(require_platform_admin),
):
    """
    Suspending locks out every member of that org from every org-scoped
    route (enforced in app/security/tenancy.py's current_membership
    dependency) — not just a cosmetic flag. Use with intent.
    """
    org = admin_service.set_organization_suspended(db, organization_id, payload.is_suspended)
    from app.utils.audit import record_audit

    record_audit(
        db,
        organization_id=org.id,
        actor_user_id=admin.id,
        action="organization.suspended" if payload.is_suspended else "organization.unsuspended",
        resource_type="organization",
        resource_id=str(org.id),
    )
    db.commit()
    # Re-fetch enriched (member/tender counts, credit balance) rather than
    # returning the bare ORM object.
    all_items, _ = admin_service.list_organizations(db, page=1, page_size=1000)
    match = next((o for o in all_items if o.id == org.id), None)
    if match is None:
        raise HTTPException(status.HTTP_404_NOT_FOUND, "Organization not found")
    return match


@router.get("/system-logs", response_model=list[AdminSystemLogOut])
def system_logs(
    limit: int = Query(50, ge=1, le=200),
    db: Session = Depends(get_db),
    _admin: User = Depends(require_platform_admin),
):
    return admin_service.get_system_logs(db, limit=limit)


@router.post("/billing/webhook")
async def billing_webhook(request: Request, db: Session = Depends(get_db)):
    """
    Stripe webhook receiver with real signature verification. This
    previously accepted any POST body as a trusted event — that was a
    documented gap (PRODUCTION_GUIDE.md Part 5) and is now closed: the raw
    request body is verified against STRIPE_WEBHOOK_SECRET using Stripe's
    own signature scheme before anything in the payload is trusted.
    Idempotency (Part 5 point 4 in the guide) is still enforced separately
    via billing_service.record_webhook_event.
    """
    if settings.BILLING_PROVIDER != "stripe":
        raise HTTPException(status.HTTP_404_NOT_FOUND, "Billing is not enabled")

    raw_body = await request.body()
    signature = request.headers.get("stripe-signature")
    if not signature:
        raise HTTPException(status.HTTP_400_BAD_REQUEST, "Missing Stripe-Signature header")

    try:
        import stripe

        event = stripe.Webhook.construct_event(raw_body, signature, settings.STRIPE_WEBHOOK_SECRET)
    except ValueError as exc:
        logger.warning("billing_webhook_invalid_payload", error=str(exc))
        raise HTTPException(status.HTTP_400_BAD_REQUEST, "Invalid payload") from exc
    except Exception as exc:  # stripe.error.SignatureVerificationError, and any lib-specific error
        logger.warning("billing_webhook_signature_verification_failed", error=str(exc))
        raise HTTPException(status.HTTP_400_BAD_REQUEST, "Signature verification failed") from exc

    event_id = event["id"]
    event_type = event["type"]
    payload = event.to_dict() if hasattr(event, "to_dict") else dict(event)

    is_new = billing_service.record_webhook_event(
        db, provider="stripe", external_event_id=event_id, event_type=event_type, payload=payload
    )
    if not is_new:
        return {"status": "already_processed"}

    # Example handling — adapt to your actual Stripe price/credit mapping.
    if event_type == "checkout.session.completed":
        session_obj = payload.get("data", {}).get("object", {})
        org_id = session_obj.get("client_reference_id")
        credits_purchased = session_obj.get("metadata", {}).get("credits", 0)
        if org_id and credits_purchased:
            import uuid as _uuid

            billing_service.grant_credits(db, _uuid.UUID(org_id), int(credits_purchased), event_id)

    return {"status": "processed"}


@router.get("/ai-provider", response_model=AIProviderSettingOut)
def get_ai_provider_setting(db: Session = Depends(get_db), _admin: User = Depends(require_platform_admin)):
    return ai_settings_service.get_active_setting(db)


@router.put("/ai-provider", response_model=AIProviderSettingOut)
def update_ai_provider_setting(
    payload: AIProviderSettingUpdate,
    db: Session = Depends(get_db),
    admin: User = Depends(require_platform_admin),
):
    """
    Takes effect on the NEXT analysis run — there is no long-lived
    provider client held in memory between requests, `get_ai_provider(db)`
    re-reads this table every time run_tender_analysis starts, so no
    restart is needed.
    """
    updated = ai_settings_service.update_setting(db, admin.id, payload)
    from app.utils.audit import record_audit

    record_audit(
        db,
        organization_id=None,  # platform-wide action, not tied to any single organization
        actor_user_id=admin.id,
        action="ai_provider.updated",
        resource_type="ai_provider_setting",
        resource_id=None,
        metadata={"provider": payload.provider, "model": payload.model},
    )
    db.commit()
    return updated


@router.post("/ai-provider/test", response_model=AIProviderTestResult)
async def test_ai_provider(db: Session = Depends(get_db), _admin: User = Depends(require_platform_admin)):
    return await ai_settings_service.test_connection(db)
