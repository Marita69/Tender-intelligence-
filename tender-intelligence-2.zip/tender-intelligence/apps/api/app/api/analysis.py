import uuid

from fastapi import APIRouter, Depends, HTTPException, status
from sqlalchemy import select
from sqlalchemy.orm import Session

from app.db.session import get_db
from app.models.analysis import BidAssessment, Requirement, Risk
from app.models.document import AnalysisJob
from app.models.review import FieldCorrection, ReviewItem
from app.schemas.analysis import (
    AnalysisJobOut,
    BidAssessmentOut,
    FieldCorrectionCreate,
    RequirementOut,
    RiskOut,
    TenderAnalysisOut,
)
from app.security.tenancy import CurrentContext, current_membership
from app.services import billing_service, tender_service
from app.utils.audit import record_audit

router = APIRouter(prefix="/api/v1/tenders/{tender_id}/analysis", tags=["analysis"])


@router.post("/run", response_model=AnalysisJobOut, status_code=202)
def trigger_analysis(
    tender_id: uuid.UUID, ctx: CurrentContext = Depends(current_membership), db: Session = Depends(get_db)
):
    """
    Enqueues the analysis pipeline (spec §4.3: heavy operations must not
    block the HTTP request). Returns immediately with a job in "pending"
    state; the frontend polls GET /analysis/jobs/{job_id} or the tender's
    status field.
    """
    tender_service.get_tender_or_404(db, ctx, tender_id)  # 404s + enforces tenant scope

    if not billing_service.has_available_credit(db, ctx.organization_id):
        raise HTTPException(status.HTTP_402_PAYMENT_REQUIRED, "No analysis credits remaining")

    from app.workers.tasks import run_tender_analysis_task

    async_result = run_tender_analysis_task.delay(str(tender_id))
    billing_service.consume_credit(db, ctx.organization_id)
    record_audit(
        db,
        organization_id=ctx.organization_id,
        actor_user_id=ctx.user.id,
        action="analysis.triggered",
        resource_type="tender",
        resource_id=str(tender_id),
        metadata={"celery_task_id": async_result.id},
    )
    db.commit()

    # In eager/dev mode, .delay() has already run synchronously and the
    # AnalysisJob row exists; in production it's still "pending" here and
    # the client should poll.
    job = db.execute(
        select(AnalysisJob)
        .where(AnalysisJob.tender_id == tender_id)
        .order_by(AnalysisJob.created_at.desc())
    ).scalars().first()
    if job is None:
        raise HTTPException(status.HTTP_202_ACCEPTED, "Analysis queued")
    return job


@router.get("/jobs/{job_id}", response_model=AnalysisJobOut)
def get_job(
    tender_id: uuid.UUID,
    job_id: uuid.UUID,
    ctx: CurrentContext = Depends(current_membership),
    db: Session = Depends(get_db),
):
    tender_service.get_tender_or_404(db, ctx, tender_id)
    job = db.execute(
        select(AnalysisJob).where(AnalysisJob.id == job_id, AnalysisJob.tender_id == tender_id)
    ).scalar_one_or_none()
    if job is None:
        raise HTTPException(status.HTTP_404_NOT_FOUND, "Analysis job not found")
    return job


@router.get("", response_model=TenderAnalysisOut)
def get_latest_analysis(
    tender_id: uuid.UUID, ctx: CurrentContext = Depends(current_membership), db: Session = Depends(get_db)
):
    tender_service.get_tender_or_404(db, ctx, tender_id)
    job = db.execute(
        select(AnalysisJob).where(AnalysisJob.tender_id == tender_id).order_by(AnalysisJob.created_at.desc())
    ).scalars().first()
    if job is None:
        raise HTTPException(status.HTTP_404_NOT_FOUND, "No analysis has been run for this tender yet")

    requirements = list(db.execute(select(Requirement).where(Requirement.tender_id == tender_id)).scalars())
    risks = list(db.execute(select(Risk).where(Risk.tender_id == tender_id)).scalars())
    assessment = db.execute(
        select(BidAssessment).where(BidAssessment.tender_id == tender_id).order_by(BidAssessment.created_at.desc())
    ).scalars().first()

    return TenderAnalysisOut(
        job=AnalysisJobOut.model_validate(job),
        requirements=[RequirementOut.model_validate(r) for r in requirements],
        risks=[RiskOut.model_validate(r) for r in risks],
        bid_assessment=None if assessment is None else BidAssessmentOut.model_validate(assessment),
    )


@router.post("/requirements/{requirement_id}/corrections", status_code=201)
def correct_requirement(
    tender_id: uuid.UUID,
    requirement_id: uuid.UUID,
    payload: FieldCorrectionCreate,
    ctx: CurrentContext = Depends(current_membership),
    db: Session = Depends(get_db),
):
    """Spec §110: store the correction additively, never overwrite AI history."""
    tender_service.get_tender_or_404(db, ctx, tender_id)
    requirement = db.execute(
        select(Requirement).where(Requirement.id == requirement_id, Requirement.tender_id == tender_id)
    ).scalar_one_or_none()
    if requirement is None:
        raise HTTPException(status.HTTP_404_NOT_FOUND, "Requirement not found")

    original_value = str(getattr(requirement, payload.field_name, ""))
    correction = FieldCorrection(
        requirement_id=requirement.id,
        field_name=payload.field_name,
        original_value=original_value,
        corrected_value=payload.corrected_value,
        corrected_by_user_id=ctx.user.id,
        reason=payload.reason,
    )
    db.add(correction)

    if hasattr(requirement, payload.field_name):
        setattr(requirement, payload.field_name, payload.corrected_value)

    review = db.execute(select(ReviewItem).where(ReviewItem.requirement_id == requirement.id)).scalars().first()
    if review:
        from datetime import datetime, timezone

        from app.models.enums import ReviewStatus

        review.status = ReviewStatus.CORRECTED
        review.reviewed_by_user_id = ctx.user.id
        review.reviewed_at = datetime.now(timezone.utc)

    record_audit(
        db,
        organization_id=ctx.organization_id,
        actor_user_id=ctx.user.id,
        action="requirement.corrected",
        resource_type="requirement",
        resource_id=str(requirement.id),
        metadata={"field_name": payload.field_name},
    )
    db.commit()
    return {"status": "corrected"}


@router.delete("", status_code=204)
def delete_analysis(
    tender_id: uuid.UUID, ctx: CurrentContext = Depends(current_membership), db: Session = Depends(get_db)
):
    """
    Deletes every analysis result for this tender (all past runs) and
    resets it to draft — uploaded documents are untouched, so "Run
    analysis" can be clicked again immediately. See
    ai_analysis_service.reset_tender_analysis for why deletion order
    matters here.
    """
    from app.services.ai_analysis_service import reset_tender_analysis

    tender = tender_service.get_tender_or_404(db, ctx, tender_id)
    reset_tender_analysis(db, tender)
    record_audit(
        db,
        organization_id=ctx.organization_id,
        actor_user_id=ctx.user.id,
        action="analysis.reset",
        resource_type="tender",
        resource_id=str(tender_id),
    )
    db.commit()
