from fastapi import APIRouter, Depends
from sqlalchemy import select
from sqlalchemy.orm import Session

from app.db.session import get_db
from app.models.organization import OrganizationMembership, User
from app.schemas.auth import UserOut
from app.security.tenancy import CurrentContext, current_membership

router = APIRouter(prefix="/api/v1/organization", tags=["organization"])


@router.get("/members", response_model=list[UserOut])
def list_members(ctx: CurrentContext = Depends(current_membership), db: Session = Depends(get_db)):
    """Every user in the active organization — used for assignee pickers
    (tasks) and similar "who's on this team" UI, not for admin purposes."""
    rows = db.execute(
        select(User)
        .join(OrganizationMembership, OrganizationMembership.user_id == User.id)
        .where(OrganizationMembership.organization_id == ctx.organization_id)
    ).scalars()
    return [UserOut.model_validate(u) for u in rows]
