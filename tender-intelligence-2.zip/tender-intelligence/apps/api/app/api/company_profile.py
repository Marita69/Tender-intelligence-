from fastapi import APIRouter, Depends, HTTPException, status
from sqlalchemy.orm import Session

from app.db.session import get_db
from app.schemas.checklist import CompanyProfileIn, CompanyProfileOut
from app.security.tenancy import CurrentContext, current_membership
from app.services import company_profile_service

router = APIRouter(prefix="/api/v1/company-profile", tags=["company-profile"])


@router.get("", response_model=CompanyProfileOut)
def get_profile(ctx: CurrentContext = Depends(current_membership), db: Session = Depends(get_db)):
    profile = company_profile_service.get_profile(db, ctx)
    if profile is None:
        raise HTTPException(status.HTTP_404_NOT_FOUND, "Company profile not set up yet")
    return profile


@router.put("", response_model=CompanyProfileOut)
def upsert_profile(
    payload: CompanyProfileIn, ctx: CurrentContext = Depends(current_membership), db: Session = Depends(get_db)
):
    return company_profile_service.upsert_profile(db, ctx, payload)
