import uuid

from fastapi import APIRouter, Depends, File, Query, UploadFile
from fastapi.responses import StreamingResponse
from sqlalchemy.orm import Session

from app.db.session import get_db
from app.documents.storage import get_storage
from app.schemas.tender import TenderDocumentOut
from app.security.tenancy import CurrentContext, current_membership
from app.services import document_service

router = APIRouter(prefix="/api/v1/tenders/{tender_id}/documents", tags=["documents"])


@router.post("", response_model=TenderDocumentOut, status_code=201)
async def upload_document(
    tender_id: uuid.UUID,
    file: UploadFile = File(...),
    document_kind: str = Query("tender_document"),
    ctx: CurrentContext = Depends(current_membership),
    db: Session = Depends(get_db),
):
    return await document_service.upload_document(db, ctx, tender_id, file, document_kind=document_kind)


@router.get("", response_model=list[TenderDocumentOut])
def list_documents(
    tender_id: uuid.UUID, ctx: CurrentContext = Depends(current_membership), db: Session = Depends(get_db)
):
    return document_service.list_documents(db, ctx, tender_id)


@router.get("/{document_id}/download")
def download_document(
    tender_id: uuid.UUID,
    document_id: uuid.UUID,
    ctx: CurrentContext = Depends(current_membership),
    db: Session = Depends(get_db),
):
    """
    Streams the original file back. In production behind S3, prefer
    redirecting to storage.presigned_url() instead of proxying bytes
    through the API — this inline route exists so local-filesystem dev
    mode works identically without a redirect.
    """
    doc = document_service.get_document_or_404(db, ctx, document_id)
    storage = get_storage()
    data = storage.get(doc.storage_key)
    return StreamingResponse(
        iter([data]),
        media_type=doc.content_type,
        headers={"Content-Disposition": f'attachment; filename="{doc.original_filename}"'},
    )


@router.delete("/{document_id}", status_code=204)
def delete_document(
    tender_id: uuid.UUID,
    document_id: uuid.UUID,
    ctx: CurrentContext = Depends(current_membership),
    db: Session = Depends(get_db),
):
    document_service.delete_document(db, ctx, document_id)
