import uuid

from fastapi import APIRouter, Depends
from fastapi.responses import StreamingResponse
from sqlalchemy.orm import Session

from app.core.config import settings
from app.db.session import get_db
from app.security.tenancy import CurrentContext, current_membership
from app.services import report_service, tender_service
from app.utils.audit import record_audit

router = APIRouter(prefix="/api/v1/tenders/{tender_id}/reports", tags=["reports"])


@router.get("/pdf")
def export_pdf(tender_id: uuid.UUID, ctx: CurrentContext = Depends(current_membership), db: Session = Depends(get_db)):
    tender = tender_service.get_tender_or_404(db, ctx, tender_id)
    data = report_service.generate_pdf_report(db, tender_id, settings.APP_NAME)
    record_audit(
        db,
        organization_id=ctx.organization_id,
        actor_user_id=ctx.user.id,
        action="report.exported_pdf",
        resource_type="tender",
        resource_id=str(tender_id),
    )
    db.commit()
    filename = f"{tender.title[:60].replace(' ', '_')}_analysis.pdf"
    return StreamingResponse(
        iter([data]),
        media_type="application/pdf",
        headers={"Content-Disposition": f'attachment; filename="{filename}"'},
    )


@router.get("/docx")
def export_docx(tender_id: uuid.UUID, ctx: CurrentContext = Depends(current_membership), db: Session = Depends(get_db)):
    tender = tender_service.get_tender_or_404(db, ctx, tender_id)
    data = report_service.generate_docx_report(db, tender_id, settings.APP_NAME)
    record_audit(
        db,
        organization_id=ctx.organization_id,
        actor_user_id=ctx.user.id,
        action="report.exported_docx",
        resource_type="tender",
        resource_id=str(tender_id),
    )
    db.commit()
    filename = f"{tender.title[:60].replace(' ', '_')}_analysis.docx"
    return StreamingResponse(
        iter([data]),
        media_type="application/vnd.openxmlformats-officedocument.wordprocessingml.document",
        headers={"Content-Disposition": f'attachment; filename="{filename}"'},
    )
