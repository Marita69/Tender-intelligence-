import uuid

from fastapi import APIRouter, Depends
from sqlalchemy.orm import Session

from app.db.session import get_db
from app.schemas.notification import NotificationOut, NotificationPreferenceOut, NotificationPreferenceUpdate
from app.security.tenancy import CurrentContext, current_membership
from app.services import notification_service

router = APIRouter(prefix="/api/v1/notifications", tags=["notifications"])


@router.get("", response_model=list[NotificationOut])
def list_notifications(
    unread_only: bool = False, ctx: CurrentContext = Depends(current_membership), db: Session = Depends(get_db)
):
    return notification_service.list_notifications(db, ctx, unread_only=unread_only)


@router.get("/unread-count")
def get_unread_count(ctx: CurrentContext = Depends(current_membership), db: Session = Depends(get_db)):
    return {"count": notification_service.unread_count(db, ctx)}


@router.post("/{notification_id}/read", response_model=NotificationOut)
def mark_read(
    notification_id: uuid.UUID, ctx: CurrentContext = Depends(current_membership), db: Session = Depends(get_db)
):
    return notification_service.mark_read(db, ctx, notification_id)


@router.post("/mark-all-read")
def mark_all_read(ctx: CurrentContext = Depends(current_membership), db: Session = Depends(get_db)):
    count = notification_service.mark_all_read(db, ctx)
    return {"marked": count}


@router.get("/preferences", response_model=NotificationPreferenceOut)
def get_preferences(ctx: CurrentContext = Depends(current_membership), db: Session = Depends(get_db)):
    return notification_service.get_preferences(db, ctx)


@router.put("/preferences", response_model=NotificationPreferenceOut)
def update_preferences(
    payload: NotificationPreferenceUpdate,
    ctx: CurrentContext = Depends(current_membership),
    db: Session = Depends(get_db),
):
    return notification_service.update_preferences(db, ctx, payload)
