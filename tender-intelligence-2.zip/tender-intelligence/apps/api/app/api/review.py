import uuid

from fastapi import APIRouter, Depends
from sqlalchemy.orm import Session

from app.db.session import get_db
from app.models.enums import ReviewStatus
from app.schemas.review import ReviewItemOut, ReviewItemUpdate, ReviewItemWithRequirement
from app.security.tenancy import CurrentContext, current_membership
from app.services import review_service

router = APIRouter(prefix="/api/v1/review-queue", tags=["review-queue"])


def _with_requirement(review, requirement) -> ReviewItemWithRequirement:
    base = ReviewItemOut.model_validate(review).model_dump()
    return ReviewItemWithRequirement(
        **base,
        requirement_summary=requirement.summary if requirement else None,
        requirement_type=requirement.type.value if requirement else None,
    )


@router.get("", response_model=list[ReviewItemWithRequirement])
def list_review_queue(
    status_filter: ReviewStatus | None = None,
    tender_id: uuid.UUID | None = None,
    ctx: CurrentContext = Depends(current_membership),
    db: Session = Depends(get_db),
):
    rows = review_service.list_review_queue(db, ctx, status_filter=status_filter, tender_id=tender_id)
    return [_with_requirement(review, req) for review, req in rows]


@router.get("/counts")
def get_counts(ctx: CurrentContext = Depends(current_membership), db: Session = Depends(get_db)):
    return review_service.review_queue_counts(db, ctx)


@router.patch("/{review_id}", response_model=ReviewItemWithRequirement)
def update_review_item(
    review_id: uuid.UUID,
    payload: ReviewItemUpdate,
    ctx: CurrentContext = Depends(current_membership),
    db: Session = Depends(get_db),
):
    review, requirement = review_service.update_review_item(db, ctx, review_id, payload)
    return _with_requirement(review, requirement)
