import uuid

from fastapi import APIRouter, Depends
from sqlalchemy.orm import Session

from app.db.session import get_db
from app.schemas.checklist import (
    ChecklistItemOut,
    ChecklistItemUpdate,
    TaskCreate,
    TaskOut,
    TaskUpdate,
)
from app.security.tenancy import CurrentContext, current_membership
from app.services import checklist_service

router = APIRouter(prefix="/api/v1/tenders/{tender_id}", tags=["checklist", "tasks"])


@router.get("/checklist", response_model=list[ChecklistItemOut])
def list_checklist(tender_id: uuid.UUID, ctx: CurrentContext = Depends(current_membership), db: Session = Depends(get_db)):
    return checklist_service.list_checklist(db, ctx, tender_id)


@router.patch("/checklist/{item_id}", response_model=ChecklistItemOut)
def update_checklist_item(
    tender_id: uuid.UUID,
    item_id: uuid.UUID,
    payload: ChecklistItemUpdate,
    ctx: CurrentContext = Depends(current_membership),
    db: Session = Depends(get_db),
):
    return checklist_service.update_checklist_item(db, ctx, tender_id, item_id, payload)


@router.get("/tasks", response_model=list[TaskOut])
def list_tasks(tender_id: uuid.UUID, ctx: CurrentContext = Depends(current_membership), db: Session = Depends(get_db)):
    return checklist_service.list_tasks(db, ctx, tender_id)


@router.post("/tasks", response_model=TaskOut, status_code=201)
def create_task(
    tender_id: uuid.UUID,
    payload: TaskCreate,
    ctx: CurrentContext = Depends(current_membership),
    db: Session = Depends(get_db),
):
    return checklist_service.create_task(db, ctx, tender_id, payload)


@router.patch("/tasks/{task_id}", response_model=TaskOut)
def update_task(
    tender_id: uuid.UUID,
    task_id: uuid.UUID,
    payload: TaskUpdate,
    ctx: CurrentContext = Depends(current_membership),
    db: Session = Depends(get_db),
):
    return checklist_service.update_task(db, ctx, tender_id, task_id, payload)


@router.delete("/tasks/{task_id}", status_code=204)
def delete_task(
    tender_id: uuid.UUID,
    task_id: uuid.UUID,
    ctx: CurrentContext = Depends(current_membership),
    db: Session = Depends(get_db),
):
    checklist_service.delete_task(db, ctx, tender_id, task_id)
