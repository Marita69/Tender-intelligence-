import uuid

from fastapi import APIRouter, Depends, Query
from sqlalchemy.orm import Session

from app.db.session import get_db
from app.schemas.tender import TenderCreate, TenderListResponse, TenderOut, TenderUpdate
from app.security.tenancy import CurrentContext, current_membership
from app.services import tender_service

router = APIRouter(prefix="/api/v1/tenders", tags=["tenders"])


@router.post("", response_model=TenderOut, status_code=201)
def create_tender(
    payload: TenderCreate, ctx: CurrentContext = Depends(current_membership), db: Session = Depends(get_db)
):
    return tender_service.create_tender(db, ctx, payload)


@router.get("", response_model=TenderListResponse)
def list_tenders(
    search: str | None = None,
    page: int = Query(1, ge=1),
    page_size: int = Query(20, ge=1, le=100),
    ctx: CurrentContext = Depends(current_membership),
    db: Session = Depends(get_db),
):
    items, total = tender_service.list_tenders(db, ctx, search=search, page=page, page_size=page_size)
    return TenderListResponse(items=items, total=total, page=page, page_size=page_size)


@router.get("/{tender_id}", response_model=TenderOut)
def get_tender(tender_id: uuid.UUID, ctx: CurrentContext = Depends(current_membership), db: Session = Depends(get_db)):
    return tender_service.get_tender_or_404(db, ctx, tender_id)


@router.patch("/{tender_id}", response_model=TenderOut)
def update_tender(
    tender_id: uuid.UUID,
    payload: TenderUpdate,
    ctx: CurrentContext = Depends(current_membership),
    db: Session = Depends(get_db),
):
    return tender_service.update_tender(db, ctx, tender_id, payload)


@router.delete("/{tender_id}", status_code=204)
def delete_tender(
    tender_id: uuid.UUID, ctx: CurrentContext = Depends(current_membership), db: Session = Depends(get_db)
):
    tender_service.soft_delete_tender(db, ctx, tender_id)
