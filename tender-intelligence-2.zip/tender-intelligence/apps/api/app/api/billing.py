from fastapi import APIRouter, Depends, HTTPException, status
from pydantic import BaseModel
from sqlalchemy.orm import Session

from app.core.config import settings
from app.db.session import get_db
from app.security.tenancy import CurrentContext, current_membership
from app.services import billing_service

router = APIRouter(prefix="/api/v1/billing", tags=["billing"])


class CheckoutSessionRequest(BaseModel):
    success_url: str
    cancel_url: str


class CheckoutSessionResponse(BaseModel):
    checkout_url: str


class BalanceResponse(BaseModel):
    credits: int
    billing_enabled: bool


@router.get("/balance", response_model=BalanceResponse)
def get_balance(ctx: CurrentContext = Depends(current_membership), db: Session = Depends(get_db)):
    return BalanceResponse(
        credits=billing_service.get_credit_balance(db, ctx.organization_id),
        billing_enabled=settings.BILLING_PROVIDER != "none",
    )


@router.post("/checkout-session", response_model=CheckoutSessionResponse)
def create_checkout_session(
    payload: CheckoutSessionRequest,
    ctx: CurrentContext = Depends(current_membership),
    db: Session = Depends(get_db),
):
    if settings.BILLING_PROVIDER != "stripe":
        raise HTTPException(status.HTTP_400_BAD_REQUEST, "Billing is not enabled on this deployment")
    url = billing_service.create_checkout_session_url(ctx.organization_id, payload.success_url, payload.cancel_url)
    return CheckoutSessionResponse(checkout_url=url)
