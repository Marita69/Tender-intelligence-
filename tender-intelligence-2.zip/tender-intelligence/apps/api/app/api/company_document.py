import uuid
from datetime import date

from fastapi import APIRouter, Depends, File, Form, UploadFile
from fastapi.responses import StreamingResponse
from sqlalchemy.orm import Session

from app.db.session import get_db
from app.documents.storage import get_storage
from app.schemas.company_document import CompanyDocumentOut, CompanyDocumentUpdate
from app.security.tenancy import CurrentContext, current_membership
from app.services import company_document_service

router = APIRouter(prefix="/api/v1/company-documents", tags=["company-documents"])


@router.get("", response_model=list[CompanyDocumentOut])
def list_documents(ctx: CurrentContext = Depends(current_membership), db: Session = Depends(get_db)):
    docs = company_document_service.list_company_documents(db, ctx)
    return [CompanyDocumentOut.model_validate(d) for d in docs]


@router.post("", response_model=CompanyDocumentOut, status_code=201)
async def upload_document(
    file: UploadFile = File(...),
    name: str = Form(...),
    category: str = Form(...),
    issuing_body: str | None = Form(None),
    expiry_date: date | None = Form(None),
    ctx: CurrentContext = Depends(current_membership),
    db: Session = Depends(get_db),
):
    doc = await company_document_service.upload_company_document(
        db, ctx, file, name=name, category=category, issuing_body=issuing_body, expiry_date=expiry_date
    )
    return CompanyDocumentOut.model_validate(doc)


@router.patch("/{document_id}", response_model=CompanyDocumentOut)
def update_document(
    document_id: uuid.UUID,
    payload: CompanyDocumentUpdate,
    ctx: CurrentContext = Depends(current_membership),
    db: Session = Depends(get_db),
):
    doc = company_document_service.update_company_document(db, ctx, document_id, payload)
    return CompanyDocumentOut.model_validate(doc)


@router.get("/{document_id}/download")
def download_document(
    document_id: uuid.UUID, ctx: CurrentContext = Depends(current_membership), db: Session = Depends(get_db)
):
    doc = company_document_service.get_company_document_or_404(db, ctx, document_id)
    data = get_storage().get(doc.storage_key)
    return StreamingResponse(
        iter([data]),
        media_type=doc.content_type,
        headers={"Content-Disposition": f'attachment; filename="{doc.original_filename}"'},
    )


@router.delete("/{document_id}", status_code=204)
def delete_document(
    document_id: uuid.UUID, ctx: CurrentContext = Depends(current_membership), db: Session = Depends(get_db)
):
    company_document_service.delete_company_document(db, ctx, document_id)
