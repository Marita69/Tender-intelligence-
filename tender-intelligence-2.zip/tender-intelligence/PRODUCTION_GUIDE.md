# Production Guide — What You Need To Do

This lists every step required to take this codebase from "exists" to
"running in production," in order. Nothing in this repo has been run yet
(see root README), so **Part 1 is not optional** — do it before anything
else, on your own machine or CI, where you have real network access.

---

## Part 1 — Get it running locally first (do this before anything else)

1. **Install backend dependencies and run the test suite.**
   ```bash
   cd apps/api
   pip install -r requirements.txt --break-system-packages   # or use a venv
   pytest -v
   ```
   This uses the mock AI provider and in-memory SQLite, so it needs no
   external services. If tests fail, fix that before going further — it's
   much cheaper to find a bug here than after deploying.

2. **Generate and review the initial database migration.**
   ```bash
   # start a local Postgres however you like, e.g.:
   docker run -d --name pg -e POSTGRES_USER=tender -e POSTGRES_PASSWORD=tender \
     -e POSTGRES_DB=tender_intelligence -p 5432:5432 postgres:16-alpine

   cd apps/api
   cp ../../.env.example .env   # then edit DATABASE_URL if needed
   alembic revision --autogenerate -m "initial schema"
   ```
   **Read the generated file in `migrations/versions/` before applying
   it.** Autogenerate is good but not infallible — check enum types,
   nullable flags, and index choices match what you actually want.
   ```bash
   alembic upgrade head
   ```

3. **Install and build the frontend.**
   ```bash
   cd apps/web
   npm install
   npm run build     # this runs `tsc -b` first — fix whatever it reports
   ```
   This has never been run in this environment — treat the first build as
   a debugging session, not a formality.

4. **Run the whole stack together and do one real end-to-end pass.**
   ```bash
   docker compose up --build
   ```
   Sign up, create a tender, upload a real tender PDF (including at least
   one scanned/image-only PDF, to exercise the OCR path), run analysis
   with `AI_PROVIDER=mock`, and check the checklist/report export work.
   Then switch to a real key (`AI_PROVIDER=anthropic`, see step 6 below)
   and do it again to see real extraction quality — the mock provider only
   finds date-like patterns, it will not find real eligibility criteria or
   mandatory documents.

Do not proceed to production infrastructure until this all works locally.

---

## Part 2 — Choose your infrastructure

You need, at minimum:

| Component | What it's for | Suggested options |
|---|---|---|
| Postgres | primary database | Managed: RDS, Supabase, Neon, Render Postgres, DigitalOcean Managed DB |
| Redis | Celery broker/result backend | Managed: Upstash, Redis Cloud, ElastiCache |
| Object storage | tender PDFs, generated reports | S3, Cloudflare R2 (S3-compatible, cheaper egress), DigitalOcean Spaces |
| Compute for `api` | serves the FastAPI app | Fly.io, Render, Railway, ECS/Fargate, a plain VM |
| Compute for `worker` + `beat` | runs the analysis pipeline + retention job | same platform as `api`, separate service/process |
| Static hosting for `web` | the built frontend | Vercel, Netlify, Cloudflare Pages, or served by the same platform as `api` |
| Anthropic API key | real AI analysis | console.anthropic.com |

If you want the absolute simplest path: Render or Railway can host
Postgres + Redis + api + worker + beat all in one project, and
Vercel/Netlify can host the built frontend for free. Fly.io is a good
alternative if you want everything (including Postgres) in one place.

---

## Part 3 — Configuration you must set for production

Copy `.env.example` to your platform's environment variable/secrets
manager (not into a committed `.env` file) and set:

- `SECRET_KEY` — generate with `python3 -c "import secrets; print(secrets.token_urlsafe(48))"`.
  Rotating this invalidates every issued token, so store it somewhere durable.
- `ADMIN_EMAIL` — the ONE email address that gets platform-admin access
  (system overview, org directory/suspend, system logs). Whoever signs up
  or logs in with this exact email (case-insensitive) is auto-elevated;
  every other account is guaranteed non-admin. There is no other way to
  grant this — no invite flow, no API to set it. Use a real inbox you
  control. Leave blank to disable the admin role/pages entirely.
- `APP_ENV=production`
- `DATABASE_URL` / `ASYNC_DATABASE_URL` — your managed Postgres connection strings.
- `REDIS_URL` — your managed Redis connection string.
- `STORAGE_BACKEND=s3`, plus `S3_BUCKET`, `S3_REGION`, `S3_ACCESS_KEY_ID`,
  `S3_SECRET_ACCESS_KEY` (and `S3_ENDPOINT_URL` if using R2/Spaces/MinIO
  instead of real AWS S3).
- `AI_PROVIDER=anthropic` and `ANTHROPIC_API_KEY` — see Part 4.
- `CORS_ORIGINS` — the real frontend origin(s), e.g. `["https://app.yourdomain.com"]`.
  Never leave this as `*` or `localhost` in production.
- `SENTRY_DSN` — see Part 6.
- `CELERY_TASK_ALWAYS_EAGER=false` — production must run a real worker process.
- `VITE_API_BASE_URL` (frontend build-time var) — your real API URL,
  e.g. `https://api.yourdomain.com`. This is baked in at `npm run build`
  time, so you must rebuild the frontend if this changes.
- `BILLING_PROVIDER` and Stripe keys — only if you're charging for usage;
  see Part 5. Leave as `none` for an internal/unlimited-usage deployment.

## Part 4 — Get an AI provider API key

Three providers are supported out of the box, sharing one abstraction
(`app/ai/provider.py`) — pick whichever fits your budget. All three can
be configured at startup via `.env`, and switched at runtime without a
redeploy via the platform admin's **Admin Dashboard → AI Provider**
panel (only the `ADMIN_EMAIL` account can see it) — the env vars below
are just the fresh-install default.

### Option A: Anthropic (highest quality, paid)

1. Go to https://console.anthropic.com and create/sign in to an
   organization.
2. Create an API key under Settings → API Keys.
3. Set `ANTHROPIC_API_KEY` and `AI_PROVIDER=anthropic`.
4. Set a billing budget/alert in the console so a bug in the retry logic
   can't run up an unbounded bill.
5. `AI_MODEL` in `.env` currently points at `claude-sonnet-4-6` — check
   console.anthropic.com/docs for the current recommended model string
   before launch, since this may have changed since this repo was written.

### Option B: OpenRouter (free tier available)

1. Sign up at https://openrouter.ai, create a key at
   openrouter.ai/keys.
2. Set `OPENROUTER_API_KEY` and `AI_PROVIDER=openrouter`.
3. Pick a model from https://openrouter.ai/models — filter by
   `max_price=0` for genuinely free models (suffixed `:free`). Free
   models have real usage limits (requests/day) and no uptime guarantee —
   fine for evaluating the product or low-volume/self-hosted use, not
   something to build a paid product on top of without a fallback.
4. Set `OPENROUTER_MODEL` to whatever you picked.

### Option C: NVIDIA NIM (free evaluation tier)

1. Sign up at https://build.nvidia.com, create a key from your profile.
2. Set `NVIDIA_API_KEY` and `AI_PROVIDER=nvidia`.
3. Pick a model from NVIDIA's catalog at build.nvidia.com/models and set
   `NVIDIA_MODEL` accordingly.
4. NVIDIA's free tier is an evaluation allowance, not an unlimited free
   product — check their current terms before relying on it for real
   traffic.

### Option D: Google Gemini (free tier available)

1. Sign up at https://aistudio.google.com, create a key at
   aistudio.google.com/apikey.
2. Set `GEMINI_API_KEY` and `AI_PROVIDER=gemini`.
3. `GEMINI_MODEL` defaults to `gemini-2.0-flash`; see
   ai.google.dev/gemini-api/docs/models for the current catalog and each
   model's free-tier request/token limits.
4. This goes through Google's OpenAI-compatibility endpoint
   (`generativelanguage.googleapis.com/.../openai`), not the native Gemini
   SDK — same generic provider as OpenRouter/NVIDIA, see the caveat below.

### Option E: DeepSeek (low-cost, not free)

1. Sign up at https://platform.deepseek.com, create a key at
   platform.deepseek.com/api_keys.
2. Set `DEEPSEEK_API_KEY` and `AI_PROVIDER=deepseek`.
3. `DEEPSEEK_MODEL` defaults to `deepseek-chat`; `deepseek-reasoner` is
   also available for harder extraction cases at higher cost/latency.
4. Unlike the other options here, DeepSeek's direct API has no free tier
   — it's included because it was specifically requested, not because
   it's free. Pricing is low relative to frontier-model APIs; check
   platform.deepseek.com/api-docs/pricing for current rates.

### Structured-output caveat for B through E

Anthropic's provider prompts for JSON and parses the response text
directly (no native tool-calling used). OpenRouter/NVIDIA/Gemini/DeepSeek
all go through the same prompt-and-parse approach (with a best-effort
`response_format=json_object` attempt first, falling back automatically
if the model/provider rejects it) for portability across the wide range
of models any of these might be pointed at — free/smaller models are
more likely to occasionally return malformed JSON or ignore part of the
schema than a frontier model like Claude. If you see a lot of
requirements landing with `confidence=unknown` or entire chunks silently
failing to parse (check the API logs for `ai_json_parse_failed`), that's
usually the model, not a bug — try a larger/more capable model in the
same provider's catalog, or switch providers via the admin panel to
compare quality before committing.

## Part 5 — Billing (only if you're charging users)

The billing abstraction (`app/services/billing_service.py`,
`app/models/billing.py`) is a **credits ledger with idempotent, signature-
verified webhook handling**, plus a checkout-session endpoint and a basic
frontend billing page. It is not wired to a real Stripe product/price
yet. To finish it:

1. Create a Stripe account, and a product/price for whatever unit you're
   selling (default assumption in this code: a fixed bundle of analysis
   credits per purchase).
2. Set `BILLING_PROVIDER=stripe`, `STRIPE_SECRET_KEY`, `STRIPE_WEBHOOK_SECRET`,
   `STRIPE_PRICE_ID` (the Stripe Price id for your credits bundle), and
   `STRIPE_CREDITS_PER_PURCHASE` (how many credits that price grants).
3. Point a Stripe webhook at `POST /api/v1/admin/billing/webhook`.
   Signature verification is already implemented
   (`stripe.Webhook.construct_event(...)` against the raw body and
   `STRIPE_WEBHOOK_SECRET` in `app/api/admin.py`) — you do not need to add
   this yourself, just make sure `STRIPE_WEBHOOK_SECRET` matches what
   Stripe's dashboard shows for the webhook endpoint you create.
4. The `checkout.session.completed` handling in `admin.py` reads
   `client_reference_id` (the organization id) and `metadata.credits`
   (set by `create_checkout_session_url` in `billing_service.py`) — if you
   change the checkout session creation, keep these two in sync.
5. The frontend `BillingPage` (`/app/billing`) shows balance and a "buy
   more credits" button that redirects to Stripe Checkout — it does not
   yet show a post-purchase confirmation screen; Stripe redirects back to
   `success_url`/`cancel_url` with query params you can read and display
   if you want that polish.

If you're not charging (internal tool, free tier, self-hosted), leave
`BILLING_PROVIDER=none` and skip this whole section — every organization
gets unlimited analyses.

## Part 6 — Observability

1. Create a free Sentry project (or use an existing one), set `SENTRY_DSN`.
   Both the FastAPI app and (if you wire it similarly) the Celery worker
   will report unhandled exceptions.
2. Structured JSON logs are emitted to stdout in non-development
   environments (`app/core/logging.py`) — point your platform's log
   aggregation (or a sidecar like Vector/Fluent Bit) at stdout; no
   additional log shipping code is needed.
3. Point your platform's health checks at `GET /health` (liveness — no DB
   call) and `GET /health/ready` (readiness — confirms DB connectivity).
4. Set up an uptime check (e.g. Better Uptime, UptimeRobot, or your
   platform's built-in one) against `/health`.
5. Watch Celery queue depth once you have real traffic — if analysis jobs
   back up, scale worker replicas or increase concurrency
   (`celery -A app.workers.celery_app worker --concurrency=N`).

## Part 7 — Security checklist before going live

- [ ] `SECRET_KEY` is a real random value, not the placeholder, and is
      stored in a secrets manager, not committed anywhere.
- [ ] `CORS_ORIGINS` is locked to your real frontend domain(s).
- [ ] `Stripe webhook signature verification is implemented (Part 5, if applicable).` — ~~gap~~ **done**: `admin.py` verifies `stripe-signature` via `stripe.Webhook.construct_event`. Just confirm `STRIPE_WEBHOOK_SECRET` is set correctly for your environment.
- [ ] Rate limiting — ~~gap~~ **partially done**: `slowapi` is wired globally (200/min default) with stricter limits on `/auth/signup` (5/hour) and `/auth/login` (10/min). Review whether other endpoints (e.g. `/analysis/run`, given it costs a credit and calls a paid AI API) need their own limits before launch, and switch the limiter's storage from in-memory to Redis-backed for any multi-instance deployment (see `app/core/rate_limit.py`).
- [ ] TLS/HTTPS is enforced end-to-end (most platforms do this
      automatically; if self-hosting on a VM, put Caddy or nginx in front
      with Let's Encrypt).
- [ ] Postgres and Redis are not publicly reachable — only from your
      `api`/`worker` compute, via VPC/private networking or IP allowlisting.
- [ ] S3 bucket is private (no public read); the app serves files through
      the authenticated `/documents/{id}/download` route or short-lived
      presigned URLs, never a public bucket URL.
- [ ] Rate limiting — see the updated item above; if you expect meaningful
      traffic, also consider a reverse-proxy/CDN-level rule as defense in
      depth on top of the in-app `slowapi` limits.
- [ ] Backups are configured for Postgres (most managed providers do daily
      snapshots by default — confirm retention period meets your needs)
      and lifecycle rules are set on the S3 bucket if you want redundancy
      beyond Postgres.
- [ ] Decide and document your real data-retention window (the retention
      worker in `app/workers/tasks.py` currently hard-codes 30 days for
      soft-deleted documents — change `RETENTION_DAYS` to match your
      actual policy, and confirm it against any regulatory requirements
      relevant to your customers' data).
- [ ] `apps/api/.env` and `apps/web/.env` are in `.gitignore` (already are)
      and were never committed with real secrets during local development.

## Part 8 — Deploy

Exact steps depend on your chosen platform, but the shape is always:

1. Build and push the `apps/api` Docker image (used for both `api` and
   `worker`/`beat` — same image, different `command`).
2. Run three processes/services from that image: `uvicorn app.main:app`,
   `celery -A app.workers.celery_app worker`, and
   `celery -A app.workers.celery_app beat`.
3. Run `alembic upgrade head` as a release step (before the new `api`
   version receives traffic) — most platforms have a dedicated "release
   command" hook for this; otherwise run it manually before flipping traffic.
4. Build the frontend (`npm run build` with the real `VITE_API_BASE_URL`)
   and deploy the built static output to your static host, or serve it
   from a small nginx container.
5. Point DNS at both (e.g. `app.yourdomain.com` → frontend,
   `api.yourdomain.com` → backend), confirm HTTPS certs are issued.
6. Smoke-test: sign up, upload a real tender, run analysis, export a
   report, exactly like step 4 of Part 1, but against production.

## Part 9 — What to build next (post-launch priorities)

Updated since the first pass — items 1, 2, 4, and 5 below are now done;
what's left:

1. ~~Human review queue UI~~ — **done**: `/app/review-queue` lets a
   reviewer filter and resolve/reject flagged items.
2. ~~Field-correction UI~~ — **done**: an inline "Correct" affordance on
   each requirement in the Tender Overview tab.
3. **Real-time job progress** — still polling-based (with backoff, in
   `TenderDetail.tsx`), not push-based. Good enough for single-user usage;
   consider websockets/SSE if you expect many concurrent users watching
   the same long-running analysis.
4. ~~Rate limiting~~ — **done** at the app level (`slowapi`); still
   consider a CDN/reverse-proxy layer on top for defense in depth (Part 7).
5. ~~Stripe signature verification + checkout UI~~ — **done**. Remaining
   billing polish: a post-purchase confirmation screen (currently just
   redirects back to the tenders list), and handling refunds/disputes if
   you need to claw back credits.
6. Admin dashboard UI beyond the raw stats page — no queue-depth, AI-spend,
   or error-rate visualizations yet.
7. A full design pass on the frontend — the current Tailwind styling is
   functional and consistent (see the "compliance stamp" motif) but was
   optimized for correctness over polish given the scope of this build.
8. Multi-language support, SSO/SAML, drag-and-drop upload — not started.
